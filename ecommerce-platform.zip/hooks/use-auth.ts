"use client"

import type React from "react"

import { useState, useEffect, createContext, useContext } from "react"

type User = {
  id: string
  name: string
  email: string
  image?: string
}

type AuthContextType = {
  isAuthenticated: boolean
  isLoading: boolean
  user: User | null
  signIn: (email: string, password: string) => Promise<boolean>
  signOut: () => void
  addToCartAfterSignIn: (productId: number | null) => void
  pendingCartItem: number | null
}

// Create context with default values
const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  isLoading: true,
  user: null,
  signIn: async () => false,
  signOut: () => {},
  addToCartAfterSignIn: () => {},
  pendingCartItem: null,
})

// Mock user data
const mockUser: User = {
  id: "user-1",
  name: "John Doe",
  email: "john.doe@example.com",
  image: "/placeholder.svg?height=32&width=32&text=JD",
}

// Provider component
export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [user, setUser] = useState<User | null>(null)
  const [pendingCartItem, setPendingCartItem] = useState<number | null>(null)

  // Check if user is already authenticated on mount
  useEffect(() => {
    const checkAuth = () => {
      const storedAuth = localStorage.getItem("isAuthenticated")
      if (storedAuth === "true") {
        setIsAuthenticated(true)
        setUser(mockUser)
      }
      setIsLoading(false)
    }

    checkAuth()
  }, [])

  // Sign in function
  const signIn = async (email: string, password: string): Promise<boolean> => {
    // In a real app, this would make an API call to authenticate
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // For demo purposes, any email/password combination works
    setIsAuthenticated(true)
    setUser(mockUser)
    localStorage.setItem("isAuthenticated", "true")
    setIsLoading(false)
    return true
  }

  // Sign out function
  const signOut = () => {
    setIsAuthenticated(false)
    setUser(null)
    localStorage.removeItem("isAuthenticated")
  }

  // Add to cart after sign in
  const addToCartAfterSignIn = (productId: number | null) => {
    setPendingCartItem(productId)
  }

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isLoading,
        user,
        signIn,
        signOut,
        addToCartAfterSignIn,
        pendingCartItem,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

// Hook for using the auth context
export const useAuth = () => useContext(AuthContext)

