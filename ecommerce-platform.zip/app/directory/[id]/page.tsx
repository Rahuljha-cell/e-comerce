"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Clock, Globe, MapPin, Phone, Star } from "lucide-react"

export default function BusinessPage({ params }: { params: { id: string } }) {
  const [reviewText, setReviewText] = useState("")
  const [rating, setRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)

  // Mock business data
  const business = {
    id: Number.parseInt(params.id),
    name: `Business Name ${params.id}`,
    category: Number.parseInt(params.id) % 2 === 0 ? "Retail" : "Services",
    rating: 4.5,
    reviews: 78,
    address: "123 Main St, New York, NY 10001",
    phone: "(123) 456-7890",
    website: "www.business-name.com",
    hours: {
      Monday: "9:00 AM - 6:00 PM",
      Tuesday: "9:00 AM - 6:00 PM",
      Wednesday: "9:00 AM - 6:00 PM",
      Thursday: "9:00 AM - 6:00 PM",
      Friday: "9:00 AM - 6:00 PM",
      Saturday: "10:00 AM - 4:00 PM",
      Sunday: "Closed",
    },
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
    images: [
      `/placeholder.svg?height=400&width=600&text=Business+${params.id}+Image+1`,
      `/placeholder.svg?height=400&width=600&text=Business+${params.id}+Image+2`,
      `/placeholder.svg?height=400&width=600&text=Business+${params.id}+Image+3`,
    ],
    reviews: [
      {
        id: 1,
        name: "John Doe",
        rating: 5,
        date: "2023-05-15",
        text: "Great service and friendly staff. Would definitely recommend!",
      },
      {
        id: 2,
        name: "Jane Smith",
        rating: 4,
        date: "2023-04-22",
        text: "Good experience overall. The products are high quality but a bit pricey.",
      },
      {
        id: 3,
        name: "Mike Johnson",
        rating: 5,
        date: "2023-03-10",
        text: "Excellent customer service. They went above and beyond to help me find what I needed.",
      },
    ],
  }

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, this would submit the review to an API
    alert(`Review submitted: ${rating} stars - ${reviewText}`)
    setReviewText("")
    setRating(0)
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Link href="/directory" className="flex items-center text-sm mb-6 hover:underline">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Directory
      </Link>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <div className="relative aspect-video overflow-hidden rounded-lg">
            <Image
              src={business.images[0] || "/placeholder.svg"}
              alt={business.name}
              fill
              className="object-cover"
              priority
            />
          </div>
          <div className="grid grid-cols-3 gap-2">
            {business.images.slice(1).map((image, index) => (
              <div key={index} className="relative aspect-video overflow-hidden rounded-lg">
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`${business.name} - Image ${index + 2}`}
                  fill
                  className="object-cover"
                />
              </div>
            ))}
          </div>

          <Tabs defaultValue="about">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="about">About</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>
            <TabsContent value="about" className="mt-6">
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">About {business.name}</h2>
                <p className="text-muted-foreground">{business.description}</p>
                <p className="text-muted-foreground">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et
                  dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                  aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
                  dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                  officia deserunt mollit anim id est laborum.
                </p>
              </div>
            </TabsContent>
            <TabsContent value="reviews" className="mt-6">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">Customer Reviews</h2>
                  <div className="flex items-center">
                    <div className="flex">
                      {Array(5)
                        .fill(0)
                        .map((_, i) => (
                          <Star
                            key={i}
                            className={`h-5 w-5 ${
                              i < Math.floor(business.rating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                            }`}
                          />
                        ))}
                    </div>
                    <span className="ml-2 font-medium">
                      {business.rating} ({business.reviews.length} reviews)
                    </span>
                  </div>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Write a Review</CardTitle>
                    <CardDescription>Share your experience with this business</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmitReview} className="space-y-4">
                      <div>
                        <div className="flex items-center mb-2">
                          <span className="mr-2">Rating:</span>
                          <div className="flex">
                            {Array(5)
                              .fill(0)
                              .map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-6 w-6 cursor-pointer ${
                                    i < (hoveredRating || rating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                  }`}
                                  onMouseEnter={() => setHoveredRating(i + 1)}
                                  onMouseLeave={() => setHoveredRating(0)}
                                  onClick={() => setRating(i + 1)}
                                />
                              ))}
                          </div>
                        </div>
                        <Textarea
                          placeholder="Write your review here..."
                          value={reviewText}
                          onChange={(e) => setReviewText(e.target.value)}
                          className="min-h-[100px]"
                        />
                      </div>
                      <Button type="submit" disabled={!rating || !reviewText.trim()}>
                        Submit Review
                      </Button>
                    </form>
                  </CardContent>
                </Card>

                <div className="space-y-4">
                  {business.reviews.map((review) => (
                    <Card key={review.id}>
                      <CardContent className="pt-6">
                        <div className="flex justify-between mb-2">
                          <div>
                            <h4 className="font-semibold">{review.name}</h4>
                            <div className="flex">
                              {Array(5)
                                .fill(0)
                                .map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`h-4 w-4 ${
                                      i < review.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                    }`}
                                  />
                                ))}
                            </div>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            {new Date(review.date).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-muted-foreground">{review.text}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{business.name}</CardTitle>
              <CardDescription>{business.category}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center">
                <MapPin className="h-5 w-5 mr-2 text-muted-foreground" />
                <span>{business.address}</span>
              </div>
              <div className="flex items-center">
                <Phone className="h-5 w-5 mr-2 text-muted-foreground" />
                <span>{business.phone}</span>
              </div>
              <div className="flex items-center">
                <Globe className="h-5 w-5 mr-2 text-muted-foreground" />
                <a
                  href={`https://${business.website}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline"
                >
                  {business.website}
                </a>
              </div>
              <div className="pt-4 border-t">
                <h3 className="font-semibold mb-2 flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-muted-foreground" />
                  Business Hours
                </h3>
                <ul className="space-y-1">
                  {Object.entries(business.hours).map(([day, hours]) => (
                    <li key={day} className="flex justify-between text-sm">
                      <span>{day}</span>
                      <span className="text-muted-foreground">{hours}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Location</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative aspect-square overflow-hidden rounded-lg bg-muted">
                <Image src="/placeholder.svg?height=400&width=400&text=Map" alt="Map" fill className="object-cover" />
              </div>
              <Button className="w-full mt-4">Get Directions</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Contact Business</CardTitle>
            </CardHeader>
            <CardContent>
              <Button className="w-full">Send Message</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

