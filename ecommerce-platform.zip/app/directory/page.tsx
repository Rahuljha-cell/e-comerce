"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Phone, Star, Search } from "lucide-react"

export default function DirectoryPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [category, setCategory] = useState("all")

  // Mock business data
  const businesses = [
    {
      id: 1,
      name: "Tech Solutions Inc.",
      category: "Technology",
      rating: 4.8,
      reviews: 124,
      address: "123 Main St, New York, NY",
      phone: "(123) 456-7890",
      image: "/placeholder.svg?height=200&width=400&text=Tech+Solutions",
      description: "Providing innovative technology solutions for businesses of all sizes.",
    },
    {
      id: 2,
      name: "Green Leaf Cafe",
      category: "Food & Dining",
      rating: 4.5,
      reviews: 89,
      address: "456 Oak Ave, New York, NY",
      phone: "(123) 456-7891",
      image: "/placeholder.svg?height=200&width=400&text=Green+Leaf+Cafe",
      description: "Organic cafe serving fresh, locally-sourced meals in a cozy atmosphere.",
    },
    {
      id: 3,
      name: "Fitness First Gym",
      category: "Health & Fitness",
      rating: 4.2,
      reviews: 67,
      address: "789 Pine Rd, New York, NY",
      phone: "(123) 456-7892",
      image: "/placeholder.svg?height=200&width=400&text=Fitness+First",
      description: "State-of-the-art fitness center with personal training and group classes.",
    },
    {
      id: 4,
      name: "Creative Design Studio",
      category: "Creative Services",
      rating: 4.9,
      reviews: 45,
      address: "101 Maple Dr, New York, NY",
      phone: "(123) 456-7893",
      image: "/placeholder.svg?height=200&width=400&text=Creative+Design",
      description: "Award-winning design studio specializing in branding and digital media.",
    },
    {
      id: 5,
      name: "Sunset Spa & Wellness",
      category: "Health & Fitness",
      rating: 4.7,
      reviews: 112,
      address: "202 Cedar Ln, New York, NY",
      phone: "(123) 456-7894",
      image: "/placeholder.svg?height=200&width=400&text=Sunset+Spa",
      description: "Luxury spa offering a range of treatments for relaxation and rejuvenation.",
    },
    {
      id: 6,
      name: "Urban Outfitters",
      category: "Retail",
      rating: 4.3,
      reviews: 78,
      address: "303 Birch Blvd, New York, NY",
      phone: "(123) 456-7895",
      image: "/placeholder.svg?height=200&width=400&text=Urban+Outfitters",
      description: "Trendy clothing and accessories for the fashion-forward shopper.",
    },
  ]

  // Filter businesses based on search query and category
  const filteredBusinesses = businesses.filter((business) => {
    const matchesSearch =
      business.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      business.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = category === "all" || business.category === category
    return matchesSearch && matchesCategory
  })

  // Get unique categories
  const categories = ["all", ...new Set(businesses.map((business) => business.category))]

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <div className="flex flex-col items-center text-center space-y-2 mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Business Directory</h1>
        <p className="text-muted-foreground max-w-[700px]">Discover and connect with local businesses in your area.</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search businesses..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-full md:w-[200px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((cat) => (
              <SelectItem key={cat} value={cat}>
                {cat === "all" ? "All Categories" : cat}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="grid">
        <div className="flex justify-between items-center mb-6">
          <div className="text-sm text-muted-foreground">
            Showing {filteredBusinesses.length} of {businesses.length} businesses
          </div>
          <TabsList>
            <TabsTrigger value="grid">Grid</TabsTrigger>
            <TabsTrigger value="list">List</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="grid" className="mt-0">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBusinesses.map((business) => (
              <Card key={business.id} className="overflow-hidden">
                <div className="relative h-48">
                  <Image src={business.image || "/placeholder.svg"} alt={business.name} fill className="object-cover" />
                </div>
                <CardHeader>
                  <CardTitle>{business.name}</CardTitle>
                  <CardDescription>{business.category}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center mb-2">
                    <div className="flex">
                      {Array(5)
                        .fill(0)
                        .map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < Math.floor(business.rating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                            }`}
                          />
                        ))}
                    </div>
                    <span className="ml-2 text-sm text-muted-foreground">
                      {business.rating} ({business.reviews} reviews)
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">{business.description}</p>
                  <div className="space-y-1">
                    <div className="flex items-center text-sm">
                      <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{business.address}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Phone className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{business.phone}</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button asChild className="w-full">
                    <Link href={`/directory/${business.id}`}>View Details</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="list" className="mt-0">
          <div className="space-y-4">
            {filteredBusinesses.map((business) => (
              <Card key={business.id}>
                <div className="flex flex-col md:flex-row">
                  <div className="relative w-full md:w-48 h-48 md:h-auto">
                    <Image
                      src={business.image || "/placeholder.svg"}
                      alt={business.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1 p-6">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                      <div>
                        <h3 className="text-lg font-semibold">{business.name}</h3>
                        <p className="text-sm text-muted-foreground">{business.category}</p>
                      </div>
                      <div className="flex items-center mt-2 md:mt-0">
                        <div className="flex">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${
                                  i < Math.floor(business.rating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                }`}
                              />
                            ))}
                        </div>
                        <span className="ml-2 text-sm text-muted-foreground">
                          {business.rating} ({business.reviews} reviews)
                        </span>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">{business.description}</p>
                    <div className="flex flex-col md:flex-row md:items-center justify-between">
                      <div className="space-y-1 md:space-y-0 md:space-x-4 md:flex">
                        <div className="flex items-center text-sm">
                          <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span>{business.address}</span>
                        </div>
                        <div className="flex items-center text-sm">
                          <Phone className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span>{business.phone}</span>
                        </div>
                      </div>
                      <Button asChild className="mt-4 md:mt-0">
                        <Link href={`/directory/${business.id}`}>View Details</Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

