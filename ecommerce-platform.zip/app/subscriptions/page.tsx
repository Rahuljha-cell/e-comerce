"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Check, CheckCircle2, CreditCard, Landmark, Wallet } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import LoadingSpinner from "@/components/loading-spinner"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function SubscriptionsPage() {
  const [billingCycle, setBillingCycle] = useState("monthly")
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState("credit-card")
  const [isProcessing, setIsProcessing] = useState(false)
  const [activeSubscription, setActiveSubscription] = useState<string | null>(null)
  const [cardInfo, setCardInfo] = useState({
    cardNumber: "",
    cardName: "",
    expiry: "",
    cvv: "",
  })

  // Mock subscription plans
  const plans = [
    {
      id: "basic",
      name: "Basic",
      description: "Essential features for individuals",
      monthlyPrice: 9.99,
      yearlyPrice: 99.99,
      features: ["Access to basic products", "Standard shipping", "Email support", "10% discount on all purchases"],
    },
    {
      id: "premium",
      name: "Premium",
      description: "Advanced features for professionals",
      monthlyPrice: 19.99,
      yearlyPrice: 199.99,
      features: [
        "Access to all products",
        "Free priority shipping",
        "24/7 phone and email support",
        "20% discount on all purchases",
        "Early access to new products",
      ],
      popular: true,
    },
    {
      id: "enterprise",
      name: "Enterprise",
      description: "Complete solution for businesses",
      monthlyPrice: 49.99,
      yearlyPrice: 499.99,
      features: [
        "Access to all products and services",
        "Free express shipping",
        "Dedicated account manager",
        "30% discount on all purchases",
        "Early access to new products",
        "Custom solutions and integrations",
      ],
    },
  ]

  const handleSubscribe = (planId: string) => {
    setSelectedPlan(planId)
    setIsPaymentDialogOpen(true)
  }

  const handleCardInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setCardInfo((prev) => ({ ...prev, [name]: value }))
  }

  const validateCardInfo = () => {
    if (paymentMethod !== "credit-card") return true

    return (
      cardInfo.cardNumber.length >= 16 &&
      cardInfo.cardName.trim() !== "" &&
      cardInfo.expiry.length >= 5 &&
      cardInfo.cvv.length >= 3
    )
  }

  const handleProcessPayment = async () => {
    if (!validateCardInfo() && paymentMethod === "credit-card") {
      toast({
        title: "Invalid Card Information",
        description: "Please check your card details and try again.",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setIsProcessing(false)
    setIsPaymentDialogOpen(false)
    setActiveSubscription(selectedPlan)

    toast({
      title: "Subscription Activated",
      description: `Your ${plans.find((p) => p.id === selectedPlan)?.name} subscription has been successfully activated.`,
    })
  }

  const handleCancelSubscription = async () => {
    setIsProcessing(true)

    // Simulate cancellation processing
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsProcessing(false)
    setActiveSubscription(null)

    toast({
      title: "Subscription Cancelled",
      description: "Your subscription has been cancelled. You will have access until the end of your billing period.",
    })
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Toaster />

      <div className="flex flex-col items-center text-center space-y-2 mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Subscription Plans</h1>
        <p className="text-muted-foreground max-w-[700px]">
          Choose the perfect plan for your needs. Upgrade or downgrade at any time.
        </p>
      </div>

      {activeSubscription && (
        <Alert className="mb-8 max-w-3xl mx-auto">
          <CheckCircle2 className="h-4 w-4" />
          <AlertTitle>Active Subscription</AlertTitle>
          <AlertDescription className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              You are currently subscribed to the{" "}
              <span className="font-semibold">{plans.find((p) => p.id === activeSubscription)?.name}</span> plan. Your
              next billing date is {new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}.
            </div>
            <Button variant="outline" size="sm" onClick={() => handleCancelSubscription()} disabled={isProcessing}>
              {isProcessing ? (
                <>
                  <LoadingSpinner size="small" />
                  <span className="ml-2">Processing...</span>
                </>
              ) : (
                "Cancel Subscription"
              )}
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <div className="flex justify-center mb-8">
        <Tabs defaultValue="monthly" value={billingCycle} onValueChange={setBillingCycle} className="w-[400px]">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
            <TabsTrigger value="yearly">Yearly (Save 15%)</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Card key={plan.id} className={`flex flex-col ${plan.popular ? "border-primary shadow-md" : ""}`}>
            {plan.popular && (
              <div className="bg-primary text-primary-foreground text-center py-1 text-sm font-medium">
                Most Popular
              </div>
            )}
            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="mb-4">
                <span className="text-3xl font-bold">
                  ${billingCycle === "monthly" ? plan.monthlyPrice : plan.yearlyPrice}
                </span>
                <span className="text-muted-foreground">/{billingCycle === "monthly" ? "month" : "year"}</span>
              </div>
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="h-4 w-4 mr-2 text-primary" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full"
                variant={plan.popular ? "default" : "outline"}
                onClick={() => handleSubscribe(plan.id)}
                disabled={activeSubscription === plan.id}
              >
                {activeSubscription === plan.id ? (
                  <>
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Current Plan
                  </>
                ) : (
                  `Subscribe to ${plan.name}`
                )}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="mt-12">
        <Tabs defaultValue="features">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="faq">FAQ</TabsTrigger>
            <TabsTrigger value="testimonials">Testimonials</TabsTrigger>
          </TabsList>
          <TabsContent value="features" className="mt-6">
            <div className="grid md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Product Access</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Subscribers get exclusive access to premium products and early releases before they're available to
                    the general public.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Free Shipping</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Enjoy free shipping on all orders, with priority and express options available for higher-tier
                    plans.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Dedicated Support</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Get priority customer support with faster response times and dedicated account managers for
                    enterprise plans.
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="faq" className="mt-6">
            <div className="space-y-4">
              <div className="border-b pb-4">
                <h3 className="font-semibold mb-2">Can I cancel my subscription at any time?</h3>
                <p className="text-muted-foreground">
                  Yes, you can cancel your subscription at any time. Your benefits will continue until the end of your
                  current billing cycle.
                </p>
              </div>
              <div className="border-b pb-4">
                <h3 className="font-semibold mb-2">How do I upgrade or downgrade my plan?</h3>
                <p className="text-muted-foreground">
                  You can change your plan at any time from your account settings. Changes will be applied at the start
                  of your next billing cycle.
                </p>
              </div>
              <div className="border-b pb-4">
                <h3 className="font-semibold mb-2">Are there any long-term commitments?</h3>
                <p className="text-muted-foreground">
                  No, all our plans are commitment-free. You can subscribe on a monthly or yearly basis with no
                  long-term contracts.
                </p>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="testimonials" className="mt-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardContent className="pt-6">
                  <p className="italic text-muted-foreground mb-4">
                    "The Premium subscription has been a game-changer for our business. The dedicated support and
                    discounts have saved us thousands."
                  </p>
                  <div className="font-semibold">Sarah Johnson</div>
                  <div className="text-sm text-muted-foreground">CEO, Johnson Enterprises</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <p className="italic text-muted-foreground mb-4">
                    "I love the Basic plan for my personal use. The discounts and free shipping have already paid for
                    the subscription many times over."
                  </p>
                  <div className="font-semibold">Michael Chen</div>
                  <div className="text-sm text-muted-foreground">Freelance Designer</div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Payment Dialog */}
      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Complete Your Subscription</DialogTitle>
            <DialogDescription>
              {selectedPlan && (
                <>
                  You are subscribing to the {plans.find((p) => p.id === selectedPlan)?.name} plan for $
                  {billingCycle === "monthly"
                    ? plans.find((p) => p.id === selectedPlan)?.monthlyPrice
                    : plans.find((p) => p.id === selectedPlan)?.yearlyPrice}
                  /{billingCycle === "monthly" ? "month" : "year"}.
                </>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <div className="space-y-2">
              <Label>Payment Method</Label>
              <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-2">
                <div className="flex items-center space-x-2 rounded-md border p-3">
                  <RadioGroupItem value="credit-card" id="credit-card" />
                  <Label htmlFor="credit-card" className="flex items-center gap-2 cursor-pointer">
                    <CreditCard className="h-4 w-4" />
                    Credit Card
                  </Label>
                </div>
                <div className="flex items-center space-x-2 rounded-md border p-3">
                  <RadioGroupItem value="paypal" id="paypal" />
                  <Label htmlFor="paypal" className="flex items-center gap-2 cursor-pointer">
                    <Wallet className="h-4 w-4" />
                    PayPal
                  </Label>
                </div>
                <div className="flex items-center space-x-2 rounded-md border p-3">
                  <RadioGroupItem value="bank-transfer" id="bank-transfer" />
                  <Label htmlFor="bank-transfer" className="flex items-center gap-2 cursor-pointer">
                    <Landmark className="h-4 w-4" />
                    Bank Transfer
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {paymentMethod === "credit-card" && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="cardNumber">Card Number</Label>
                  <Input
                    id="cardNumber"
                    name="cardNumber"
                    placeholder="1234 5678 9012 3456"
                    value={cardInfo.cardNumber}
                    onChange={handleCardInfoChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cardName">Name on Card</Label>
                  <Input
                    id="cardName"
                    name="cardName"
                    placeholder="John Doe"
                    value={cardInfo.cardName}
                    onChange={handleCardInfoChange}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="expiry">Expiry Date</Label>
                    <Input
                      id="expiry"
                      name="expiry"
                      placeholder="MM/YY"
                      value={cardInfo.expiry}
                      onChange={handleCardInfoChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cvv">CVV</Label>
                    <Input id="cvv" name="cvv" placeholder="123" value={cardInfo.cvv} onChange={handleCardInfoChange} />
                  </div>
                </div>
              </div>
            )}

            {paymentMethod === "paypal" && (
              <div className="text-center p-4 border rounded-md">
                <p className="text-muted-foreground mb-4">You will be redirected to PayPal to complete your payment.</p>
              </div>
            )}

            {paymentMethod === "bank-transfer" && (
              <div className="p-4 border rounded-md">
                <p className="text-muted-foreground mb-4">
                  Please use the following details to make your bank transfer:
                </p>
                <div className="space-y-2 text-sm">
                  <p>
                    <span className="font-medium">Bank Name:</span> Global Bank
                  </p>
                  <p>
                    <span className="font-medium">Account Name:</span> ShopHub Inc.
                  </p>
                  <p>
                    <span className="font-medium">Account Number:</span> 1234567890
                  </p>
                  <p>
                    <span className="font-medium">Routing Number:</span> 987654321
                  </p>
                  <p>
                    <span className="font-medium">Reference:</span> SUB-{Date.now().toString().slice(-6)}
                  </p>
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)} disabled={isProcessing}>
              Cancel
            </Button>
            <Button onClick={handleProcessPayment} disabled={isProcessing}>
              {isProcessing ? (
                <>
                  <LoadingSpinner size="small" />
                  <span className="ml-2">Processing...</span>
                </>
              ) : (
                `Pay ${
                  billingCycle === "monthly"
                    ? `$${plans.find((p) => p.id === selectedPlan)?.monthlyPrice}/month`
                    : `$${plans.find((p) => p.id === selectedPlan)?.yearlyPrice}/year`
                }`
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

