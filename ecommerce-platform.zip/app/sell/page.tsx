"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { CheckCircle2, Store, TrendingUp, Users, CreditCard, HelpCircle, BarChart, Package, Truck } from "lucide-react"

export default function SellPage() {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    businessName: "",
    businessEmail: "",
    businessPhone: "",
    businessWebsite: "",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    country: "",
    businessType: "",
    taxId: "",
    productCategories: [] as string[],
    agreeTerms: false,
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))
  }

  const handleCategoryToggle = (category: string) => {
    setFormData((prev) => {
      const categories = [...prev.productCategories]
      if (categories.includes(category)) {
        return { ...prev, productCategories: categories.filter((c) => c !== category) }
      } else {
        return { ...prev, productCategories: [...categories, category] }
      }
    })
  }

  const validateStep1 = () => {
    const { businessName, businessEmail, firstName, lastName, email } = formData
    return businessName && businessEmail && firstName && lastName && email
  }

  const validateStep2 = () => {
    const { address, city, state, zip, country, businessType } = formData
    return address && city && state && zip && country && businessType
  }

  const validateStep3 = () => {
    const { productCategories, agreeTerms } = formData
    return productCategories.length > 0 && agreeTerms
  }

  const handleNextStep = () => {
    if (step === 1 && validateStep1()) {
      setStep(2)
    } else if (step === 2 && validateStep2()) {
      setStep(3)
    } else if (step === 3 && validateStep3()) {
      handleSubmit()
    } else {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields to continue.",
        variant: "destructive",
      })
    }
  }

  const handlePrevStep = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  const handleSubmit = () => {
    // Simulate form submission
    toast({
      title: "Application Submitted",
      description:
        "Your seller application has been submitted successfully. We'll review your information and get back to you soon.",
    })

    // Reset form and go to success step
    setStep(4)
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Toaster />

      <div className="flex flex-col items-center text-center space-y-4 mb-12">
        <div className="flex items-center gap-2">
          <Store className="h-6 w-6 text-primary" />
          <h1 className="text-3xl font-bold tracking-tight">Sell on ShopHub</h1>
        </div>
        <p className="text-muted-foreground max-w-[700px] md:text-lg">
          Join thousands of sellers and reach millions of customers worldwide.
        </p>
      </div>

      {step < 4 ? (
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between mb-8">
            <div className="flex items-center">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 1 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
              >
                1
              </div>
              <span className="ml-2 font-medium">Business Info</span>
            </div>
            <div className="flex items-center">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 2 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
              >
                2
              </div>
              <span className="ml-2 font-medium">Address & Details</span>
            </div>
            <div className="flex items-center">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 3 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
              >
                3
              </div>
              <span className="ml-2 font-medium">Products & Terms</span>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>
                {step === 1 ? "Business Information" : step === 2 ? "Address & Business Details" : "Products & Terms"}
              </CardTitle>
              <CardDescription>
                {step === 1
                  ? "Tell us about your business and contact information"
                  : step === 2
                    ? "Provide your address and business details"
                    : "Select product categories and review our terms"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {step === 1 && (
                <div className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Business Information</h3>

                    <div className="space-y-2">
                      <Label htmlFor="businessName">
                        Business Name <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="businessName"
                        name="businessName"
                        value={formData.businessName}
                        onChange={handleInputChange}
                        placeholder="Your business name"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="businessEmail">
                        Business Email <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="businessEmail"
                        name="businessEmail"
                        type="email"
                        value={formData.businessEmail}
                        onChange={handleInputChange}
                        placeholder="business@example.com"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="businessPhone">Business Phone</Label>
                        <Input
                          id="businessPhone"
                          name="businessPhone"
                          value={formData.businessPhone}
                          onChange={handleInputChange}
                          placeholder="(123) 456-7890"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="businessWebsite">Business Website</Label>
                        <Input
                          id="businessWebsite"
                          name="businessWebsite"
                          value={formData.businessWebsite}
                          onChange={handleInputChange}
                          placeholder="https://yourbusiness.com"
                        />
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Primary Contact</h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">
                          First Name <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="firstName"
                          name="firstName"
                          value={formData.firstName}
                          onChange={handleInputChange}
                          placeholder="John"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">
                          Last Name <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="lastName"
                          name="lastName"
                          value={formData.lastName}
                          onChange={handleInputChange}
                          placeholder="Doe"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">
                        Email <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="john.doe@example.com"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="(123) 456-7890"
                      />
                    </div>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Business Address</h3>

                    <div className="space-y-2">
                      <Label htmlFor="address">
                        Street Address <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="address"
                        name="address"
                        value={formData.address}
                        onChange={handleInputChange}
                        placeholder="123 Main St"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="city">
                          City <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="city"
                          name="city"
                          value={formData.city}
                          onChange={handleInputChange}
                          placeholder="New York"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="state">
                          State/Province <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="state"
                          name="state"
                          value={formData.state}
                          onChange={handleInputChange}
                          placeholder="NY"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="zip">
                          ZIP/Postal Code <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="zip"
                          name="zip"
                          value={formData.zip}
                          onChange={handleInputChange}
                          placeholder="10001"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="country">
                          Country <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="country"
                          name="country"
                          value={formData.country}
                          onChange={handleInputChange}
                          placeholder="United States"
                        />
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Business Details</h3>

                    <div className="space-y-2">
                      <Label htmlFor="businessType">
                        Business Type <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="businessType"
                        name="businessType"
                        value={formData.businessType}
                        onChange={handleInputChange}
                        placeholder="e.g., Sole Proprietorship, LLC, Corporation"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="taxId">Tax ID / Business Registration Number</Label>
                      <Input
                        id="taxId"
                        name="taxId"
                        value={formData.taxId}
                        onChange={handleInputChange}
                        placeholder="Tax ID or business registration number"
                      />
                    </div>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Product Categories</h3>
                    <p className="text-sm text-muted-foreground">
                      Select the categories that best describe the products you plan to sell{" "}
                      <span className="text-red-500">*</span>
                    </p>

                    <div className="grid grid-cols-2 gap-4">
                      {[
                        "Electronics",
                        "Clothing",
                        "Home & Kitchen",
                        "Beauty",
                        "Books",
                        "Toys & Games",
                        "Sports & Outdoors",
                        "Jewelry",
                        "Health & Wellness",
                        "Automotive",
                      ].map((category) => (
                        <div key={category} className="flex items-center space-x-2">
                          <Checkbox
                            id={`category-${category}`}
                            checked={formData.productCategories.includes(category)}
                            onCheckedChange={(checked) => handleCategoryToggle(category)}
                          />
                          <Label htmlFor={`category-${category}`}>{category}</Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Terms & Conditions</h3>

                    <div className="rounded-md border p-4 bg-muted/50 max-h-[200px] overflow-y-auto">
                      <div className="text-sm text-muted-foreground">
                        <p className="mb-4">
                          By selling on ShopHub, you agree to our Seller Terms of Service, which include:
                        </p>
                        <ul className="list-disc pl-5 space-y-2">
                          <li>Maintaining accurate product listings and inventory</li>
                          <li>Processing and shipping orders in a timely manner</li>
                          <li>Providing excellent customer service</li>
                          <li>Complying with all applicable laws and regulations</li>
                          <li>Paying all applicable fees and commissions</li>
                          <li>Adhering to our community guidelines and policies</li>
                        </ul>
                        <p className="mt-4">
                          ShopHub charges a 5% commission on each sale, plus a $0.30 transaction fee. Additional fees
                          may apply for premium services and promotions.
                        </p>
                        <p className="mt-4">
                          You can cancel your seller account at any time, subject to fulfilling any outstanding orders
                          and obligations.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="agreeTerms"
                        checked={formData.agreeTerms}
                        onCheckedChange={(checked) => handleCheckboxChange("agreeTerms", checked === true)}
                      />
                      <Label htmlFor="agreeTerms" className="text-sm">
                        I agree to the{" "}
                        <Link href="/terms" className="text-primary hover:underline">
                          Terms of Service
                        </Link>{" "}
                        and{" "}
                        <Link href="/privacy" className="text-primary hover:underline">
                          Privacy Policy
                        </Link>{" "}
                        <span className="text-red-500">*</span>
                      </Label>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              {step > 1 ? (
                <Button variant="outline" onClick={handlePrevStep}>
                  Back
                </Button>
              ) : (
                <div></div>
              )}
              <Button onClick={handleNextStep}>{step < 3 ? "Continue" : "Submit Application"}</Button>
            </CardFooter>
          </Card>
        </div>
      ) : (
        <div className="max-w-2xl mx-auto text-center">
          <div className="mb-6 flex justify-center">
            <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center">
              <CheckCircle2 className="h-10 w-10 text-primary" />
            </div>
          </div>
          <h2 className="text-2xl font-bold mb-4">Application Submitted Successfully!</h2>
          <p className="text-muted-foreground mb-8">
            Thank you for applying to become a seller on ShopHub. We've received your application and will review it
            shortly. You'll receive an email at {formData.email} with the next steps.
          </p>
          <div className="bg-muted p-6 rounded-lg mb-8">
            <h3 className="font-semibold mb-2">What happens next?</h3>
            <ol className="text-left text-sm text-muted-foreground space-y-2">
              <li>1. Our team will review your application (typically within 1-2 business days)</li>
              <li>2. You'll receive an email with the approval status</li>
              <li>3. If approved, you'll get access to the Seller Dashboard</li>
              <li>4. Set up your store profile and start listing products</li>
              <li>5. Start selling and growing your business on ShopHub!</li>
            </ol>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild>
              <Link href="/">Return to Homepage</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/contact">Contact Support</Link>
            </Button>
          </div>
        </div>
      )}

      {step < 4 && (
        <div className="max-w-6xl mx-auto mt-16">
          <h2 className="text-2xl font-bold tracking-tight text-center mb-8">Why Sell on ShopHub?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <div className="p-2 w-fit rounded-full bg-primary/10 mb-2">
                  <Users className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Reach Millions of Customers</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Connect with our global customer base and expand your business reach. Our marketplace attracts
                  millions of shoppers every month.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="p-2 w-fit rounded-full bg-primary/10 mb-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Powerful Selling Tools</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Access analytics, inventory management, and marketing tools designed to help you grow your business
                  and increase sales.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="p-2 w-fit rounded-full bg-primary/10 mb-2">
                  <CreditCard className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Secure Payments</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Receive payments securely and on time. We handle payment processing and provide protection for both
                  sellers and buyers.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="mt-16 bg-muted rounded-lg p-8">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-xl font-bold mb-4">Seller Success Stories</h3>
                <div className="space-y-4">
                  <div className="bg-background rounded-lg p-4">
                    <p className="italic text-muted-foreground mb-2">
                      "Since joining ShopHub, our sales have increased by 200%. The platform's tools and customer reach
                      have been game-changers for our business."
                    </p>
                    <p className="font-medium">- Sarah J., Electronics Seller</p>
                  </div>
                  <div className="bg-background rounded-lg p-4">
                    <p className="italic text-muted-foreground mb-2">
                      "As a small business owner, ShopHub has given me the opportunity to reach customers I never could
                      have on my own. The seller support team is amazing!"
                    </p>
                    <p className="font-medium">- Michael T., Handmade Goods</p>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-4">Seller Resources</h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <BarChart className="h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h4 className="font-medium">Seller University</h4>
                      <p className="text-sm text-muted-foreground">
                        Free courses and resources to help you succeed as a seller.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Package className="h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h4 className="font-medium">Fulfillment Services</h4>
                      <p className="text-sm text-muted-foreground">
                        Let us handle storage, packing, and shipping for your products.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Truck className="h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h4 className="font-medium">Shipping Program</h4>
                      <p className="text-sm text-muted-foreground">
                        Discounted shipping rates and integrated shipping solutions.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <HelpCircle className="h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h4 className="font-medium">Seller Support</h4>
                      <p className="text-sm text-muted-foreground">
                        Dedicated support team to help you resolve issues quickly.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

