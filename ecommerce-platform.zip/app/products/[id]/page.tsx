"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Star, Truck, ShieldCheck, ShoppingCart, Heart, Share2, CheckCircle2, ThumbsUp, ThumbsDown } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import LoadingSpinner from "@/components/loading-spinner"
import { mockProducts } from "@/lib/mock-data"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Define product categories
const categories = [
  { id: "electronics", name: "Electronics", icon: "💻" },
  { id: "mens-clothing", name: "Men's Clothing", icon: "👔" },
  { id: "womens-clothing", name: "Women's Clothing", icon: "👗" },
  { id: "jewelry", name: "Jewelry & Watches", icon: "💍" },
  { id: "home", name: "Home & Kitchen", icon: "🏠" },
  { id: "beauty", name: "Beauty & Personal Care", icon: "💄" },
  { id: "sports", name: "Sports & Outdoors", icon: "🏀" },
  { id: "toys", name: "Toys & Games", icon: "🎮" },
]

// Extend mock products with categories
const categorizedProducts = mockProducts.map((product) => {
  let category = "electronics"

  if (product.id % 8 === 0) category = "mens-clothing"
  else if (product.id % 7 === 0) category = "womens-clothing"
  else if (product.id % 6 === 0) category = "jewelry"
  else if (product.id % 5 === 0) category = "home"
  else if (product.id % 4 === 0) category = "beauty"
  else if (product.id % 3 === 0) category = "sports"
  else if (product.id % 2 === 0) category = "toys"

  return {
    ...product,
    category,
  }
})

// Define product images for different categories
const productImages = {
  electronics: [
    "/placeholder.svg?height=600&width=600&text=Electronics+Image+1",
    "/placeholder.svg?height=600&width=600&text=Electronics+Image+2",
    "/placeholder.svg?height=600&width=600&text=Electronics+Image+3",
  ],
  "mens-clothing": [
    "/placeholder.svg?height=600&width=600&text=Mens+Clothing+Image+1",
    "/placeholder.svg?height=600&width=600&text=Mens+Clothing+Image+2",
    "/placeholder.svg?height=600&width=600&text=Mens+Clothing+Image+3",
  ],
  "womens-clothing": [
    "/placeholder.svg?height=600&width=600&text=Womens+Clothing+Image+1",
    "/placeholder.svg?height=600&width=600&text=Womens+Clothing+Image+2",
    "/placeholder.svg?height=600&width=600&text=Womens+Clothing+Image+3",
  ],
  jewelry: [
    "/placeholder.svg?height=600&width=600&text=Jewelry+Image+1",
    "/placeholder.svg?height=600&width=600&text=Jewelry+Image+2",
    "/placeholder.svg?height=600&width=600&text=Jewelry+Image+3",
  ],
  home: [
    "/placeholder.svg?height=600&width=600&text=Home+Image+1",
    "/placeholder.svg?height=600&width=600&text=Home+Image+2",
    "/placeholder.svg?height=600&width=600&text=Home+Image+3",
  ],
  beauty: [
    "/placeholder.svg?height=600&width=600&text=Beauty+Image+1",
    "/placeholder.svg?height=600&width=600&text=Beauty+Image+2",
    "/placeholder.svg?height=600&width=600&text=Beauty+Image+3",
  ],
  sports: [
    "/placeholder.svg?height=600&width=600&text=Sports+Image+1",
    "/placeholder.svg?height=600&width=600&text=Sports+Image+2",
    "/placeholder.svg?height=600&width=600&text=Sports+Image+3",
  ],
  toys: [
    "/placeholder.svg?height=600&width=600&text=Toys+Image+1",
    "/placeholder.svg?height=600&width=600&text=Toys+Image+2",
    "/placeholder.svg?height=600&width=600&text=Toys+Image+3",
  ],
}

// Get product images based on category
const getProductImages = (category: string) => {
  return productImages[category as keyof typeof productImages] || productImages.electronics
}

export default function ProductPage({ params }: { params: { id: string } }) {
  const [isLoading, setIsLoading] = useState(true)
  const [product, setProduct] = useState<any>(null)
  const [selectedImage, setSelectedImage] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [relatedProducts, setRelatedProducts] = useState<any[]>([])
  const [isAddingToCart, setIsAddingToCart] = useState(false)
  const [addedToCart, setAddedToCart] = useState(false)
  const [isAddingToWishlist, setIsAddingToWishlist] = useState(false)
  const [addedToWishlist, setAddedToWishlist] = useState(false)
  const [reviewText, setReviewText] = useState("")
  const [reviewRating, setReviewRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)
  const [feedbackText, setFeedbackText] = useState("")
  const [deliveryRating, setDeliveryRating] = useState(0)

  // Load product data
  useEffect(() => {
    const timer = setTimeout(() => {
      const productId = Number.parseInt(params.id)
      const foundProduct = categorizedProducts.find((p) => p.id === productId)

      if (foundProduct) {
        // Add additional product details
        const enhancedProduct = {
          ...foundProduct,
          images: getProductImages(foundProduct.category),
          description:
            "This is a detailed description of the product. It includes information about the features, materials, and other important details that customers might want to know before making a purchase.",
          features: [
            "Feature 1: Lorem ipsum dolor sit amet",
            "Feature 2: Consectetur adipiscing elit",
            "Feature 3: Sed do eiusmod tempor incididunt",
            "Feature 4: Ut labore et dolore magna aliqua",
          ],
          specifications: {
            Dimensions: "10 x 5 x 2 inches",
            Weight: "1.5 lbs",
            Material: "Premium quality materials",
            Color: foundProduct.color,
            Warranty: "1 year",
          },
          reviews: [
            {
              id: 1,
              name: "Customer Name 1",
              rating: 5,
              date: "2023-05-15",
              text: "Great product and excellent quality. Would definitely recommend!",
              avatar: "/placeholder.svg?height=40&width=40&text=User+1",
              helpful: 12,
              unhelpful: 2,
            },
            {
              id: 2,
              name: "Customer Name 2",
              rating: 4,
              date: "2023-04-22",
              text: "Good product overall. The quality is high but a bit pricey.",
              avatar: "/placeholder.svg?height=40&width=40&text=User+2",
              helpful: 8,
              unhelpful: 1,
            },
            {
              id: 3,
              name: "Customer Name 3",
              rating: 5,
              date: "2023-03-10",
              text: "Excellent customer service. The product arrived quickly and in perfect condition.",
              avatar: "/placeholder.svg?height=40&width=40&text=User+3",
              helpful: 15,
              unhelpful: 0,
            },
          ],
          feedback: [
            {
              id: 1,
              name: "John D.",
              date: "2023-06-10",
              text: "The delivery was super fast! Product was well packaged.",
              rating: 5,
              avatar: "/placeholder.svg?height=40&width=40&text=John",
            },
            {
              id: 2,
              name: "Sarah M.",
              date: "2023-05-28",
              text: "Delivery was on time. The product matches the description perfectly.",
              rating: 4,
              avatar: "/placeholder.svg?height=40&width=40&text=Sarah",
            },
          ],
          categoryName: categories.find((c) => c.id === foundProduct.category)?.name || "Products",
        }

        setProduct(enhancedProduct)

        // Get related products from the same category
        const related = categorizedProducts
          .filter((p) => p.category === foundProduct.category && p.id !== productId)
          .slice(0, 4)

        setRelatedProducts(related)
      }

      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [params.id])

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number.parseInt(e.target.value)
    if (!isNaN(value) && value > 0) {
      setQuantity(value)
    }
  }

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  const increaseQuantity = () => {
    setQuantity(quantity + 1)
  }

  const addToCart = async () => {
    setIsAddingToCart(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setIsAddingToCart(false)
    setAddedToCart(true)

    // Reset added to cart status after 3 seconds
    setTimeout(() => {
      setAddedToCart(false)
    }, 3000)

    toast({
      title: "Added to Cart",
      description: `${product.name} (Qty: ${quantity}) has been added to your cart.`,
      action: (
        <Link href="/cart">
          <Button variant="outline" size="sm">
            View Cart
          </Button>
        </Link>
      ),
    })
  }

  const addToWishlist = async () => {
    setIsAddingToWishlist(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 800))

    setIsAddingToWishlist(false)
    setAddedToWishlist(true)

    toast({
      title: "Added to Wishlist",
      description: `${product.name} has been added to your wishlist.`,
      action: (
        <Link href="/wishlist">
          <Button variant="outline" size="sm">
            View Wishlist
          </Button>
        </Link>
      ),
    })
  }

  const submitReview = (e: React.FormEvent) => {
    e.preventDefault()

    if (reviewRating === 0) {
      toast({
        title: "Rating Required",
        description: "Please select a rating before submitting your review.",
        variant: "destructive",
      })
      return
    }

    toast({
      title: "Review Submitted",
      description: "Thank you for your review! It will be published after moderation.",
    })

    setReviewText("")
    setReviewRating(0)
  }

  const submitFeedback = (e: React.FormEvent) => {
    e.preventDefault()

    if (deliveryRating === 0) {
      toast({
        title: "Rating Required",
        description: "Please select a delivery rating before submitting your feedback.",
        variant: "destructive",
      })
      return
    }

    toast({
      title: "Feedback Submitted",
      description: "Thank you for your feedback! It helps us improve our service.",
    })

    setFeedbackText("")
    setDeliveryRating(0)
  }

  const markHelpful = (reviewId: number, helpful: boolean) => {
    toast({
      title: helpful ? "Marked as Helpful" : "Marked as Unhelpful",
      description: "Thank you for your feedback on this review.",
    })
  }

  if (isLoading) {
    return (
      <div className="container px-4 py-8 md:px-6 md:py-12">
        <div className="flex items-center gap-2 mb-6">
          <Skeleton className="h-4 w-4" />
          <Skeleton className="h-4 w-24" />
        </div>
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <Skeleton className="aspect-square w-full rounded-lg" />
            <div className="grid grid-cols-3 gap-2">
              <Skeleton className="aspect-square w-full rounded-lg" />
              <Skeleton className="aspect-square w-full rounded-lg" />
              <Skeleton className="aspect-square w-full rounded-lg" />
            </div>
          </div>
          <div className="space-y-6">
            <div>
              <Skeleton className="h-8 w-3/4 mb-2" />
              <div className="flex items-center gap-4 mt-2">
                <Skeleton className="h-4 w-24" />
              </div>
            </div>
            <Skeleton className="h-8 w-24" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <div className="space-y-2">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="container px-4 py-8 md:px-6 md:py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The product you are looking for does not exist or has been removed.
        </p>
        <Button asChild>
          <Link href="/products">Back to Products</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Toaster />

      <div className="flex flex-wrap items-center gap-2 mb-6 text-sm">
        <Link href="/" className="text-muted-foreground hover:text-foreground">
          Home
        </Link>
        <span className="text-muted-foreground">/</span>
        <Link href="/products" className="text-muted-foreground hover:text-foreground">
          Products
        </Link>
        <span className="text-muted-foreground">/</span>
        <Link href={`/category/${product.category}`} className="text-muted-foreground hover:text-foreground">
          {product.categoryName}
        </Link>
        <span className="text-muted-foreground">/</span>
        <span className="text-foreground">{product.name}</span>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <div className="relative aspect-square overflow-hidden rounded-lg border">
            <Image
              src={product.images[selectedImage] || "/placeholder.svg"}
              alt={product.name}
              fill
              className="object-cover"
              priority
            />
            {product.onSale && <Badge className="absolute top-2 right-2 bg-red-500 hover:bg-red-600">Sale</Badge>}
          </div>
          <div className="grid grid-cols-3 gap-2">
            {product.images.map((image: string, index: number) => (
              <div
                key={index}
                className={`relative aspect-square overflow-hidden rounded-lg border cursor-pointer ${selectedImage === index ? "ring-2 ring-primary" : ""}`}
                onClick={() => setSelectedImage(index)}
              >
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`${product.name} - Image ${index + 1}`}
                  fill
                  className="object-cover"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">{product.name}</h1>
            <div className="flex items-center gap-4 mt-2">
              <div className="flex items-center">
                {Array(5)
                  .fill(0)
                  .map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(product.rating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                      }`}
                    />
                  ))}
                <span className="ml-2 text-sm text-muted-foreground">
                  {product.rating.toFixed(1)} ({product.reviews.length} reviews)
                </span>
              </div>
              <span className="text-sm text-muted-foreground">Brand: {product.brand}</span>
            </div>
          </div>

          <div>
            {product.onSale ? (
              <div className="flex items-center gap-2">
                <p className="text-3xl font-bold">${product.salePrice.toFixed(2)}</p>
                <p className="text-lg text-muted-foreground line-through">${product.price.toFixed(2)}</p>
                <Badge className="ml-2 bg-red-500 hover:bg-red-600">
                  Save ${(product.price - product.salePrice).toFixed(2)}
                </Badge>
              </div>
            ) : (
              <p className="text-3xl font-bold">${product.price.toFixed(2)}</p>
            )}
            <p className="text-sm text-muted-foreground mt-1">
              {product.inStock ? (
                <span className="text-green-600 font-medium">In Stock</span>
              ) : (
                <span className="text-red-600 font-medium">Out of Stock</span>
              )}
            </p>
          </div>

          <p className="text-muted-foreground">{product.description}</p>

          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full border" style={{ backgroundColor: product.colorHex }} />
              <span>Color: {product.color}</span>
            </div>

            <div className="flex items-center gap-4">
              <span>Quantity:</span>
              <div className="flex items-center">
                <Button variant="outline" size="icon" className="h-8 w-8 rounded-r-none" onClick={decreaseQuantity}>
                  <span>-</span>
                </Button>
                <Input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={handleQuantityChange}
                  className="h-8 w-12 rounded-none text-center [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                />
                <Button variant="outline" size="icon" className="h-8 w-8 rounded-l-none" onClick={increaseQuantity}>
                  <span>+</span>
                </Button>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Button className="w-full" disabled={isAddingToCart || !product.inStock} onClick={addToCart}>
              {isAddingToCart ? (
                <>
                  <LoadingSpinner size="small" />
                  <span className="ml-2">Adding to Cart...</span>
                </>
              ) : addedToCart ? (
                <>
                  <CheckCircle2 className="h-5 w-5 mr-2" />
                  Added to Cart
                </>
              ) : (
                <>
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Add to Cart
                </>
              )}
            </Button>
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                className="w-full"
                onClick={addToWishlist}
                disabled={isAddingToWishlist || addedToWishlist}
              >
                {isAddingToWishlist ? (
                  <>
                    <LoadingSpinner size="small" />
                    <span className="ml-2">Adding...</span>
                  </>
                ) : addedToWishlist ? (
                  <>
                    <Heart className="h-5 w-5 mr-2 fill-red-500 text-red-500" />
                    In Wishlist
                  </>
                ) : (
                  <>
                    <Heart className="h-5 w-5 mr-2" />
                    Wishlist
                  </>
                )}
              </Button>
              <Button variant="outline" className="w-full">
                <Share2 className="h-5 w-5 mr-2" />
                Share
              </Button>
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t">
            <div className="flex items-center gap-2">
              <Truck className="h-5 w-5 text-muted-foreground" />
              <span className="text-sm">Free shipping on orders over $50</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-muted-foreground" />
              <span className="text-sm">30-day money-back guarantee</span>
            </div>
          </div>

          <div className="pt-4 text-sm text-muted-foreground">
            <p>
              Sold and shipped by <span className="font-medium text-foreground">Rahul Jha</span>
            </p>
          </div>
        </div>
      </div>

      <div className="mt-12">
        <Tabs defaultValue="details">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="specifications">Specifications</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
            <TabsTrigger value="feedback">Delivery & Product Feedback</TabsTrigger>
          </TabsList>
          <TabsContent value="details" className="mt-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Product Features</h3>
              <ul className="list-disc pl-5 space-y-2">
                {product.features.map((feature: string, index: number) => (
                  <li key={index}>{feature}</li>
                ))}
              </ul>
            </div>
          </TabsContent>
          <TabsContent value="specifications" className="mt-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Technical Specifications</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(product.specifications).map(([key, value]) => (
                  <div key={key} className="flex justify-between py-2 border-b">
                    <span className="font-medium">{key}</span>
                    <span className="text-muted-foreground">{value as string}</span>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
          <TabsContent value="reviews" className="mt-6">
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h3 className="text-lg font-semibold">Customer Reviews</h3>
                  <div className="flex items-center mt-1">
                    <div className="flex">
                      {Array(5)
                        .fill(0)
                        .map((_, i) => (
                          <Star
                            key={i}
                            className={`h-5 w-5 ${
                              i < Math.floor(product.rating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                            }`}
                          />
                        ))}
                    </div>
                    <span className="ml-2 font-medium">
                      {product.rating.toFixed(1)} ({product.reviews.length} reviews)
                    </span>
                  </div>
                </div>
                <Button>Write a Review</Button>
              </div>

              <Card>
                <CardContent className="pt-6">
                  <h4 className="font-semibold mb-4">Write Your Review</h4>
                  <form onSubmit={submitReview} className="space-y-4">
                    <div>
                      <div className="flex items-center mb-2">
                        <span className="mr-2">Rating:</span>
                        <div className="flex">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <Star
                                key={i}
                                className={`h-6 w-6 cursor-pointer ${
                                  i < (hoveredRating || reviewRating)
                                    ? "text-yellow-500 fill-yellow-500"
                                    : "text-gray-300"
                                }`}
                                onMouseEnter={() => setHoveredRating(i + 1)}
                                onMouseLeave={() => setHoveredRating(0)}
                                onClick={() => setReviewRating(i + 1)}
                              />
                            ))}
                        </div>
                      </div>
                      <Textarea
                        placeholder="Share your experience with this product..."
                        value={reviewText}
                        onChange={(e) => setReviewText(e.target.value)}
                        className="min-h-[100px]"
                      />
                    </div>
                    <Button type="submit" disabled={!reviewRating || !reviewText.trim()}>
                      Submit Review
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <div className="space-y-4">
                {product.reviews.map((review: any) => (
                  <Card key={review.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center">
                          <Avatar className="h-10 w-10 mr-3">
                            <AvatarImage src={review.avatar} alt={review.name} />
                            <AvatarFallback>{review.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="font-semibold">{review.name}</h4>
                            <div className="flex items-center">
                              <div className="flex">
                                {Array(5)
                                  .fill(0)
                                  .map((_, i) => (
                                    <Star
                                      key={i}
                                      className={`h-4 w-4 ${
                                        i < review.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                      }`}
                                    />
                                  ))}
                              </div>
                              <span className="text-xs ml-2 text-muted-foreground">Verified Purchase</span>
                            </div>
                          </div>
                        </div>
                        <span className="text-sm text-muted-foreground">{review.date}</span>
                      </div>
                      <p className="text-muted-foreground mb-4">{review.text}</p>
                      <div className="flex items-center gap-4 text-sm">
                        <span>Was this review helpful?</span>
                        <button
                          className="flex items-center gap-1 hover:text-primary"
                          onClick={() => markHelpful(review.id, true)}
                        >
                          <ThumbsUp className="h-4 w-4" />
                          <span>{review.helpful}</span>
                        </button>
                        <button
                          className="flex items-center gap-1 hover:text-primary"
                          onClick={() => markHelpful(review.id, false)}
                        >
                          <ThumbsDown className="h-4 w-4" />
                          <span>{review.unhelpful}</span>
                        </button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>
          <TabsContent value="feedback" className="mt-6">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Delivery & Product Feedback</h3>
                <p className="text-muted-foreground">
                  Share your experience with the delivery service and the condition of the product when it arrived.
                </p>
              </div>

              <Card>
                <CardContent className="pt-6">
                  <h4 className="font-semibold mb-4">Submit Your Feedback</h4>
                  <form onSubmit={submitFeedback} className="space-y-4">
                    <div>
                      <div className="flex items-center mb-2">
                        <span className="mr-2">Delivery Rating:</span>
                        <div className="flex">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <Star
                                key={i}
                                className={`h-6 w-6 cursor-pointer ${
                                  i < deliveryRating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                }`}
                                onClick={() => setDeliveryRating(i + 1)}
                              />
                            ))}
                        </div>
                      </div>
                      <Textarea
                        placeholder="How was your delivery experience? Was the product in good condition?"
                        value={feedbackText}
                        onChange={(e) => setFeedbackText(e.target.value)}
                        className="min-h-[100px]"
                      />
                    </div>
                    <Button type="submit" disabled={!deliveryRating || !feedbackText.trim()}>
                      Submit Feedback
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <div className="space-y-4">
                {product.feedback.map((feedback: any) => (
                  <Card key={feedback.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center">
                          <Avatar className="h-10 w-10 mr-3">
                            <AvatarImage src={feedback.avatar} alt={feedback.name} />
                            <AvatarFallback>{feedback.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="font-semibold">{feedback.name}</h4>
                            <div className="flex">
                              {Array(5)
                                .fill(0)
                                .map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`h-4 w-4 ${
                                      i < feedback.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                                    }`}
                                  />
                                ))}
                            </div>
                          </div>
                        </div>
                        <span className="text-sm text-muted-foreground">{feedback.date}</span>
                      </div>
                      <p className="text-muted-foreground">{feedback.text}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold tracking-tight mb-6">Related Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {relatedProducts.map((relatedProduct) => (
            <Card key={relatedProduct.id} className="overflow-hidden h-full transition-all hover:shadow-lg">
              <Link href={`/products/${relatedProduct.id}`}>
                <div className="relative h-48 md:h-60">
                  <Image
                    src={getProductImages(relatedProduct.category)[0] || "/placeholder.svg"}
                    alt={relatedProduct.name}
                    fill
                    className="object-cover"
                  />
                  {relatedProduct.onSale && (
                    <Badge className="absolute top-2 right-2 bg-red-500 hover:bg-red-600">Sale</Badge>
                  )}
                </div>
              </Link>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-xs text-muted-foreground">{relatedProduct.brand}</p>
                  <div className="flex items-center">
                    <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                    <span className="text-xs ml-1">{relatedProduct.rating.toFixed(1)}</span>
                  </div>
                </div>
                <Link href={`/products/${relatedProduct.id}`}>
                  <h3 className="font-medium text-sm line-clamp-1 hover:underline">{relatedProduct.name}</h3>
                </Link>
                <div className="flex items-center gap-2 mt-1">
                  {relatedProduct.onSale ? (
                    <>
                      <span className="font-medium text-sm">${relatedProduct.salePrice.toFixed(2)}</span>
                      <span className="text-xs text-muted-foreground line-through">
                        ${relatedProduct.price.toFixed(2)}
                      </span>
                    </>
                  ) : (
                    <span className="font-medium text-sm">${relatedProduct.price.toFixed(2)}</span>
                  )}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full mt-3"
                  onClick={() => {
                    toast({
                      title: "Added to Cart",
                      description: `${relatedProduct.name} has been added to your cart.`,
                      action: (
                        <Link href="/cart">
                          <Button variant="outline" size="sm">
                            View Cart
                          </Button>
                        </Link>
                      ),
                    })
                  }}
                >
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Add to Cart
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}

