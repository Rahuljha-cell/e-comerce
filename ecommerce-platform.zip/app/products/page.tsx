"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import ProductFilters from "@/components/product-filters"
import ProductSorting from "@/components/product-sorting"
import { Badge } from "@/components/ui/badge"
import { Filter, X } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { mockProducts } from "@/lib/mock-data"

// Define types
type SortOption = "featured" | "newest" | "price-low" | "price-high" | "best-selling" | "rating"
type FilterState = {
  categories: string[]
  brands: string[]
  priceRange: [number, number]
  colors: string[]
  ratings: number[]
  onSale: boolean
  inStock: boolean
}

export default function ProductsPage() {
  // State for products and filtering/sorting
  const [products, setProducts] = useState(mockProducts)
  const [filteredProducts, setFilteredProducts] = useState(mockProducts)
  const [sortOption, setSortOption] = useState<SortOption>("featured")
  const [isFilterOpen, setIsFilterOpen] = useState(false)
  const [activeFiltersCount, setActiveFiltersCount] = useState(0)

  // Get min and max prices from products
  const minPrice = Math.min(...mockProducts.map((p) => p.price))
  const maxPrice = Math.max(...mockProducts.map((p) => p.price))

  // Initial filter state
  const [filters, setFilters] = useState<FilterState>({
    categories: [],
    brands: [],
    priceRange: [minPrice, maxPrice],
    colors: [],
    ratings: [],
    onSale: false,
    inStock: false,
  })

  // Extract unique values for filter options
  const allCategories = [...new Set(mockProducts.map((p) => p.category))]
  const allBrands = [...new Set(mockProducts.map((p) => p.brand))]
  const allColors = [...new Set(mockProducts.map((p) => p.color))]

  // Apply filters and sorting
  useEffect(() => {
    let result = [...mockProducts]

    // Apply category filter
    if (filters.categories.length > 0) {
      result = result.filter((product) => filters.categories.includes(product.category))
    }

    // Apply brand filter
    if (filters.brands.length > 0) {
      result = result.filter((product) => filters.brands.includes(product.brand))
    }

    // Apply color filter
    if (filters.colors.length > 0) {
      result = result.filter((product) => filters.colors.includes(product.color))
    }

    // Apply price range filter
    result = result.filter(
      (product) => product.price >= filters.priceRange[0] && product.price <= filters.priceRange[1],
    )

    // Apply rating filter
    if (filters.ratings.length > 0) {
      result = result.filter((product) => filters.ratings.includes(Math.floor(product.rating)))
    }

    // Apply sale filter
    if (filters.onSale) {
      result = result.filter((product) => product.onSale)
    }

    // Apply stock filter
    if (filters.inStock) {
      result = result.filter((product) => product.inStock)
    }

    // Apply sorting
    result = sortProducts(result, sortOption)

    setFilteredProducts(result)

    // Count active filters
    let count = 0
    if (filters.categories.length) count++
    if (filters.brands.length) count++
    if (filters.colors.length) count++
    if (filters.ratings.length) count++
    if (filters.onSale) count++
    if (filters.inStock) count++
    if (filters.priceRange[0] > minPrice || filters.priceRange[1] < maxPrice) count++

    setActiveFiltersCount(count)
  }, [filters, sortOption])

  // Sort products based on selected option
  const sortProducts = (products: typeof mockProducts, option: SortOption) => {
    switch (option) {
      case "featured":
        return [...products].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0))
      case "newest":
        return [...products].sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime())
      case "price-low":
        return [...products].sort((a, b) => a.price - b.price)
      case "price-high":
        return [...products].sort((a, b) => b.price - a.price)
      case "best-selling":
        return [...products].sort((a, b) => b.salesCount - a.salesCount)
      case "rating":
        return [...products].sort((a, b) => b.rating - a.rating)
      default:
        return products
    }
  }

  // Update filter state
  const handleFilterChange = (filterType: keyof FilterState, value: any) => {
    setFilters((prev) => ({
      ...prev,
      [filterType]: value,
    }))
  }

  // Toggle a single value in an array filter
  const toggleArrayFilter = (filterType: "categories" | "brands" | "colors" | "ratings", value: string | number) => {
    setFilters((prev) => {
      const currentValues = prev[filterType]
      const newValues = currentValues.includes(value as never)
        ? currentValues.filter((v) => v !== value)
        : [...currentValues, value]

      return {
        ...prev,
        [filterType]: newValues,
      }
    })
  }

  // Toggle boolean filters
  const toggleBooleanFilter = (filterType: "onSale" | "inStock") => {
    setFilters((prev) => ({
      ...prev,
      [filterType]: !prev[filterType],
    }))
  }

  // Clear all filters
  const clearAllFilters = () => {
    setFilters({
      categories: [],
      brands: [],
      priceRange: [minPrice, maxPrice],
      colors: [],
      ratings: [],
      onSale: false,
      inStock: false,
    })
    setSortOption("featured")
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Desktop Filters */}
        <aside className="w-full md:w-64 shrink-0 hidden md:block">
          <ProductFilters
            filters={filters}
            allCategories={allCategories}
            allBrands={allBrands}
            allColors={allColors}
            minPrice={minPrice}
            maxPrice={maxPrice}
            onFilterChange={handleFilterChange}
            toggleArrayFilter={toggleArrayFilter}
            toggleBooleanFilter={toggleBooleanFilter}
            clearAllFilters={clearAllFilters}
          />
        </aside>

        <div className="flex-1">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Products</h1>
              <p className="text-muted-foreground">
                Showing {filteredProducts.length} of {mockProducts.length} products
              </p>
            </div>

            {/* Mobile Filter Button */}
            <div className="flex items-center gap-2 md:hidden">
              <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    Filters
                    {activeFiltersCount > 0 && (
                      <Badge variant="secondary" className="ml-1">
                        {activeFiltersCount}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-full sm:max-w-md overflow-y-auto">
                  <div className="py-4">
                    <ProductFilters
                      filters={filters}
                      allCategories={allCategories}
                      allBrands={allBrands}
                      allColors={allColors}
                      minPrice={minPrice}
                      maxPrice={maxPrice}
                      onFilterChange={handleFilterChange}
                      toggleArrayFilter={toggleArrayFilter}
                      toggleBooleanFilter={toggleBooleanFilter}
                      clearAllFilters={clearAllFilters}
                      onClose={() => setIsFilterOpen(false)}
                    />
                  </div>
                </SheetContent>
              </Sheet>

              <ProductSorting sortOption={sortOption} onSortChange={setSortOption} />
            </div>

            {/* Desktop Sorting */}
            <div className="hidden md:block">
              <ProductSorting sortOption={sortOption} onSortChange={setSortOption} />
            </div>
          </div>

          {/* Active Filters Display */}
          {activeFiltersCount > 0 && (
            <div className="flex flex-wrap gap-2 mb-6">
              {filters.categories.length > 0 &&
                filters.categories.map((category) => (
                  <Badge key={category} variant="secondary" className="flex items-center gap-1">
                    Category: {category}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 p-0 ml-1"
                      onClick={() => toggleArrayFilter("categories", category)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}

              {filters.brands.length > 0 &&
                filters.brands.map((brand) => (
                  <Badge key={brand} variant="secondary" className="flex items-center gap-1">
                    Brand: {brand}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 p-0 ml-1"
                      onClick={() => toggleArrayFilter("brands", brand)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}

              {filters.colors.length > 0 &&
                filters.colors.map((color) => (
                  <Badge key={color} variant="secondary" className="flex items-center gap-1">
                    Color: {color}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 p-0 ml-1"
                      onClick={() => toggleArrayFilter("colors", color)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}

              {(filters.priceRange[0] > minPrice || filters.priceRange[1] < maxPrice) && (
                <Badge variant="secondary" className="flex items-center gap-1">
                  Price: ${filters.priceRange[0].toFixed(2)} - ${filters.priceRange[1].toFixed(2)}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 p-0 ml-1"
                    onClick={() => handleFilterChange("priceRange", [minPrice, maxPrice])}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              )}

              {filters.onSale && (
                <Badge variant="secondary" className="flex items-center gap-1">
                  On Sale
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 p-0 ml-1"
                    onClick={() => toggleBooleanFilter("onSale")}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              )}

              {filters.inStock && (
                <Badge variant="secondary" className="flex items-center gap-1">
                  In Stock
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 p-0 ml-1"
                    onClick={() => toggleBooleanFilter("inStock")}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              )}

              <Button variant="ghost" size="sm" className="text-xs" onClick={clearAllFilters}>
                Clear All
              </Button>
            </div>
          )}

          {/* Product Grid */}
          {filteredProducts.length === 0 ? (
            <div className="text-center py-12 border rounded-lg">
              <h3 className="text-lg font-medium mb-2">No products found</h3>
              <p className="text-muted-foreground mb-4">Try adjusting your filters to find what you're looking for.</p>
              <Button onClick={clearAllFilters}>Clear All Filters</Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <Link href={`/products/${product.id}`} key={product.id}>
                  <Card className="overflow-hidden h-full transition-all hover:shadow-lg">
                    <div className="relative h-60">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        fill
                        className="object-cover"
                      />
                      {product.onSale && (
                        <Badge className="absolute top-2 left-2 bg-red-500 hover:bg-red-600">Sale</Badge>
                      )}
                      {!product.inStock && (
                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                          <span className="text-white font-medium">Out of Stock</span>
                        </div>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-sm text-muted-foreground">{product.brand}</p>
                        <div className="flex items-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill="currentColor"
                            className="w-4 h-4 text-yellow-500"
                          >
                            <path
                              fillRule="evenodd"
                              d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z"
                              clipRule="evenodd"
                            />
                          </svg>
                          <span className="text-sm ml-1">{product.rating.toFixed(1)}</span>
                        </div>
                      </div>
                      <h3 className="font-semibold line-clamp-1">{product.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        {product.onSale ? (
                          <>
                            <span className="font-medium">${product.salePrice.toFixed(2)}</span>
                            <span className="text-sm text-muted-foreground line-through">
                              ${product.price.toFixed(2)}
                            </span>
                          </>
                        ) : (
                          <span className="font-medium">${product.price.toFixed(2)}</span>
                        )}
                      </div>
                      <div className="flex items-center gap-1 mt-2">
                        <div className="w-4 h-4 rounded-full border" style={{ backgroundColor: product.colorHex }} />
                        <span className="text-xs text-muted-foreground">{product.color}</span>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}

          {/* Pagination */}
          {filteredProducts.length > 0 && (
            <div className="flex justify-center mt-8">
              <Button variant="outline" className="mx-1">
                1
              </Button>
              <Button variant="outline" className="mx-1">
                2
              </Button>
              <Button variant="outline" className="mx-1">
                3
              </Button>
              <Button variant="outline" className="mx-1">
                Next
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

