"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { ArrowLeft, Star } from "lucide-react"
import { mockProducts } from "@/lib/mock-data"

export default function FeaturedProductsPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [featuredProducts, setFeaturedProducts] = useState<any[]>([])

  // Simulate loading state
  useEffect(() => {
    const timer = setTimeout(() => {
      // Filter featured products
      const featured = mockProducts.filter((product) => product.featured)
      setFeaturedProducts(featured)
      setIsLoading(false)
    }, 800)

    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Link href="/products" className="flex items-center text-sm mb-6 hover:underline">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to All Products
      </Link>

      <div className="flex flex-col items-center text-center space-y-4 mb-12">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Featured Products</h1>
        <p className="text-muted-foreground max-w-[700px]">
          Discover our handpicked selection of premium products, chosen for their exceptional quality and popularity.
        </p>
      </div>

      {/* Hero Featured Product */}
      {isLoading ? (
        <div className="mb-12">
          <Skeleton className="h-[400px] w-full rounded-lg" />
        </div>
      ) : (
        featuredProducts.length > 0 && (
          <div className="relative rounded-lg overflow-hidden mb-12">
            <div className="relative h-[400px] md:h-[500px]">
              <Image
                src={featuredProducts[0].image || "/placeholder.svg"}
                alt={featuredProducts[0].name}
                fill
                className="object-cover"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-6 md:p-8">
                <Badge className="w-fit mb-2 bg-primary hover:bg-primary">Featured</Badge>
                <h2 className="text-2xl md:text-3xl font-bold text-white mb-2">{featuredProducts[0].name}</h2>
                <p className="text-white/80 mb-4 max-w-xl">{featuredProducts[0].description}</p>
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex items-center">
                    {Array(5)
                      .fill(0)
                      .map((_, i) => (
                        <Star
                          key={i}
                          className={`h-5 w-5 ${
                            i < Math.floor(featuredProducts[0].rating)
                              ? "text-yellow-500 fill-yellow-500"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                    <span className="ml-2 text-white">{featuredProducts[0].rating.toFixed(1)}</span>
                  </div>
                  <span className="text-white/80">{featuredProducts[0].reviews} reviews</span>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild size="lg">
                    <Link href={`/products/${featuredProducts[0].id}`}>View Details</Link>
                  </Button>
                  <Button variant="secondary" size="lg">
                    Add to Cart
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )
      )}

      {/* Featured Products Grid */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold tracking-tight mb-6">More Featured Products</h2>
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array(7)
              .fill(0)
              .map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <div className="relative h-60">
                    <Skeleton className="h-full w-full" />
                  </div>
                  <CardContent className="p-4">
                    <Skeleton className="h-4 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-4" />
                    <Skeleton className="h-4 w-1/4" />
                  </CardContent>
                </Card>
              ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {featuredProducts.slice(1).map((product) => (
              <Link href={`/products/${product.id}`} key={product.id}>
                <Card className="overflow-hidden h-full transition-all hover:shadow-lg">
                  <div className="relative h-60">
                    <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
                    <Badge className="absolute top-2 left-2 bg-primary hover:bg-primary">Featured</Badge>
                    {product.onSale && (
                      <Badge className="absolute top-2 right-2 bg-red-500 hover:bg-red-600">Sale</Badge>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm text-muted-foreground">{product.brand}</p>
                      <div className="flex items-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="currentColor"
                          className="w-4 h-4 text-yellow-500"
                        >
                          <path
                            fillRule="evenodd"
                            d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z"
                            clipRule="evenodd"
                          />
                        </svg>
                        <span className="text-sm ml-1">{product.rating.toFixed(1)}</span>
                      </div>
                    </div>
                    <h3 className="font-semibold line-clamp-1">{product.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      {product.onSale ? (
                        <>
                          <span className="font-medium">${product.salePrice.toFixed(2)}</span>
                          <span className="text-sm text-muted-foreground line-through">
                            ${product.price.toFixed(2)}
                          </span>
                        </>
                      ) : (
                        <span className="font-medium">${product.price.toFixed(2)}</span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* Why Featured Section */}
      <div className="bg-muted rounded-lg p-8 mb-12">
        <h2 className="text-2xl font-bold tracking-tight text-center mb-8">Why We Feature These Products</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="p-3 rounded-full bg-primary/10">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-6 w-6 text-primary"
              >
                <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                <path d="m7 10 3 3 7-7" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold">Quality Assured</h3>
            <p className="text-muted-foreground">
              All featured products undergo rigorous quality testing to ensure they meet our high standards.
            </p>
          </div>
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="p-3 rounded-full bg-primary/10">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-6 w-6 text-primary"
              >
                <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold">Customer Favorites</h3>
            <p className="text-muted-foreground">
              These products have received exceptional reviews and are loved by our customers.
            </p>
          </div>
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="p-3 rounded-full bg-primary/10">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-6 w-6 text-primary"
              >
                <path d="M20.91 8.84 8.56 2.23a1.93 1.93 0 0 0-1.81 0L3.1 4.13a2.12 2.12 0 0 0-.05 3.69l12.22 6.93a2 2 0 0 0 1.94 0L21 12.51a2.12 2.12 0 0 0-.09-3.67Z" />
                <path d="m3.09 8.84 12.35-6.61a1.93 1.93 0 0 1 1.81 0l3.65 1.9a2.12 2.12 0 0 1 .1 3.69L8.73 14.75a2 2 0 0 1-1.94 0L3 12.51a2.12 2.12 0 0 1 .09-3.67Z" />
                <line x1="12" x2="12" y1="22" y2="13" />
                <path d="M20 13.5v3.37a2.06 2.06 0 0 1-1.11 1.83l-6 3.08a1.93 1.93 0 0 1-1.78 0l-6-3.08A2.06 2.06 0 0 1 4 16.87V13.5" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold">Exclusive Selection</h3>
            <p className="text-muted-foreground">
              Our team carefully selects each featured product based on innovation, design, and value.
            </p>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="text-center">
        <h2 className="text-2xl font-bold tracking-tight mb-4">Explore All Products</h2>
        <p className="text-muted-foreground max-w-[500px] mx-auto mb-6">
          Discover our complete collection of high-quality products across all categories.
        </p>
        <Button asChild size="lg">
          <Link href="/products">Shop All Products</Link>
        </Button>
      </div>
    </div>
  )
}

