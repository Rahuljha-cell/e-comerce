"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { ArrowLeft, ShoppingCart, Heart } from "lucide-react"
import { mockProducts } from "@/lib/mock-data"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { useAuth } from "@/hooks/use-auth"
import { useRouter } from "next/navigation"

export default function NewArrivalsPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [products, setProducts] = useState<any[]>([])
  const [activeCategory, setActiveCategory] = useState("all")
  const { isAuthenticated, addToCartAfterSignIn } = useAuth()
  const router = useRouter()

  // Simulate loading state
  useEffect(() => {
    const timer = setTimeout(() => {
      // Sort products by date added (newest first) and take the first 16
      const newArrivals = [...mockProducts]
        .sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime())
        .slice(0, 16)

      setProducts(newArrivals)
      setIsLoading(false)
    }, 800)

    return () => clearTimeout(timer)
  }, [])

  // Filter products by category
  const filteredProducts =
    activeCategory === "all"
      ? products
      : products.filter((product) => {
          if (activeCategory === "clothing") {
            return product.category === "mens-clothing" || product.category === "womens-clothing"
          }
          return product.category === activeCategory
        })

  // Handle add to cart
  const handleAddToCart = (product: any) => {
    if (!isAuthenticated) {
      // Store the product ID to add after sign in
      addToCartAfterSignIn(product.id)

      // Redirect to sign in page
      router.push("/signin")
      return
    }

    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart.`,
      action: (
        <Link href="/cart">
          <Button variant="outline" size="sm">
            View Cart
          </Button>
        </Link>
      ),
    })
  }

  // Handle add to wishlist
  const handleAddToWishlist = (product: any) => {
    if (!isAuthenticated) {
      router.push("/signin")
      return
    }

    toast({
      title: "Added to Wishlist",
      description: `${product.name} has been added to your wishlist.`,
    })
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Toaster />

      <Link href="/products" className="flex items-center text-sm mb-6 hover:underline">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to All Products
      </Link>

      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">New Arrivals</h1>
          <p className="text-muted-foreground mt-1">Check out our latest products and collections</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Tabs defaultValue="all" value={activeCategory} onValueChange={setActiveCategory}>
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="electronics">Electronics</TabsTrigger>
              <TabsTrigger value="clothing">Clothing</TabsTrigger>
              <TabsTrigger value="home">Home</TabsTrigger>
              <TabsTrigger value="accessories">Accessories</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array(8)
            .fill(0)
            .map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <div className="relative h-60">
                  <Skeleton className="h-full w-full" />
                </div>
                <CardContent className="p-4">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2 mb-4" />
                  <Skeleton className="h-4 w-1/4" />
                </CardContent>
              </Card>
            ))}
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold mb-4">No products found</h2>
          <p className="text-muted-foreground mb-6">
            We couldn't find any products in this category. Please try another category or check back later.
          </p>
          <Button onClick={() => setActiveCategory("all")}>View All Products</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="overflow-hidden h-full transition-all hover:shadow-lg group">
              <Link href={`/products/${product.id}`}>
                <div className="relative h-60">
                  <Image
                    src={
                      product.image || `/placeholder.svg?height=240&width=240&text=${encodeURIComponent(product.name)}`
                    }
                    alt={product.name}
                    fill
                    className="object-cover transition-transform group-hover:scale-105"
                  />
                  <Badge className="absolute top-2 left-2 bg-primary hover:bg-primary">New</Badge>
                  {product.onSale && <Badge className="absolute top-2 right-2 bg-red-500 hover:bg-red-600">Sale</Badge>}
                </div>
              </Link>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm text-muted-foreground">{product.brand}</p>
                  <div className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="currentColor"
                      className="w-4 h-4 text-yellow-500"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <span className="text-sm ml-1">{product.rating.toFixed(1)}</span>
                  </div>
                </div>
                <Link href={`/products/${product.id}`}>
                  <h3 className="font-semibold line-clamp-1 hover:underline">{product.name}</h3>
                </Link>
                <div className="flex items-center gap-2 mt-1">
                  {product.onSale ? (
                    <>
                      <span className="font-medium">${product.salePrice.toFixed(2)}</span>
                      <span className="text-sm text-muted-foreground line-through">${product.price.toFixed(2)}</span>
                    </>
                  ) : (
                    <span className="font-medium">${product.price.toFixed(2)}</span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Added on {new Date(product.dateAdded).toLocaleDateString()}
                </p>
                <div className="flex gap-2 mt-3">
                  <Button
                    variant="default"
                    size="sm"
                    className="flex-1"
                    onClick={(e) => {
                      e.preventDefault()
                      handleAddToCart(product)
                    }}
                  >
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Add to Cart
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="px-2"
                    onClick={(e) => {
                      e.preventDefault()
                      handleAddToWishlist(product)
                    }}
                  >
                    <Heart className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="mt-12 text-center">
        <h2 className="text-xl font-semibold mb-4">Subscribe for New Arrivals</h2>
        <p className="text-muted-foreground max-w-[500px] mx-auto mb-6">
          Be the first to know about our newest products. Subscribe to our newsletter for exclusive updates and early
          access.
        </p>
        <div className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
          <input type="email" placeholder="Enter your email" className="px-4 py-2 border rounded-md flex-1" />
          <Button>Subscribe</Button>
        </div>
      </div>
    </div>
  )
}

