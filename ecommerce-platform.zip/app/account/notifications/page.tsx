"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { Bell, ShoppingBag, Tag, Truck, Gift, CreditCard, Heart, MessageSquare } from "lucide-react"
import AccountSidebar from "@/components/account-sidebar"

// Mock notifications
const mockNotifications = [
  {
    id: 1,
    title: "Your order has shipped!",
    description: "Order #ORD-123456 has been shipped and is on its way.",
    date: "2023-04-05T14:30:00",
    read: true,
    type: "order",
    icon: Truck,
  },
  {
    id: 2,
    title: "Flash Sale: 50% off Electronics",
    description: "Don't miss our 24-hour flash sale on all electronics!",
    date: "2023-04-04T09:15:00",
    read: false,
    type: "promotion",
    icon: Tag,
  },
  {
    id: 3,
    title: "New items on your wishlist are on sale",
    description: "3 items from your wishlist are now on sale. Check them out before they're gone!",
    date: "2023-04-03T16:45:00",
    read: false,
    type: "wishlist",
    icon: Heart,
  },
  {
    id: 4,
    title: "Your order has been delivered",
    description: "Order #ORD-789012 has been delivered. Enjoy your purchase!",
    date: "2023-04-02T11:20:00",
    read: true,
    type: "order",
    icon: ShoppingBag,
  },
  {
    id: 5,
    title: "Payment method expiring soon",
    description: "Your credit card ending in 4567 will expire next month. Please update your payment information.",
    date: "2023-04-01T08:10:00",
    read: false,
    type: "payment",
    icon: CreditCard,
  },
  {
    id: 6,
    title: "Special offer just for you!",
    description: "We've selected some special offers based on your shopping history.",
    date: "2023-03-30T13:25:00",
    read: true,
    type: "promotion",
    icon: Gift,
  },
  {
    id: 7,
    title: "Customer support response",
    description: "We've responded to your recent support request about your order.",
    date: "2023-03-29T15:40:00",
    read: false,
    type: "support",
    icon: MessageSquare,
  },
]

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState(mockNotifications)
  const [notificationSettings, setNotificationSettings] = useState({
    email: {
      orders: true,
      promotions: true,
      wishlist: true,
      payments: true,
      support: true,
    },
    push: {
      orders: true,
      promotions: false,
      wishlist: true,
      payments: true,
      support: true,
    },
    sms: {
      orders: true,
      promotions: false,
      wishlist: false,
      payments: true,
      support: false,
    },
  })

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAsRead = (id: number) => {
    setNotifications(notifications.map((n) => (n.id === id ? { ...n, read: true } : n)))

    toast({
      title: "Notification marked as read",
      description: "The notification has been marked as read.",
    })
  }

  const markAllAsRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })))

    toast({
      title: "All notifications marked as read",
      description: "All notifications have been marked as read.",
    })
  }

  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter((n) => n.id !== id))

    toast({
      title: "Notification deleted",
      description: "The notification has been deleted.",
    })
  }

  const clearAllNotifications = () => {
    setNotifications([])

    toast({
      title: "All notifications cleared",
      description: "All notifications have been cleared.",
    })
  }

  const updateNotificationSetting = (channel: "email" | "push" | "sms", type: string, value: boolean) => {
    setNotificationSettings({
      ...notificationSettings,
      [channel]: {
        ...notificationSettings[channel],
        [type]: value,
      },
    })
  }

  const saveNotificationSettings = () => {
    toast({
      title: "Settings saved",
      description: "Your notification preferences have been updated.",
    })
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))

    if (diffInDays === 0) {
      return `Today at ${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
    } else if (diffInDays === 1) {
      return `Yesterday at ${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
    } else if (diffInDays < 7) {
      return `${diffInDays} days ago`
    } else {
      return date.toLocaleDateString()
    }
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Toaster />

      <div className="flex flex-col md:flex-row gap-8">
        <AccountSidebar />

        <div className="flex-1">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
            <div className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-primary" />
              <h1 className="text-2xl font-bold tracking-tight">Notifications</h1>
              {unreadCount > 0 && (
                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-medium">
                  {unreadCount}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={markAllAsRead} disabled={unreadCount === 0}>
                Mark All as Read
              </Button>
              <Button variant="outline" size="sm" onClick={clearAllNotifications} disabled={notifications.length === 0}>
                Clear All
              </Button>
            </div>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Recent Notifications</CardTitle>
              <CardDescription>View and manage your recent notifications</CardDescription>
            </CardHeader>
            <CardContent>
              {notifications.length === 0 ? (
                <div className="text-center py-12">
                  <Bell className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No notifications</h3>
                  <p className="text-muted-foreground">You don't have any notifications at the moment.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {notifications.map((notification) => {
                    const Icon = notification.icon
                    return (
                      <div
                        key={notification.id}
                        className={`flex gap-4 p-4 rounded-lg border ${!notification.read ? "bg-muted/50" : ""}`}
                      >
                        <div className={`p-2 h-fit rounded-full ${!notification.read ? "bg-primary/10" : "bg-muted"}`}>
                          <Icon
                            className={`h-5 w-5 ${!notification.read ? "text-primary" : "text-muted-foreground"}`}
                          />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <h3
                              className={`font-medium ${!notification.read ? "text-foreground" : "text-muted-foreground"}`}
                            >
                              {notification.title}
                            </h3>
                            <span className="text-xs text-muted-foreground">{formatDate(notification.date)}</span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">{notification.description}</p>
                          <div className="flex gap-2 mt-2">
                            {!notification.read && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 px-2 text-xs"
                                onClick={() => markAsRead(notification.id)}
                              >
                                Mark as Read
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 px-2 text-xs text-red-500 hover:text-red-600 hover:bg-red-50"
                              onClick={() => deleteNotification(notification.id)}
                            >
                              Delete
                            </Button>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>Manage how you receive notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-4 gap-4 text-center text-sm font-medium border-b pb-2">
                  <div>Notification Type</div>
                  <div>Email</div>
                  <div>Push</div>
                  <div>SMS</div>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-4 gap-4 items-center">
                    <div className="flex items-center gap-2">
                      <ShoppingBag className="h-4 w-4 text-muted-foreground" />
                      <span>Order Updates</span>
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.email.orders}
                        onCheckedChange={(checked) => updateNotificationSetting("email", "orders", checked)}
                      />
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.push.orders}
                        onCheckedChange={(checked) => updateNotificationSetting("push", "orders", checked)}
                      />
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.sms.orders}
                        onCheckedChange={(checked) => updateNotificationSetting("sms", "orders", checked)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-4 items-center">
                    <div className="flex items-center gap-2">
                      <Tag className="h-4 w-4 text-muted-foreground" />
                      <span>Promotions & Deals</span>
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.email.promotions}
                        onCheckedChange={(checked) => updateNotificationSetting("email", "promotions", checked)}
                      />
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.push.promotions}
                        onCheckedChange={(checked) => updateNotificationSetting("push", "promotions", checked)}
                      />
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.sms.promotions}
                        onCheckedChange={(checked) => updateNotificationSetting("sms", "promotions", checked)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-4 items-center">
                    <div className="flex items-center gap-2">
                      <Heart className="h-4 w-4 text-muted-foreground" />
                      <span>Wishlist Updates</span>
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.email.wishlist}
                        onCheckedChange={(checked) => updateNotificationSetting("email", "wishlist", checked)}
                      />
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.push.wishlist}
                        onCheckedChange={(checked) => updateNotificationSetting("push", "wishlist", checked)}
                      />
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.sms.wishlist}
                        onCheckedChange={(checked) => updateNotificationSetting("sms", "wishlist", checked)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-4 items-center">
                    <div className="flex items-center gap-2">
                      <CreditCard className="h-4 w-4 text-muted-foreground" />
                      <span>Payment Updates</span>
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.email.payments}
                        onCheckedChange={(checked) => updateNotificationSetting("email", "payments", checked)}
                      />
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.push.payments}
                        onCheckedChange={(checked) => updateNotificationSetting("push", "payments", checked)}
                      />
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.sms.payments}
                        onCheckedChange={(checked) => updateNotificationSetting("sms", "payments", checked)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-4 items-center">
                    <div className="flex items-center gap-2">
                      <MessageSquare className="h-4 w-4 text-muted-foreground" />
                      <span>Support Messages</span>
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.email.support}
                        onCheckedChange={(checked) => updateNotificationSetting("email", "support", checked)}
                      />
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.push.support}
                        onCheckedChange={(checked) => updateNotificationSetting("push", "support", checked)}
                      />
                    </div>
                    <div className="flex justify-center">
                      <Switch
                        checked={notificationSettings.sms.support}
                        onCheckedChange={(checked) => updateNotificationSetting("sms", "support", checked)}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <Button onClick={saveNotificationSettings}>Save Preferences</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

