"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Package, Search, Star, FileText, RefreshCw, XCircle, RotateCcw, AlertTriangle } from "lucide-react"
import { Separator } from "@/components/ui/separator"
import AccountSidebar from "@/components/account-sidebar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"

// Mock orders data
const mockOrders = [
  {
    id: "ORD-123456",
    date: "2023-03-15",
    total: 349.97,
    status: "delivered",
    items: [
      {
        id: 1,
        name: "Premium Wireless Headphones",
        price: 199.99,
        quantity: 1,
        image: "/placeholder.svg?height=80&width=80&text=Headphones",
      },
      {
        id: 8,
        name: "Wireless Gaming Mouse",
        price: 69.99,
        quantity: 2,
        image: "/placeholder.svg?height=80&width=80&text=Mouse",
      },
    ],
    deliveredDate: "2023-03-20",
    trackingNumber: "TRK9876543210",
    returnEligible: true,
    returnDeadline: "2023-03-27",
  },
  {
    id: "ORD-789012",
    date: "2023-02-28",
    total: 1299.99,
    status: "delivered",
    items: [
      {
        id: 5,
        name: "Professional DSLR Camera",
        price: 1299.99,
        quantity: 1,
        image: "/placeholder.svg?height=80&width=80&text=Camera",
      },
    ],
    deliveredDate: "2023-03-05",
    trackingNumber: "TRK1234567890",
    returnEligible: false,
    returnDeadline: "2023-03-12",
  },
  {
    id: "ORD-345678",
    date: "2023-04-02",
    total: 129.99,
    status: "shipped",
    items: [
      {
        id: 12,
        name: "Ceramic Coffee Mug Set",
        price: 39.99,
        quantity: 1,
        image: "/placeholder.svg?height=80&width=80&text=Mugs",
      },
      {
        id: 15,
        name: "Yoga Mat",
        price: 29.99,
        quantity: 3,
        image: "/placeholder.svg?height=80&width=80&text=Yoga+Mat",
      },
    ],
    estimatedDelivery: "2023-04-08",
    trackingNumber: "TRK5678901234",
    cancelEligible: true,
  },
  {
    id: "ORD-901234",
    date: "2023-04-05",
    total: 249.99,
    status: "processing",
    items: [
      {
        id: 3,
        name: "Smart Fitness Watch",
        price: 199.99,
        quantity: 1,
        image: "/placeholder.svg?height=80&width=80&text=Watch",
      },
      {
        id: 14,
        name: "Leather Wallet",
        price: 49.99,
        quantity: 1,
        image: "/placeholder.svg?height=80&width=80&text=Wallet",
      },
    ],
    estimatedShipping: "2023-04-07",
    cancelEligible: true,
  },
]

export default function OrdersPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [orders, setOrders] = useState<any[]>([])
  const [filteredOrders, setFilteredOrders] = useState<any[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [timeFilter, setTimeFilter] = useState("all")
  const [sortOrder, setSortOrder] = useState("newest")
  const [selectedReturnReason, setSelectedReturnReason] = useState("")
  const [returnDetails, setReturnDetails] = useState("")
  const [selectedOrder, setSelectedOrder] = useState<any>(null)
  const [selectedItem, setSelectedItem] = useState<any>(null)
  const [returnType, setReturnType] = useState("refund")
  const [reviewRating, setReviewRating] = useState(0)
  const [reviewText, setReviewText] = useState("")
  const [hoveredRating, setHoveredRating] = useState(0)
  const [activeTab, setActiveTab] = useState("all-orders")

  // Load orders
  useEffect(() => {
    const timer = setTimeout(() => {
      setOrders(mockOrders)
      setFilteredOrders(mockOrders)
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Filter and sort orders
  useEffect(() => {
    let result = [...orders]

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      result = result.filter(
        (order) =>
          order.id.toLowerCase().includes(query) ||
          order.items.some((item: any) => item.name.toLowerCase().includes(query)),
      )
    }

    // Filter by status
    if (statusFilter !== "all") {
      result = result.filter((order) => order.status === statusFilter)
    }

    // Filter by time
    if (timeFilter !== "all") {
      const now = new Date()
      const threeMonthsAgo = new Date(now.setMonth(now.getMonth() - 3))
      const sixMonthsAgo = new Date(now.setMonth(now.getMonth() - 3)) // now is already 3 months ago

      if (timeFilter === "3months") {
        result = result.filter((order) => new Date(order.date) >= threeMonthsAgo)
      } else if (timeFilter === "6months") {
        result = result.filter((order) => new Date(order.date) >= sixMonthsAgo)
      }
    }

    // Sort orders
    if (sortOrder === "newest") {
      result.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    } else if (sortOrder === "oldest") {
      result.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    } else if (sortOrder === "highest") {
      result.sort((a, b) => b.total - a.total)
    } else if (sortOrder === "lowest") {
      result.sort((a, b) => a.total - b.total)
    }

    setFilteredOrders(result)
  }, [orders, searchQuery, statusFilter, timeFilter, sortOrder])

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "delivered":
        return <Badge className="bg-green-500 hover:bg-green-600">Delivered</Badge>
      case "shipped":
        return <Badge className="bg-blue-500 hover:bg-blue-600">Shipped</Badge>
      case "processing":
        return <Badge className="bg-yellow-500 hover:bg-yellow-600">Processing</Badge>
      case "cancelled":
        return <Badge className="bg-red-500 hover:bg-red-600">Cancelled</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  // Cancel order
  const cancelOrder = (orderId: string) => {
    setOrders(
      orders.map((order) => (order.id === orderId ? { ...order, status: "cancelled", cancelEligible: false } : order)),
    )

    toast({
      title: "Order Cancelled",
      description: `Order ${orderId} has been cancelled successfully.`,
    })

    // Automatically switch to cancelled tab after cancellation
    setActiveTab("cancelled")
  }

  // Initiate return
  const initiateReturn = () => {
    if (!selectedOrder || !selectedItem || !selectedReturnReason) return

    // In a real app, this would make an API call to initiate the return
    toast({
      title: "Return Initiated",
      description: `Your return request for ${selectedItem.name} has been submitted successfully.`,
    })

    // Reset form
    setSelectedReturnReason("")
    setReturnDetails("")
    setSelectedOrder(null)
    setSelectedItem(null)
    setReturnType("refund")
  }

  // Submit review
  const submitReview = () => {
    if (!selectedOrder || !selectedItem || !reviewRating) return

    toast({
      title: "Review Submitted",
      description: `Thank you for reviewing ${selectedItem.name}!`,
    })

    // Reset form
    setReviewRating(0)
    setReviewText("")
    setSelectedOrder(null)
    setSelectedItem(null)
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Toaster />

      <div className="flex flex-col md:flex-row gap-8">
        <AccountSidebar />

        <div className="flex-1">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Your Orders</h1>
              <p className="text-muted-foreground">View and manage your order history</p>
            </div>

            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="h-8">
                <FileText className="h-4 w-4 mr-2" />
                Download History
              </Button>
              <Button variant="outline" size="sm" className="h-8">
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>

          <Tabs defaultValue="all-orders" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="all-orders">All Orders</TabsTrigger>
              <TabsTrigger value="buy-again">Buy Again</TabsTrigger>
              <TabsTrigger value="not-yet-shipped">Not Yet Shipped</TabsTrigger>
              <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
              <TabsTrigger value="returns">Returns</TabsTrigger>
            </TabsList>

            <TabsContent value="all-orders">
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="relative flex-1">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="search"
                        placeholder="Search orders..."
                        className="pl-8"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Select value={statusFilter} onValueChange={setStatusFilter}>
                        <SelectTrigger className="w-[130px]">
                          <SelectValue placeholder="Status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Statuses</SelectItem>
                          <SelectItem value="delivered">Delivered</SelectItem>
                          <SelectItem value="shipped">Shipped</SelectItem>
                          <SelectItem value="processing">Processing</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>

                      <Select value={timeFilter} onValueChange={setTimeFilter}>
                        <SelectTrigger className="w-[130px]">
                          <SelectValue placeholder="Time" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Time</SelectItem>
                          <SelectItem value="3months">Last 3 Months</SelectItem>
                          <SelectItem value="6months">Last 6 Months</SelectItem>
                          <SelectItem value="year">Last Year</SelectItem>
                        </SelectContent>
                      </Select>

                      <Select value={sortOrder} onValueChange={setSortOrder}>
                        <SelectTrigger className="w-[130px]">
                          <SelectValue placeholder="Sort" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="newest">Newest First</SelectItem>
                          <SelectItem value="oldest">Oldest First</SelectItem>
                          <SelectItem value="highest">Highest Amount</SelectItem>
                          <SelectItem value="lowest">Lowest Amount</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardHeader>

                <CardContent>
                  {isLoading ? (
                    <div className="space-y-4">
                      {Array(3)
                        .fill(0)
                        .map((_, i) => (
                          <div key={i} className="border rounded-lg p-4">
                            <div className="flex justify-between items-start mb-4">
                              <div>
                                <Skeleton className="h-5 w-32 mb-2" />
                                <Skeleton className="h-4 w-24" />
                              </div>
                              <Skeleton className="h-6 w-20" />
                            </div>
                            <Separator className="my-4" />
                            <div className="flex gap-4 mb-4">
                              <Skeleton className="h-16 w-16 rounded" />
                              <div className="flex-1">
                                <Skeleton className="h-4 w-3/4 mb-2" />
                                <Skeleton className="h-4 w-1/2" />
                              </div>
                              <Skeleton className="h-4 w-16" />
                            </div>
                            <div className="flex justify-between items-center">
                              <Skeleton className="h-4 w-32" />
                              <Skeleton className="h-9 w-28" />
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : filteredOrders.length === 0 ? (
                    <div className="text-center py-12">
                      <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <h3 className="text-lg font-medium mb-2">No orders found</h3>
                      <p className="text-muted-foreground mb-6">
                        {searchQuery || statusFilter !== "all" || timeFilter !== "all"
                          ? "Try adjusting your filters to find what you're looking for."
                          : "You haven't placed any orders yet."}
                      </p>
                      {searchQuery || statusFilter !== "all" || timeFilter !== "all" ? (
                        <Button
                          variant="outline"
                          onClick={() => {
                            setSearchQuery("")
                            setStatusFilter("all")
                            setTimeFilter("all")
                          }}
                        >
                          Clear Filters
                        </Button>
                      ) : (
                        <Button asChild>
                          <Link href="/products">Start Shopping</Link>
                        </Button>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredOrders.map((order) => (
                        <div key={order.id} className="border rounded-lg p-4">
                          <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                            <div>
                              <div className="flex items-center gap-2">
                                <h3 className="font-semibold">Order {order.id}</h3>
                                {getStatusBadge(order.status)}
                              </div>
                              <p className="text-sm text-muted-foreground">
                                Placed on {new Date(order.date).toLocaleDateString()}
                              </p>
                            </div>
                            <p className="font-medium">Total: ${order.total.toFixed(2)}</p>
                          </div>
                          <Separator className="my-4" />
                          <div className="space-y-4">
                            {order.items.map((item: any) => (
                              <div key={item.id} className="flex gap-4">
                                <div className="relative w-16 h-16 rounded-md overflow-hidden">
                                  <Image
                                    src={item.image || "/placeholder.svg"}
                                    alt={item.name}
                                    fill
                                    className="object-cover"
                                  />
                                </div>
                                <div className="flex-1">
                                  <Link href={`/products/${item.id}`} className="font-medium hover:underline">
                                    {item.name}
                                  </Link>
                                  <p className="text-sm text-muted-foreground">
                                    Qty: {item.quantity} × ${item.price.toFixed(2)}
                                  </p>
                                </div>
                                <div className="text-right">
                                  <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                                  <Button variant="ghost" size="sm" asChild className="h-8 px-2">
                                    <Link href={`/products/${item.id}`}>Buy Again</Link>
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                          <div className="flex flex-col sm:flex-row justify-between items-center mt-6 pt-4 border-t">
                            <div className="text-sm text-muted-foreground mb-4 sm:mb-0">
                              {order.status === "delivered" ? (
                                <span>Delivered on {new Date(order.deliveredDate).toLocaleDateString()}</span>
                              ) : order.status === "shipped" ? (
                                <span>
                                  Estimated delivery: {new Date(order.estimatedDelivery).toLocaleDateString()}
                                </span>
                              ) : order.status === "cancelled" ? (
                                <span className="text-red-500">This order has been cancelled</span>
                              ) : (
                                <span>
                                  Estimated shipping: {new Date(order.estimatedShipping).toLocaleDateString()}
                                </span>
                              )}
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {/* Cancel Order Button - Only for processing or shipped orders */}
                              {(order.status === "processing" || order.status === "shipped") &&
                                order.cancelEligible && (
                                  <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        className="text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600"
                                      >
                                        <XCircle className="h-4 w-4 mr-2" />
                                        Cancel Order
                                      </Button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                      <AlertDialogHeader>
                                        <AlertDialogTitle>Cancel Order</AlertDialogTitle>
                                        <AlertDialogDescription>
                                          Are you sure you want to cancel this order? This action cannot be undone.
                                        </AlertDialogDescription>
                                      </AlertDialogHeader>
                                      <AlertDialogFooter>
                                        <AlertDialogCancel>No, Keep Order</AlertDialogCancel>
                                        <AlertDialogAction
                                          onClick={() => cancelOrder(order.id)}
                                          className="bg-red-500 hover:bg-red-600"
                                        >
                                          Yes, Cancel Order
                                        </AlertDialogAction>
                                      </AlertDialogFooter>
                                    </AlertDialogContent>
                                  </AlertDialog>
                                )}

                              {/* Return/Replace Button - Only for delivered orders within return window */}
                              {order.status === "delivered" && order.returnEligible && (
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => {
                                        setSelectedOrder(order)
                                        setSelectedItem(order.items[0])
                                      }}
                                    >
                                      <RotateCcw className="h-4 w-4 mr-2" />
                                      Return or Replace
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
                                    <DialogHeader>
                                      <DialogTitle>Return or Replace Item</DialogTitle>
                                      <DialogDescription>
                                        Please select the item you wish to return or replace and provide details.
                                      </DialogDescription>
                                      <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
                                        <XCircle className="h-4 w-4" />
                                        <span className="sr-only">Close</span>
                                      </DialogClose>
                                    </DialogHeader>

                                    <div className="space-y-4 py-4">
                                      <div className="space-y-2">
                                        <Label>Select Item</Label>
                                        <Select
                                          value={selectedItem?.id.toString()}
                                          onValueChange={(value) => {
                                            const item = order.items.find((i: any) => i.id.toString() === value)
                                            setSelectedItem(item)
                                          }}
                                        >
                                          <SelectTrigger>
                                            <SelectValue placeholder="Select an item" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            {order.items.map((item: any) => (
                                              <SelectItem key={item.id} value={item.id.toString()}>
                                                {item.name} (Qty: {item.quantity})
                                              </SelectItem>
                                            ))}
                                          </SelectContent>
                                        </Select>
                                      </div>

                                      <div className="space-y-2">
                                        <Label>Return Type</Label>
                                        <RadioGroup value={returnType} onValueChange={setReturnType}>
                                          <div className="flex items-center space-x-2">
                                            <RadioGroupItem value="refund" id="refund" />
                                            <Label htmlFor="refund">Refund</Label>
                                          </div>
                                          <div className="flex items-center space-x-2">
                                            <RadioGroupItem value="replacement" id="replacement" />
                                            <Label htmlFor="replacement">Replacement</Label>
                                          </div>
                                        </RadioGroup>
                                      </div>

                                      <div className="space-y-2">
                                        <Label>Reason for Return</Label>
                                        <Select value={selectedReturnReason} onValueChange={setSelectedReturnReason}>
                                          <SelectTrigger>
                                            <SelectValue placeholder="Select a reason" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="defective">Item is defective</SelectItem>
                                            <SelectItem value="damaged">Item arrived damaged</SelectItem>
                                            <SelectItem value="wrong">Wrong item received</SelectItem>
                                            <SelectItem value="notneeded">No longer needed</SelectItem>
                                            <SelectItem value="notdescribed">Item not as described</SelectItem>
                                            <SelectItem value="other">Other reason</SelectItem>
                                          </SelectContent>
                                        </Select>
                                      </div>

                                      <div className="space-y-2">
                                        <Label>Additional Details</Label>
                                        <Textarea
                                          placeholder="Please provide any additional details about your return request"
                                          value={returnDetails}
                                          onChange={(e) => setReturnDetails(e.target.value)}
                                        />
                                      </div>

                                      <div className="rounded-md bg-yellow-50 p-4 text-sm text-yellow-800">
                                        <div className="flex items-center gap-2">
                                          <AlertTriangle className="h-4 w-4" />
                                          <span className="font-medium">Important</span>
                                        </div>
                                        <p className="mt-1">
                                          Return eligible until {new Date(order.returnDeadline).toLocaleDateString()}.
                                          Please keep the original packaging for returns.
                                        </p>
                                      </div>
                                    </div>

                                    <DialogFooter>
                                      <Button type="submit" onClick={initiateReturn} disabled={!selectedReturnReason}>
                                        Submit Return Request
                                      </Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>
                              )}

                              {/* Write a Review Button - Only for delivered orders */}
                              {order.status === "delivered" && (
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => {
                                        setSelectedOrder(order)
                                        setSelectedItem(order.items[0])
                                      }}
                                    >
                                      <Star className="h-4 w-4 mr-2" />
                                      Write a Review
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="sm:max-w-[500px]">
                                    <DialogHeader>
                                      <DialogTitle>Write a Review</DialogTitle>
                                      <DialogDescription>
                                        Share your experience with this product to help other shoppers.
                                      </DialogDescription>
                                      <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
                                        <XCircle className="h-4 w-4" />
                                        <span className="sr-only">Close</span>
                                      </DialogClose>
                                    </DialogHeader>

                                    <div className="space-y-4 py-4">
                                      <div className="space-y-2">
                                        <Label>Select Item</Label>
                                        <Select
                                          value={selectedItem?.id.toString()}
                                          onValueChange={(value) => {
                                            const item = order.items.find((i: any) => i.id.toString() === value)
                                            setSelectedItem(item)
                                          }}
                                        >
                                          <SelectTrigger>
                                            <SelectValue placeholder="Select an item" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            {order.items.map((item: any) => (
                                              <SelectItem key={item.id} value={item.id.toString()}>
                                                {item.name}
                                              </SelectItem>
                                            ))}
                                          </SelectContent>
                                        </Select>
                                      </div>

                                      <div className="space-y-2">
                                        <Label>Rating</Label>
                                        <div className="flex">
                                          {Array(5)
                                            .fill(0)
                                            .map((_, i) => (
                                              <Star
                                                key={i}
                                                className={`h-6 w-6 cursor-pointer ${
                                                  i < (hoveredRating || reviewRating)
                                                    ? "text-yellow-500 fill-yellow-500"
                                                    : "text-gray-300"
                                                }`}
                                                onMouseEnter={() => setHoveredRating(i + 1)}
                                                onMouseLeave={() => setHoveredRating(0)}
                                                onClick={() => setReviewRating(i + 1)}
                                              />
                                            ))}
                                        </div>
                                      </div>

                                      <div className="space-y-2">
                                        <Label>Review</Label>
                                        <Textarea
                                          placeholder="What did you like or dislike about this product?"
                                          value={reviewText}
                                          onChange={(e) => setReviewText(e.target.value)}
                                          className="min-h-[100px]"
                                        />
                                      </div>
                                    </div>

                                    <DialogFooter>
                                      <Button type="submit" onClick={submitReview} disabled={!reviewRating}>
                                        Submit Review
                                      </Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>
                              )}

                              <Button variant="outline" size="sm" asChild>
                                <Link href={`/account/orders/${order.id}`}>View Order Details</Link>
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="buy-again">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-12">
                    <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">Buy Again</h3>
                    <p className="text-muted-foreground mb-6">
                      Items you've purchased before will appear here for easy reordering.
                    </p>
                    <Button asChild>
                      <Link href="/products">Browse Products</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="not-yet-shipped">
              <Card>
                <CardContent className="pt-6">
                  {isLoading ? (
                    <div className="space-y-4">
                      {Array(2)
                        .fill(0)
                        .map((_, i) => (
                          <div key={i} className="border rounded-lg p-4">
                            <div className="flex justify-between items-start mb-4">
                              <div>
                                <Skeleton className="h-5 w-32 mb-2" />
                                <Skeleton className="h-4 w-24" />
                              </div>
                              <Skeleton className="h-6 w-20" />
                            </div>
                            <Separator className="my-4" />
                            <div className="flex gap-4 mb-4">
                              <Skeleton className="h-16 w-16 rounded" />
                              <div className="flex-1">
                                <Skeleton className="h-4 w-3/4 mb-2" />
                                <Skeleton className="h-4 w-1/2" />
                              </div>
                              <Skeleton className="h-4 w-16" />
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredOrders
                        .filter((order) => order.status === "processing")
                        .map((order) => (
                          <div key={order.id} className="border rounded-lg p-4">
                            <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                              <div>
                                <div className="flex items-center gap-2">
                                  <h3 className="font-semibold">Order {order.id}</h3>
                                  {getStatusBadge(order.status)}
                                </div>
                                <p className="text-sm text-muted-foreground">
                                  Placed on {new Date(order.date).toLocaleDateString()}
                                </p>
                              </div>
                              <p className="font-medium">Total: ${order.total.toFixed(2)}</p>
                            </div>
                            <Separator className="my-4" />
                            <div className="space-y-4">
                              {order.items.map((item: any) => (
                                <div key={item.id} className="flex gap-4">
                                  <div className="relative w-16 h-16 rounded-md overflow-hidden">
                                    <Image
                                      src={item.image || "/placeholder.svg"}
                                      alt={item.name}
                                      fill
                                      className="object-cover"
                                    />
                                  </div>
                                  <div className="flex-1">
                                    <Link href={`/products/${item.id}`} className="font-medium hover:underline">
                                      {item.name}
                                    </Link>
                                    <p className="text-sm text-muted-foreground">
                                      Qty: {item.quantity} × ${item.price.toFixed(2)}
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                            <div className="flex justify-between items-center mt-6 pt-4 border-t">
                              <div className="text-sm text-muted-foreground">
                                <span>
                                  Estimated shipping: {new Date(order.estimatedShipping).toLocaleDateString()}
                                </span>
                              </div>
                              <div className="flex gap-2">
                                {order.cancelEligible && (
                                  <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        className="text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600"
                                      >
                                        <XCircle className="h-4 w-4 mr-2" />
                                        Cancel Order
                                      </Button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                      <AlertDialogHeader>
                                        <AlertDialogTitle>Cancel Order</AlertDialogTitle>
                                        <AlertDialogDescription>
                                          Are you sure you want to cancel this order? This action cannot be undone.
                                        </AlertDialogDescription>
                                      </AlertDialogHeader>
                                      <AlertDialogFooter>
                                        <AlertDialogCancel>No, Keep Order</AlertDialogCancel>
                                        <AlertDialogAction
                                          onClick={() => cancelOrder(order.id)}
                                          className="bg-red-500 hover:bg-red-600"
                                        >
                                          Yes, Cancel Order
                                        </AlertDialogAction>
                                      </AlertDialogFooter>
                                    </AlertDialogContent>
                                  </AlertDialog>
                                )}
                                <Button variant="outline" size="sm" asChild>
                                  <Link href={`/account/orders/${order.id}`}>View Order Details</Link>
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}

                      {filteredOrders.filter((order) => order.status === "processing").length === 0 && (
                        <div className="text-center py-12">
                          <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                          <h3 className="text-lg font-medium mb-2">No pending shipments</h3>
                          <p className="text-muted-foreground mb-6">All your orders have been shipped or delivered.</p>
                          <Button asChild>
                            <Link href="/products">Continue Shopping</Link>
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="cancelled">
              <Card>
                <CardContent className="pt-6">
                  {isLoading ? (
                    <div className="space-y-4">
                      {Array(2)
                        .fill(0)
                        .map((_, i) => (
                          <div key={i} className="border rounded-lg p-4">
                            <div className="flex justify-between items-start mb-4">
                              <div>
                                <Skeleton className="h-5 w-32 mb-2" />
                                <Skeleton className="h-4 w-24" />
                              </div>
                              <Skeleton className="h-6 w-20" />
                            </div>
                            <Separator className="my-4" />
                            <div className="flex gap-4 mb-4">
                              <Skeleton className="h-16 w-16 rounded" />
                              <div className="flex-1">
                                <Skeleton className="h-4 w-3/4 mb-2" />
                                <Skeleton className="h-4 w-1/2" />
                              </div>
                              <Skeleton className="h-4 w-16" />
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredOrders
                        .filter((order) => order.status === "cancelled")
                        .map((order) => (
                          <div key={order.id} className="border rounded-lg p-4">
                            <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                              <div>
                                <div className="flex items-center gap-2">
                                  <h3 className="font-semibold">Order {order.id}</h3>
                                  {getStatusBadge(order.status)}
                                </div>
                                <p className="text-sm text-muted-foreground">
                                  Placed on {new Date(order.date).toLocaleDateString()}
                                </p>
                              </div>
                              <p className="font-medium">Total: ${order.total.toFixed(2)}</p>
                            </div>
                            <Separator className="my-4" />
                            <div className="space-y-4">
                              {order.items.map((item: any) => (
                                <div key={item.id} className="flex gap-4">
                                  <div className="relative w-16 h-16 rounded-md overflow-hidden">
                                    <Image
                                      src={item.image || "/placeholder.svg"}
                                      alt={item.name}
                                      fill
                                      className="object-cover"
                                    />
                                  </div>
                                  <div className="flex-1">
                                    <Link href={`/products/${item.id}`} className="font-medium hover:underline">
                                      {item.name}
                                    </Link>
                                    <p className="text-sm text-muted-foreground">
                                      Qty: {item.quantity} × ${item.price.toFixed(2)}
                                    </p>
                                  </div>
                                  <div className="text-right">
                                    <Button variant="ghost" size="sm" asChild className="h-8 px-2">
                                      <Link href={`/products/${item.id}`}>Buy Again</Link>
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                            <div className="flex justify-between items-center mt-6 pt-4 border-t">
                              <div className="text-sm text-red-500">
                                <span>Order cancelled on {new Date().toLocaleDateString()}</span>
                              </div>
                              <Button variant="outline" size="sm" asChild>
                                <Link href={`/account/orders/${order.id}`}>View Order Details</Link>
                              </Button>
                            </div>
                          </div>
                        ))}

                      {filteredOrders.filter((order) => order.status === "cancelled").length === 0 && (
                        <div className="text-center py-12">
                          <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                          <h3 className="text-lg font-medium mb-2">No Cancelled Orders</h3>
                          <p className="text-muted-foreground mb-6">You don't have any cancelled orders.</p>
                          <Button asChild>
                            <Link href="/products">Continue Shopping</Link>
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="returns">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-12">
                    <RotateCcw className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">Returns & Replacements</h3>
                    <p className="text-muted-foreground mb-6">
                      Track and manage your return requests here. You can return most items within 7 days of delivery.
                    </p>
                    <Button asChild>
                      <Link href="/account/orders">View Orders</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

