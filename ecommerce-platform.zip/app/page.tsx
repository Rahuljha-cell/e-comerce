"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"
import { Input } from "@/components/ui/input"
import { ShoppingCart, Star, ChevronRight, Clock, Zap, Gift, Percent } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { mockProducts } from "@/lib/mock-data"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Define product categories
const categories = [
  { id: "electronics", name: "Electronics", icon: "💻" },
  { id: "mens-clothing", name: "Men's Clothing", icon: "👔" },
  { id: "womens-clothing", name: "Women's Clothing", icon: "👗" },
  { id: "jewelry", name: "Jewelry & Watches", icon: "💍" },
  { id: "home", name: "Home & Kitchen", icon: "🏠" },
  { id: "beauty", name: "Beauty & Personal Care", icon: "💄" },
  { id: "sports", name: "Sports & Outdoors", icon: "🏀" },
  { id: "toys", name: "Toys & Games", icon: "🎮" },
  { id: "books", name: "Books", icon: "📚" },
]

// Extend mock products with categories
const categorizedProducts = mockProducts.map((product) => {
  let category = "electronics"

  if (product.id % 9 === 0) category = "books"
  else if (product.id % 8 === 0) category = "mens-clothing"
  else if (product.id % 7 === 0) category = "womens-clothing"
  else if (product.id % 6 === 0) category = "jewelry"
  else if (product.id % 5 === 0) category = "home"
  else if (product.id % 4 === 0) category = "beauty"
  else if (product.id % 3 === 0) category = "sports"
  else if (product.id % 2 === 0) category = "toys"

  return {
    ...product,
    category,
  }
})

// Define product images for different categories
const productImages = {
  electronics: [
    "/placeholder.svg?height=300&width=300&text=Laptop",
    "/placeholder.svg?height=300&width=300&text=Smartphone",
    "/placeholder.svg?height=300&width=300&text=Headphones",
    "/placeholder.svg?height=300&width=300&text=Tablet",
  ],
  "mens-clothing": [
    "/placeholder.svg?height=300&width=300&text=Mens+Shirt",
    "/placeholder.svg?height=300&width=300&text=Mens+Jeans",
    "/placeholder.svg?height=300&width=300&text=Mens+Jacket",
    "/placeholder.svg?height=300&width=300&text=Mens+Shoes",
  ],
  "womens-clothing": [
    "/placeholder.svg?height=300&width=300&text=Womens+Dress",
    "/placeholder.svg?height=300&width=300&text=Womens+Top",
    "/placeholder.svg?height=300&width=300&text=Womens+Jeans",
    "/placeholder.svg?height=300&width=300&text=Womens+Shoes",
  ],
  jewelry: [
    "/placeholder.svg?height=300&width=300&text=Necklace",
    "/placeholder.svg?height=300&width=300&text=Watch",
    "/placeholder.svg?height=300&width=300&text=Earrings",
    "/placeholder.svg?height=300&width=300&text=Bracelet",
  ],
  home: [
    "/placeholder.svg?height=300&width=300&text=Cookware",
    "/placeholder.svg?height=300&width=300&text=Bedding",
    "/placeholder.svg?height=300&width=300&text=Furniture",
    "/placeholder.svg?height=300&width=300&text=Decor",
  ],
  beauty: [
    "/placeholder.svg?height=300&width=300&text=Skincare",
    "/placeholder.svg?height=300&width=300&text=Makeup",
    "/placeholder.svg?height=300&width=300&text=Fragrance",
    "/placeholder.svg?height=300&width=300&text=Haircare",
  ],
  sports: [
    "/placeholder.svg?height=300&width=300&text=Fitness",
    "/placeholder.svg?height=300&width=300&text=Outdoor",
    "/placeholder.svg?height=300&width=300&text=Sports+Gear",
    "/placeholder.svg?height=300&width=300&text=Athletic+Wear",
  ],
  toys: [
    "/placeholder.svg?height=300&width=300&text=Board+Games",
    "/placeholder.svg?height=300&width=300&text=Action+Figures",
    "/placeholder.svg?height=300&width=300&text=Educational+Toys",
    "/placeholder.svg?height=300&width=300&text=Video+Games",
  ],
  books: [
    "/placeholder.svg?height=300&width=300&text=Fiction",
    "/placeholder.svg?height=300&width=300&text=Non-Fiction",
    "/placeholder.svg?height=300&width=300&text=Children+Books",
    "/placeholder.svg?height=300&width=300&text=Textbooks",
  ],
}

// Get a product image based on category and index
const getProductImage = (category: string, id: number) => {
  const images = productImages[category as keyof typeof productImages] || productImages.electronics
  return images[id % images.length]
}

// Mock mega deals data
const megaDeals = [
  {
    id: 1,
    name: "Premium Wireless Headphones",
    originalPrice: 249.99,
    dealPrice: 149.99,
    discount: 40,
    image: "/placeholder.svg?height=300&width=300&text=Headphones+Deal",
    endsIn: "2 days",
    category: "electronics",
  },
  {
    id: 2,
    name: "Smart 4K TV - 55 inch",
    originalPrice: 899.99,
    dealPrice: 599.99,
    discount: 33,
    image: "/placeholder.svg?height=300&width=300&text=TV+Deal",
    endsIn: "1 day",
    category: "electronics",
  },
  {
    id: 3,
    name: "Bestselling Novel Collection",
    originalPrice: 79.99,
    dealPrice: 39.99,
    discount: 50,
    image: "/placeholder.svg?height=300&width=300&text=Books+Deal",
    endsIn: "3 days",
    category: "books",
  },
  {
    id: 4,
    name: "Premium Kitchen Knife Set",
    originalPrice: 129.99,
    dealPrice: 69.99,
    discount: 46,
    image: "/placeholder.svg?height=300&width=300&text=Kitchen+Deal",
    endsIn: "12 hours",
    category: "home",
  },
]

export default function Home() {
  const [isLoading, setIsLoading] = useState(true)
  const [activeCategory, setActiveCategory] = useState("all")
  const [newArrivals, setNewArrivals] = useState<any[]>([])
  const [featuredProducts, setFeaturedProducts] = useState<any[]>([])
  const [bestSellers, setBestSellers] = useState<any[]>([])
  const [lastVisited, setLastVisited] = useState<any[]>([])
  const [filteredProducts, setFilteredProducts] = useState<any[]>([])
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1500])
  const [selectedBrands, setSelectedBrands] = useState<string[]>([])
  const [selectedColors, setSelectedColors] = useState<string[]>([])
  const [showFilters, setShowFilters] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  // Get min and max prices
  const minPrice = 0
  const maxPrice = 1500

  // Get unique brands and colors
  const allBrands = [...new Set(categorizedProducts.map((p) => p.brand))]
  const allColors = [...new Set(categorizedProducts.map((p) => p.color))]

  // Load products
  useEffect(() => {
    const timer = setTimeout(() => {
      // New arrivals - sort by date
      const newArrivalsData = [...categorizedProducts]
        .sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime())
        .slice(0, 8)

      // Featured products
      const featuredData = categorizedProducts.filter((p) => p.featured).slice(0, 8)

      // Best sellers - sort by sales count
      const bestSellersData = [...categorizedProducts].sort((a, b) => b.salesCount - a.salesCount).slice(0, 8)

      // Last visited products - simulate with random selection
      const lastVisitedData = [...categorizedProducts].sort(() => 0.5 - Math.random()).slice(0, 6)

      setNewArrivals(newArrivalsData)
      setFeaturedProducts(featuredData)
      setBestSellers(bestSellersData)
      setLastVisited(lastVisitedData)
      setFilteredProducts(categorizedProducts)
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Filter products based on category, price range, brands, colors, and search
  useEffect(() => {
    let result = [...categorizedProducts]

    // Filter by category
    if (activeCategory !== "all") {
      result = result.filter((p) => p.category === activeCategory)
    }

    // Filter by price range
    result = result.filter((p) => p.price >= priceRange[0] && p.price <= priceRange[1])

    // Filter by brands
    if (selectedBrands.length > 0) {
      result = result.filter((p) => selectedBrands.includes(p.brand))
    }

    // Filter by colors
    if (selectedColors.length > 0) {
      result = result.filter((p) => selectedColors.includes(p.color))
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query) ||
          p.brand.toLowerCase().includes(query),
      )
    }

    setFilteredProducts(result)
  }, [activeCategory, priceRange, selectedBrands, selectedColors, searchQuery])

  // Toggle brand selection
  const toggleBrand = (brand: string) => {
    setSelectedBrands((prev) => (prev.includes(brand) ? prev.filter((b) => b !== brand) : [...prev, brand]))
  }

  // Toggle color selection
  const toggleColor = (color: string) => {
    setSelectedColors((prev) => (prev.includes(color) ? prev.filter((c) => c !== color) : [...prev, color]))
  }

  // Reset all filters
  const resetFilters = () => {
    setActiveCategory("all")
    setPriceRange([minPrice, maxPrice])
    setSelectedBrands([])
    setSelectedColors([])
    setSearchQuery("")
  }

  // Add to cart function
  const addToCart = (product: any) => {
    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart.`,
      action: (
        <Link href="/cart">
          <Button variant="outline" size="sm">
            View Cart
          </Button>
        </Link>
      ),
    })
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Toaster />

      {/* Hero Carousel */}
      <section className="w-full">
        <Carousel className="w-full">
          <CarouselContent>
            <CarouselItem>
              <div className="relative h-[300px] md:h-[400px] lg:h-[500px] w-full">
                <Image
                  src="/placeholder.svg?height=500&width=1200&text=Electronics+Sale"
                  alt="Electronics Sale"
                  fill
                  className="object-cover"
                  priority
                />
                <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent flex flex-col justify-center p-8 md:p-16">
                  <h1 className="text-2xl md:text-4xl lg:text-5xl font-bold text-white mb-4">Summer Tech Sale</h1>
                  <p className="text-white/80 text-sm md:text-base lg:text-lg max-w-md mb-6">
                    Up to 40% off on the latest electronics and gadgets. Limited time offer.
                  </p>
                  <Button asChild size="lg" className="w-fit">
                    <Link href="/category/electronics">Shop Now</Link>
                  </Button>
                </div>
              </div>
            </CarouselItem>
            <CarouselItem>
              <div className="relative h-[300px] md:h-[400px] lg:h-[500px] w-full">
                <Image
                  src="/placeholder.svg?height=500&width=1200&text=Fashion+Collection"
                  alt="Fashion Collection"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent flex flex-col justify-center p-8 md:p-16">
                  <h1 className="text-2xl md:text-4xl lg:text-5xl font-bold text-white mb-4">New Fashion Arrivals</h1>
                  <p className="text-white/80 text-sm md:text-base lg:text-lg max-w-md mb-6">
                    Discover the latest trends in men's and women's fashion for the season.
                  </p>
                  <div className="flex gap-4">
                    <Button asChild size="lg" variant="default">
                      <Link href="/category/womens-clothing">Women's</Link>
                    </Button>
                    <Button
                      asChild
                      size="lg"
                      variant="outline"
                      className="text-white border-white hover:text-white hover:bg-white/20"
                    >
                      <Link href="/category/mens-clothing">Men's</Link>
                    </Button>
                  </div>
                </div>
              </div>
            </CarouselItem>
            <CarouselItem>
              <div className="relative h-[300px] md:h-[400px] lg:h-[500px] w-full">
                <Image
                  src="/placeholder.svg?height=500&width=1200&text=Book+Sale"
                  alt="Book Sale"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent flex flex-col justify-center p-8 md:p-16">
                  <h1 className="text-2xl md:text-4xl lg:text-5xl font-bold text-white mb-4">Book Sale</h1>
                  <p className="text-white/80 text-sm md:text-base lg:text-lg max-w-md mb-6">
                    Expand your library with our collection of bestsellers, new releases, and classics.
                  </p>
                  <Button asChild size="lg" className="w-fit">
                    <Link href="/category/books">Explore Books</Link>
                  </Button>
                </div>
              </div>
            </CarouselItem>
          </CarouselContent>
          <div className="hidden md:block">
            <CarouselPrevious />
            <CarouselNext />
          </div>
        </Carousel>
      </section>

      {/* Mega Deals Section */}
      <section className="container px-4 py-8 md:px-6 md:py-12 bg-muted rounded-lg mt-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Zap className="h-6 w-6 text-yellow-500" />
            <h2 className="text-2xl font-bold tracking-tight">Mega Deals</h2>
          </div>
          <Link href="/deals" className="text-sm font-medium flex items-center hover:text-primary transition-colors">
            View All Deals <ChevronRight className="h-4 w-4 ml-1" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {megaDeals.map((deal) => (
            <Card
              key={deal.id}
              className="overflow-hidden h-full transition-all hover:shadow-lg border-2 border-yellow-400"
            >
              <Link href={`/products/${deal.id}`}>
                <div className="relative h-48 md:h-60">
                  <Image src={deal.image || "/placeholder.svg"} alt={deal.name} fill className="object-cover" />
                  <Badge className="absolute top-2 left-2 bg-red-500 hover:bg-red-600">{deal.discount}% OFF</Badge>
                  <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-center py-2 flex items-center justify-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span>Ends in {deal.endsIn}</span>
                  </div>
                </div>
              </Link>
              <CardContent className="p-4">
                <Link href={`/products/${deal.id}`}>
                  <h3 className="font-medium line-clamp-1 hover:underline">{deal.name}</h3>
                </Link>
                <div className="flex items-center gap-2 mt-2">
                  <span className="font-bold text-lg text-red-600">${deal.dealPrice.toFixed(2)}</span>
                  <span className="text-sm text-muted-foreground line-through">${deal.originalPrice.toFixed(2)}</span>
                </div>
                <Button className="w-full mt-3" onClick={() => addToCart({ id: deal.id, name: deal.name })}>
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Add to Cart
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Categories Section */}
      <section className="container px-4 py-8 md:px-6 md:py-12">
        <h2 className="text-2xl font-bold tracking-tight mb-6">Shop by Category</h2>
        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-9 gap-4">
          {categories.map((category) => (
            <Link
              key={category.id}
              href={`/category/${category.id}`}
              className="flex flex-col items-center text-center p-4 rounded-lg border hover:border-primary hover:bg-primary/5 transition-colors"
            >
              <div className="text-3xl mb-2">{category.icon}</div>
              <span className="text-sm font-medium">{category.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Last Visited Products Section */}
      <section className="container px-4 py-8 md:px-6 md:py-12">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-2xl font-bold tracking-tight">Recently Viewed</h2>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setLastVisited([])}>
            Clear History
          </Button>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            {Array(6)
              .fill(0)
              .map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <div className="relative h-36 md:h-40">
                    <Skeleton className="h-full w-full" />
                  </div>
                  <CardContent className="p-3">
                    <Skeleton className="h-4 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2" />
                  </CardContent>
                </Card>
              ))}
          </div>
        ) : lastVisited.length === 0 ? (
          <Card className="p-6 text-center">
            <p className="text-muted-foreground">You haven't viewed any products yet.</p>
            <Button asChild className="mt-4">
              <Link href="/products">Browse Products</Link>
            </Button>
          </Card>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            {lastVisited.map((product) => (
              <Card key={product.id} className="overflow-hidden h-full transition-all hover:shadow-lg">
                <Link href={`/products/${product.id}`}>
                  <div className="relative h-36 md:h-40">
                    <Image
                      src={getProductImage(product.category, product.id) || "/placeholder.svg"}
                      alt={product.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <CardContent className="p-3">
                    <h3 className="font-medium text-sm line-clamp-1">{product.name}</h3>
                    <div className="flex items-center gap-1 mt-1">
                      {product.onSale ? (
                        <>
                          <span className="font-medium text-sm">${product.salePrice.toFixed(2)}</span>
                          <span className="text-xs text-muted-foreground line-through">
                            ${product.price.toFixed(2)}
                          </span>
                        </>
                      ) : (
                        <span className="font-medium text-sm">${product.price.toFixed(2)}</span>
                      )}
                    </div>
                  </CardContent>
                </Link>
              </Card>
            ))}
          </div>
        )}
      </section>

      {/* New Arrivals Section */}
      <section className="bg-muted py-8 md:py-12">
        <div className="container px-4 md:px-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold tracking-tight">New Arrivals</h2>
            <Link
              href="/products/new"
              className="text-sm font-medium flex items-center hover:text-primary transition-colors"
            >
              View All <ChevronRight className="h-4 w-4 ml-1" />
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {Array(4)
                .fill(0)
                .map((_, i) => (
                  <Card key={i} className="overflow-hidden">
                    <div className="relative h-48 md:h-60">
                      <Skeleton className="h-full w-full" />
                    </div>
                    <CardContent className="p-4">
                      <Skeleton className="h-4 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2 mb-4" />
                      <Skeleton className="h-4 w-1/4" />
                    </CardContent>
                  </Card>
                ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {newArrivals.slice(0, 4).map((product) => (
                <Card key={product.id} className="overflow-hidden h-full transition-all hover:shadow-lg">
                  <div className="relative h-48 md:h-60">
                    <Image
                      src={getProductImage(product.category, product.id) || "/placeholder.svg"}
                      alt={product.name}
                      fill
                      className="object-cover"
                    />
                    <Badge className="absolute top-2 left-2 bg-primary hover:bg-primary">New</Badge>
                    {product.onSale && (
                      <Badge className="absolute top-2 right-2 bg-red-500 hover:bg-red-600">Sale</Badge>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-xs text-muted-foreground">{product.brand}</p>
                      <div className="flex items-center">
                        <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                        <span className="text-xs ml-1">{product.rating.toFixed(1)}</span>
                      </div>
                    </div>
                    <h3 className="font-medium text-sm line-clamp-1">{product.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      {product.onSale ? (
                        <>
                          <span className="font-medium text-sm">${product.salePrice.toFixed(2)}</span>
                          <span className="text-xs text-muted-foreground line-through">
                            ${product.price.toFixed(2)}
                          </span>
                        </>
                      ) : (
                        <span className="font-medium text-sm">${product.price.toFixed(2)}</span>
                      )}
                    </div>
                    <Button variant="outline" size="sm" className="w-full mt-3" onClick={() => addToCart(product)}>
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Add to Cart
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Recommendations Section */}
      <section className="container px-4 py-8 md:px-6 md:py-12">
        <Tabs defaultValue="for-you" className="w-full">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold tracking-tight">Recommendations</h2>
            <TabsList>
              <TabsTrigger value="for-you">For You</TabsTrigger>
              <TabsTrigger value="top-rated">Top Rated</TabsTrigger>
              <TabsTrigger value="trending">Trending</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="for-you" className="mt-0">
            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                {Array(4)
                  .fill(0)
                  .map((_, i) => (
                    <Card key={i} className="overflow-hidden">
                      <div className="relative h-48 md:h-60">
                        <Skeleton className="h-full w-full" />
                      </div>
                      <CardContent className="p-4">
                        <Skeleton className="h-4 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-1/2 mb-4" />
                        <Skeleton className="h-4 w-1/4" />
                      </CardContent>
                    </Card>
                  ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                {featuredProducts.slice(0, 4).map((product) => (
                  <Card key={product.id} className="overflow-hidden h-full transition-all hover:shadow-lg">
                    <div className="relative h-48 md:h-60">
                      <Image
                        src={getProductImage(product.category, product.id) || "/placeholder.svg"}
                        alt={product.name}
                        fill
                        className="object-cover"
                      />
                      {product.onSale && (
                        <Badge className="absolute top-2 right-2 bg-red-500 hover:bg-red-600">Sale</Badge>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-xs text-muted-foreground">{product.brand}</p>
                        <div className="flex items-center">
                          <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                          <span className="text-xs ml-1">{product.rating.toFixed(1)}</span>
                        </div>
                      </div>
                      <h3 className="font-medium text-sm line-clamp-1">{product.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        {product.onSale ? (
                          <>
                            <span className="font-medium text-sm">${product.salePrice.toFixed(2)}</span>
                            <span className="text-xs text-muted-foreground line-through">
                              ${product.price.toFixed(2)}
                            </span>
                          </>
                        ) : (
                          <span className="font-medium text-sm">${product.price.toFixed(2)}</span>
                        )}
                      </div>
                      <Button variant="outline" size="sm" className="w-full mt-3" onClick={() => addToCart(product)}>
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Add to Cart
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="top-rated" className="mt-0">
            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                {Array(4)
                  .fill(0)
                  .map((_, i) => (
                    <Card key={i} className="overflow-hidden">
                      <div className="relative h-48 md:h-60">
                        <Skeleton className="h-full w-full" />
                      </div>
                      <CardContent className="p-4">
                        <Skeleton className="h-4 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-1/2 mb-4" />
                        <Skeleton className="h-4 w-1/4" />
                      </CardContent>
                    </Card>
                  ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                {[...categorizedProducts]
                  .sort((a, b) => b.rating - a.rating)
                  .slice(0, 4)
                  .map((product) => (
                    <Card key={product.id} className="overflow-hidden h-full transition-all hover:shadow-lg">
                      <div className="relative h-48 md:h-60">
                        <Image
                          src={getProductImage(product.category, product.id) || "/placeholder.svg"}
                          alt={product.name}
                          fill
                          className="object-cover"
                        />
                        <Badge className="absolute top-2 left-2 bg-yellow-500 hover:bg-yellow-600">Top Rated</Badge>
                        {product.onSale && (
                          <Badge className="absolute top-2 right-2 bg-red-500 hover:bg-red-600">Sale</Badge>
                        )}
                      </div>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-xs text-muted-foreground">{product.brand}</p>
                          <div className="flex items-center">
                            <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                            <span className="text-xs ml-1">{product.rating.toFixed(1)}</span>
                          </div>
                        </div>
                        <h3 className="font-medium text-sm line-clamp-1">{product.name}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          {product.onSale ? (
                            <>
                              <span className="font-medium text-sm">${product.salePrice.toFixed(2)}</span>
                              <span className="text-xs text-muted-foreground line-through">
                                ${product.price.toFixed(2)}
                              </span>
                            </>
                          ) : (
                            <span className="font-medium text-sm">${product.price.toFixed(2)}</span>
                          )}
                        </div>
                        <Button variant="outline" size="sm" className="w-full mt-3" onClick={() => addToCart(product)}>
                          <ShoppingCart className="h-4 w-4 mr-2" />
                          Add to Cart
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="trending" className="mt-0">
            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                {Array(4)
                  .fill(0)
                  .map((_, i) => (
                    <Card key={i} className="overflow-hidden">
                      <div className="relative h-48 md:h-60">
                        <Skeleton className="h-full w-full" />
                      </div>
                      <CardContent className="p-4">
                        <Skeleton className="h-4 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-1/2 mb-4" />
                        <Skeleton className="h-4 w-1/4" />
                      </CardContent>
                    </Card>
                  ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
                {bestSellers.slice(0, 4).map((product) => (
                  <Card key={product.id} className="overflow-hidden h-full transition-all hover:shadow-lg">
                    <div className="relative h-48 md:h-60">
                      <Image
                        src={getProductImage(product.category, product.id) || "/placeholder.svg"}
                        alt={product.name}
                        fill
                        className="object-cover"
                      />
                      <Badge className="absolute top-2 left-2 bg-blue-500 hover:bg-blue-600">Trending</Badge>
                      {product.onSale && (
                        <Badge className="absolute top-2 right-2 bg-red-500 hover:bg-red-600">Sale</Badge>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-xs text-muted-foreground">{product.brand}</p>
                        <div className="flex items-center">
                          <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                          <span className="text-xs ml-1">{product.rating.toFixed(1)}</span>
                        </div>
                      </div>
                      <h3 className="font-medium text-sm line-clamp-1">{product.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        {product.onSale ? (
                          <>
                            <span className="font-medium text-sm">${product.salePrice.toFixed(2)}</span>
                            <span className="text-xs text-muted-foreground line-through">
                              ${product.price.toFixed(2)}
                            </span>
                          </>
                        ) : (
                          <span className="font-medium text-sm">${product.price.toFixed(2)}</span>
                        )}
                      </div>
                      <Button variant="outline" size="sm" className="w-full mt-3" onClick={() => addToCart(product)}>
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Add to Cart
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </section>

      {/* Featured Categories */}
      <section className="container px-4 py-8 md:px-6 md:py-12">
        <h2 className="text-2xl font-bold tracking-tight mb-6">Featured Categories</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Link href="/category/electronics" className="group">
            <div className="relative h-[200px] rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=200&width=400&text=Electronics"
                alt="Electronics"
                fill
                className="object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-6">
                <h3 className="text-xl font-bold text-white">Electronics</h3>
                <p className="text-white/80 text-sm">Shop the latest gadgets and tech</p>
              </div>
            </div>
          </Link>
          <Link href="/category/books" className="group">
            <div className="relative h-[200px] rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=200&width=400&text=Books"
                alt="Books"
                fill
                className="object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-6">
                <h3 className="text-xl font-bold text-white">Books</h3>
                <p className="text-white/80 text-sm">Discover your next favorite read</p>
              </div>
            </div>
          </Link>
          <Link href="/category/home" className="group">
            <div className="relative h-[200px] rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=200&width=400&text=Home"
                alt="Home"
                fill
                className="object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-6">
                <h3 className="text-xl font-bold text-white">Home & Kitchen</h3>
                <p className="text-white/80 text-sm">Everything for your living space</p>
              </div>
            </div>
          </Link>
        </div>
      </section>

      {/* Sell on ShopHub Section */}
      <section className="container px-4 py-8 md:px-6 md:py-12">
        <div className="bg-muted rounded-lg p-8 md:p-12">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Gift className="h-6 w-6 text-primary" />
                <h2 className="text-2xl font-bold tracking-tight">Sell on ShopHub</h2>
              </div>
              <p className="text-muted-foreground mb-6">
                Reach millions of customers and grow your business with our e-commerce platform. We provide all the
                tools you need to succeed.
              </p>
              <div className="space-y-4">
                <div className="flex items-start gap-2">
                  <div className="p-1 rounded-full bg-primary/10 mt-0.5">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                      <path d="m7 10 3 3 7-7" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-medium">Easy Setup</h3>
                    <p className="text-sm text-muted-foreground">
                      Create your seller account and start listing products in minutes.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="p-1 rounded-full bg-primary/10 mt-0.5">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                      <path d="m7 10 3 3 7-7" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-medium">Powerful Tools</h3>
                    <p className="text-sm text-muted-foreground">
                      Access analytics, inventory management, and marketing tools.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="p-1 rounded-full bg-primary/10 mt-0.5">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                      <path d="m7 10 3 3 7-7" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-medium">Global Reach</h3>
                    <p className="text-sm text-muted-foreground">
                      Connect with customers around the world and expand your business.
                    </p>
                  </div>
                </div>
              </div>
              <Button asChild className="mt-6">
                <Link href="/sell">Start Selling</Link>
              </Button>
            </div>
            <div className="relative h-[300px] rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=300&width=500&text=Sell+on+ShopHub"
                alt="Sell on ShopHub"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="container px-4 py-12 md:px-6 md:py-16">
        <div className="bg-muted rounded-lg p-6 md:p-10">
          <div className="max-w-2xl mx-auto text-center">
            <div className="flex justify-center mb-4">
              <Percent className="h-10 w-10 text-primary" />
            </div>
            <h2 className="text-2xl font-bold tracking-tight mb-4">Subscribe to Our Newsletter</h2>
            <p className="text-muted-foreground mb-6">
              Stay updated with the latest products, exclusive offers, and shopping tips.
            </p>
            <div className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
              <Input type="email" placeholder="Enter your email" className="flex-1" />
              <Button>Subscribe</Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

