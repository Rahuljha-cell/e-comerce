"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, CreditCard, Landmark, Wallet, CheckCircle2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import LoadingSpinner from "@/components/loading-spinner"
import { useRouter } from "next/navigation"

export default function CheckoutPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [isProcessing, setIsProcessing] = useState(false)
  const [orderComplete, setOrderComplete] = useState(false)
  const [orderId, setOrderId] = useState("")

  // Form state
  const [shippingInfo, setShippingInfo] = useState({
    firstName: "",
    lastName: "",
    email: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    country: "",
    phone: "",
  })

  const [paymentInfo, setPaymentInfo] = useState({
    method: "credit-card",
    cardNumber: "",
    cardName: "",
    expiry: "",
    cvv: "",
  })

  // Mock cart data
  const cartItems = [
    {
      id: 1,
      name: "Premium Wireless Headphones",
      price: 199.99,
      quantity: 1,
      image: "/placeholder.svg?height=80&width=80&text=Headphones",
    },
    {
      id: 5,
      name: "Professional DSLR Camera",
      price: 1299.99,
      quantity: 1,
      image: "/placeholder.svg?height=80&width=80&text=Camera",
    },
    {
      id: 8,
      name: "Wireless Gaming Mouse",
      price: 69.99,
      quantity: 2,
      image: "/placeholder.svg?height=80&width=80&text=Mouse",
    },
  ]

  const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
  const shipping = subtotal > 100 ? 0 : 9.99
  const tax = subtotal * 0.08
  const total = subtotal + shipping + tax

  const handleShippingInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setShippingInfo((prev) => ({ ...prev, [name]: value }))
  }

  const handlePaymentInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setPaymentInfo((prev) => ({ ...prev, [name]: value }))
  }

  const validateShippingInfo = () => {
    const { firstName, lastName, email, address, city, state, zip, country, phone } = shippingInfo
    return firstName && lastName && email && address && city && state && zip && country && phone
  }

  const validatePaymentInfo = () => {
    if (paymentInfo.method !== "credit-card") return true

    const { cardNumber, cardName, expiry, cvv } = paymentInfo
    return cardNumber && cardName && expiry && cvv
  }

  const handleContinue = () => {
    if (step === 1) {
      if (!validateShippingInfo()) {
        toast({
          title: "Missing Information",
          description: "Please fill in all required shipping information.",
          variant: "destructive",
        })
        return
      }
      setStep(2)
    } else if (step === 2) {
      if (!validatePaymentInfo()) {
        toast({
          title: "Missing Information",
          description: "Please fill in all required payment information.",
          variant: "destructive",
        })
        return
      }
      setStep(3)
    }
  }

  const handlePlaceOrder = async () => {
    setIsProcessing(true)

    // Simulate order processing
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Generate a random order ID
    const generatedOrderId = `ORD-${Math.floor(100000 + Math.random() * 900000)}`
    setOrderId(generatedOrderId)

    setIsProcessing(false)
    setOrderComplete(true)

    toast({
      title: "Order Placed Successfully!",
      description: `Your order #${generatedOrderId} has been placed successfully.`,
    })
  }

  if (orderComplete) {
    return (
      <div className="container px-4 py-8 md:px-6 md:py-12 max-w-4xl mx-auto">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
            <CheckCircle2 className="h-8 w-8 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold">Order Placed Successfully!</h1>
          <p className="text-muted-foreground">Thank you for your purchase. Your order has been placed successfully.</p>
          <div className="bg-muted p-4 rounded-lg inline-block mt-4">
            <p className="font-medium">Order ID: {orderId}</p>
          </div>

          <div className="mt-8 space-y-4">
            <p>
              We've sent a confirmation email to <span className="font-medium">{shippingInfo.email}</span> with your
              order details.
            </p>
            <p>Your items will be shipped to:</p>
            <div className="bg-muted p-4 rounded-lg text-left inline-block">
              <p>
                {shippingInfo.firstName} {shippingInfo.lastName}
                <br />
                {shippingInfo.address}
                <br />
                {shippingInfo.city}, {shippingInfo.state} {shippingInfo.zip}
                <br />
                {shippingInfo.country}
                <br />
                {shippingInfo.phone}
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
            <Button asChild>
              <Link href="/">Continue Shopping</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/account/orders">View My Orders</Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Toaster />
      <Link href="/cart" className="flex items-center text-sm mb-6 hover:underline">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Cart
      </Link>
      <h1 className="text-2xl font-bold tracking-tight mb-6">Checkout</h1>
      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          <div className="flex justify-between mb-4">
            <div className="flex items-center">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
              >
                1
              </div>
              <span className="ml-2 font-medium">Shipping</span>
            </div>
            <div className="flex items-center">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
              >
                2
              </div>
              <span className="ml-2 font-medium">Payment</span>
            </div>
            <div className="flex items-center">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
              >
                3
              </div>
              <span className="ml-2 font-medium">Review</span>
            </div>
          </div>

          {step === 1 && (
            <Card>
              <CardHeader>
                <CardTitle>Shipping Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">
                      First Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      placeholder="John"
                      value={shippingInfo.firstName}
                      onChange={handleShippingInfoChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">
                      Last Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      placeholder="Doe"
                      value={shippingInfo.lastName}
                      onChange={handleShippingInfoChange}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">
                    Email <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="john.doe@example.com"
                    value={shippingInfo.email}
                    onChange={handleShippingInfoChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">
                    Address <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="address"
                    name="address"
                    placeholder="123 Main St"
                    value={shippingInfo.address}
                    onChange={handleShippingInfoChange}
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">
                      City <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="city"
                      name="city"
                      placeholder="New York"
                      value={shippingInfo.city}
                      onChange={handleShippingInfoChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="state">
                      State <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="state"
                      name="state"
                      placeholder="NY"
                      value={shippingInfo.state}
                      onChange={handleShippingInfoChange}
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="zip">
                      ZIP Code <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="zip"
                      name="zip"
                      placeholder="10001"
                      value={shippingInfo.zip}
                      onChange={handleShippingInfoChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="country">
                      Country <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="country"
                      name="country"
                      placeholder="United States"
                      value={shippingInfo.country}
                      onChange={handleShippingInfoChange}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">
                    Phone <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="phone"
                    name="phone"
                    placeholder="(123) 456-7890"
                    value={shippingInfo.phone}
                    onChange={handleShippingInfoChange}
                    required
                  />
                </div>
                <Button className="w-full" onClick={handleContinue}>
                  Continue to Payment
                </Button>
              </CardContent>
            </Card>
          )}

          {step === 2 && (
            <Card>
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <Tabs
                  defaultValue="credit-card"
                  value={paymentInfo.method}
                  onValueChange={(value) => setPaymentInfo((prev) => ({ ...prev, method: value }))}
                >
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="credit-card" className="flex items-center gap-2">
                      <CreditCard className="h-4 w-4" />
                      Credit Card
                    </TabsTrigger>
                    <TabsTrigger value="bank-transfer" className="flex items-center gap-2">
                      <Landmark className="h-4 w-4" />
                      Bank Transfer
                    </TabsTrigger>
                    <TabsTrigger value="paypal" className="flex items-center gap-2">
                      <Wallet className="h-4 w-4" />
                      PayPal
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="credit-card" className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="cardNumber">
                        Card Number <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="cardNumber"
                        name="cardNumber"
                        placeholder="1234 5678 9012 3456"
                        value={paymentInfo.cardNumber}
                        onChange={handlePaymentInfoChange}
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="expiry">
                          Expiry Date <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="expiry"
                          name="expiry"
                          placeholder="MM/YY"
                          value={paymentInfo.expiry}
                          onChange={handlePaymentInfoChange}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cvv">
                          CVV <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="cvv"
                          name="cvv"
                          placeholder="123"
                          value={paymentInfo.cvv}
                          onChange={handlePaymentInfoChange}
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cardName">
                        Name on Card <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="cardName"
                        name="cardName"
                        placeholder="John Doe"
                        value={paymentInfo.cardName}
                        onChange={handlePaymentInfoChange}
                        required
                      />
                    </div>
                  </TabsContent>
                  <TabsContent value="bank-transfer" className="pt-4">
                    <div className="space-y-4">
                      <p className="text-muted-foreground">
                        Make your payment directly into our bank account. Please use your Order ID as the payment
                        reference.
                      </p>
                      <div className="bg-muted p-4 rounded-lg">
                        <p className="font-medium">Bank: National Bank</p>
                        <p>Account Name: ShopHub Inc.</p>
                        <p>Account Number: 1234567890</p>
                        <p>Routing Number: 987654321</p>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="paypal" className="pt-4">
                    <div className="space-y-4">
                      <p className="text-muted-foreground">
                        You will be redirected to PayPal to complete your purchase securely.
                      </p>
                      <div className="flex justify-center">
                        <Image
                          src="/placeholder.svg?height=60&width=200&text=PayPal"
                          alt="PayPal"
                          width={200}
                          height={60}
                          className="object-contain"
                        />
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
                <div className="flex gap-4">
                  <Button variant="outline" className="w-full" onClick={() => setStep(1)}>
                    Back
                  </Button>
                  <Button className="w-full" onClick={handleContinue}>
                    Continue to Review
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {step === 3 && (
            <Card>
              <CardHeader>
                <CardTitle>Review Your Order</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-2">Shipping Address</h3>
                  <p className="text-muted-foreground">
                    {shippingInfo.firstName} {shippingInfo.lastName}
                    <br />
                    {shippingInfo.address}
                    <br />
                    {shippingInfo.city}, {shippingInfo.state} {shippingInfo.zip}
                    <br />
                    {shippingInfo.country}
                    <br />
                    {shippingInfo.phone}
                  </p>
                </div>
                <Separator />
                <div>
                  <h3 className="font-semibold mb-2">Payment Method</h3>
                  <div className="flex items-center">
                    {paymentInfo.method === "credit-card" ? (
                      <>
                        <CreditCard className="h-4 w-4 mr-2" />
                        <p className="text-muted-foreground">
                          Credit Card ending in {paymentInfo.cardNumber.slice(-4)}
                        </p>
                      </>
                    ) : paymentInfo.method === "bank-transfer" ? (
                      <>
                        <Landmark className="h-4 w-4 mr-2" />
                        <p className="text-muted-foreground">Bank Transfer</p>
                      </>
                    ) : (
                      <>
                        <Wallet className="h-4 w-4 mr-2" />
                        <p className="text-muted-foreground">PayPal</p>
                      </>
                    )}
                  </div>
                </div>
                <Separator />
                <div>
                  <h3 className="font-semibold mb-2">Items</h3>
                  <div className="space-y-4">
                    {cartItems.map((item) => (
                      <div key={item.id} className="flex gap-4">
                        <div className="relative w-16 h-16 rounded-md overflow-hidden">
                          <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{item.name}</p>
                          <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                        </div>
                        <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="flex gap-4">
                  <Button variant="outline" className="w-full" onClick={() => setStep(2)}>
                    Back
                  </Button>
                  <Button className="w-full" onClick={handlePlaceOrder} disabled={isProcessing}>
                    {isProcessing ? (
                      <>
                        <LoadingSpinner size="small" />
                        <span className="ml-2">Processing...</span>
                      </>
                    ) : (
                      "Place Order"
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {cartItems.map((item) => (
                <div key={item.id} className="flex justify-between">
                  <span className="text-muted-foreground">
                    {item.name} x {item.quantity}
                  </span>
                  <span>${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              <Separator />
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                {shipping === 0 ? <span className="text-green-600">Free</span> : <span>${shipping.toFixed(2)}</span>}
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tax</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-semibold">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

