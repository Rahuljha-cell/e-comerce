"use client"

import { Skeleton } from "@/components/ui/skeleton"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { Trash, Plus, Minus, ArrowRight, CheckCircle2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import LoadingSpinner from "@/components/loading-spinner"

// Define product categories
const categories = [
  { id: "electronics", name: "Electronics", icon: "💻" },
  { id: "mens-clothing", name: "Men's Clothing", icon: "👔" },
  { id: "womens-clothing", name: "Women's Clothing", icon: "👗" },
  { id: "jewelry", name: "Jewelry & Watches", icon: "💍" },
  { id: "home", name: "Home & Kitchen", icon: "🏠" },
  { id: "beauty", name: "Beauty & Personal Care", icon: "💄" },
  { id: "sports", name: "Sports & Outdoors", icon: "🏀" },
  { id: "toys", name: "Toys & Games", icon: "🎮" },
]

// Define product images for different categories
const productImages = {
  electronics: ["/placeholder.svg?height=100&width=100&text=Electronics"],
  "mens-clothing": ["/placeholder.svg?height=100&width=100&text=Mens+Clothing"],
  "womens-clothing": ["/placeholder.svg?height=100&width=100&text=Womens+Clothing"],
  jewelry: ["/placeholder.svg?height=100&width=100&text=Jewelry"],
  home: ["/placeholder.svg?height=100&width=100&text=Home"],
  beauty: ["/placeholder.svg?height=100&width=100&text=Beauty"],
  sports: ["/placeholder.svg?height=100&width=100&text=Sports"],
  toys: ["/placeholder.svg?height=100&width=100&text=Toys"],
}

// Get a product image based on category
const getProductImage = (category: string) => {
  return productImages[category as keyof typeof productImages]?.[0] || productImages.electronics[0]
}

export default function CartPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [cartItems, setCartItems] = useState<any[]>([])
  const [couponCode, setCouponCode] = useState("")
  const [isApplyingCoupon, setIsApplyingCoupon] = useState(false)
  const [couponApplied, setCouponApplied] = useState(false)
  const [discount, setDiscount] = useState(0)

  // Load cart items
  useEffect(() => {
    // Simulate API call to fetch cart items
    setTimeout(() => {
      const mockCartItems = [
        {
          id: 1,
          name: "Premium Wireless Headphones",
          price: 199.99,
          quantity: 1,
          category: "electronics",
        },
        {
          id: 5,
          name: "Professional DSLR Camera",
          price: 1299.99,
          quantity: 1,
          category: "electronics",
        },
        {
          id: 8,
          name: "Wireless Gaming Mouse",
          price: 69.99,
          quantity: 2,
          category: "electronics",
        },
      ]

      setCartItems(mockCartItems)
      setIsLoading(false)
    }, 1000)
  }, [])

  const updateQuantity = (id: number, newQuantity: number) => {
    if (newQuantity < 1) return

    setCartItems(cartItems.map((item) => (item.id === id ? { ...item, quantity: newQuantity } : item)))

    toast({
      title: "Cart Updated",
      description: "Your cart has been updated successfully.",
    })
  }

  const removeItem = (id: number) => {
    setCartItems(cartItems.filter((item) => item.id !== id))

    toast({
      title: "Item Removed",
      description: "The item has been removed from your cart.",
    })
  }

  const applyCoupon = async () => {
    if (!couponCode.trim()) {
      toast({
        title: "Error",
        description: "Please enter a coupon code.",
        variant: "destructive",
      })
      return
    }

    setIsApplyingCoupon(true)

    // Simulate API call to validate coupon
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (couponCode.toUpperCase() === "SAVE20") {
      const subtotal = calculateSubtotal()
      const discountAmount = subtotal * 0.2
      setDiscount(discountAmount)
      setCouponApplied(true)

      toast({
        title: "Coupon Applied",
        description: "Your coupon has been applied successfully.",
      })
    } else {
      toast({
        title: "Invalid Coupon",
        description: "The coupon code you entered is invalid or expired.",
        variant: "destructive",
      })
    }

    setIsApplyingCoupon(false)
  }

  const calculateSubtotal = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const subtotal = calculateSubtotal()
  const shipping = subtotal > 100 ? 0 : 9.99
  const tax = subtotal * 0.08
  const total = subtotal + shipping + tax - discount

  if (isLoading) {
    return (
      <div className="container px-4 py-8 md:px-6 md:py-12">
        <h1 className="text-2xl font-bold tracking-tight mb-6">Shopping Cart</h1>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-4 py-4 border-b">
                <Skeleton className="h-24 w-24 rounded-md" />
                <div className="flex-1 flex flex-col gap-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/4" />
                  <div className="flex items-center justify-between mt-auto">
                    <Skeleton className="h-8 w-24" />
                    <Skeleton className="h-4 w-16" />
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div>
            <Skeleton className="h-[300px] w-full rounded-md" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Toaster />

      <h1 className="text-2xl font-bold tracking-tight mb-6">Shopping Cart</h1>
      {cartItems.length === 0 ? (
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold mb-4">Your cart is empty</h2>
          <p className="text-muted-foreground mb-6">Looks like you haven't added anything to your cart yet.</p>
          <Button asChild>
            <Link href="/products">Continue Shopping</Link>
          </Button>
        </div>
      ) : (
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-4">
            {cartItems.map((item) => (
              <div key={item.id} className="flex gap-4 py-4 border-b">
                <div className="relative w-24 h-24 rounded-md overflow-hidden">
                  <Image
                    src={getProductImage(item.category) || "/placeholder.svg"}
                    alt={item.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="flex-1 flex flex-col">
                  <div className="flex justify-between">
                    <Link href={`/products/${item.id}`} className="font-semibold hover:underline">
                      {item.name}
                    </Link>
                    <Button variant="ghost" size="icon" onClick={() => removeItem(item.id)}>
                      <Trash className="h-4 w-4" />
                      <span className="sr-only">Remove</span>
                    </Button>
                  </div>
                  <p className="text-muted-foreground text-sm">${item.price.toFixed(2)}</p>
                  <div className="flex items-center mt-auto">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 rounded-r-none"
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    >
                      <Minus className="h-3 w-3" />
                      <span className="sr-only">Decrease</span>
                    </Button>
                    <Input
                      type="number"
                      min="1"
                      value={item.quantity}
                      onChange={(e) => updateQuantity(item.id, Number.parseInt(e.target.value))}
                      className="h-8 w-12 rounded-none text-center [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                    />
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 rounded-l-none"
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    >
                      <Plus className="h-3 w-3" />
                      <span className="sr-only">Increase</span>
                    </Button>
                    <span className="ml-auto font-medium">${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                </div>
              </div>
            ))}
            <div className="flex justify-between items-center pt-4">
              <Button variant="outline" asChild>
                <Link href="/products">Continue Shopping</Link>
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  toast({
                    title: "Cart Updated",
                    description: "Your cart has been updated successfully.",
                  })
                }}
              >
                Update Cart
              </Button>
            </div>
          </div>
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount</span>
                    <span>-${discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  {shipping === 0 ? <span className="text-green-600">Free</span> : <span>${shipping.toFixed(2)}</span>}
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tax</span>
                  <span>${tax.toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex justify-between font-semibold">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full" asChild>
                  <Link href="/checkout">
                    Proceed to Checkout
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
            <Card className="mt-4">
              <CardHeader>
                <CardTitle>Have a coupon?</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter coupon code"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    disabled={couponApplied || isApplyingCoupon}
                  />
                  {couponApplied ? (
                    <Button variant="outline" className="shrink-0" disabled>
                      <CheckCircle2 className="h-4 w-4 mr-2 text-green-600" />
                      Applied
                    </Button>
                  ) : (
                    <Button variant="outline" onClick={applyCoupon} disabled={isApplyingCoupon} className="shrink-0">
                      {isApplyingCoupon ? (
                        <>
                          <LoadingSpinner size="small" />
                          <span className="ml-2">Applying...</span>
                        </>
                      ) : (
                        "Apply"
                      )}
                    </Button>
                  )}
                </div>
                {couponApplied && <p className="text-sm text-green-600 mt-2">Coupon "SAVE20" applied: 20% discount</p>}
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}

