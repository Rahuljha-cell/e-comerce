import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export default function CareersPage() {
  // Mock job listings
  const jobListings = [
    {
      id: 1,
      title: "Senior Frontend Developer",
      department: "Engineering",
      location: "New York, NY",
      type: "Full-time",
      remote: true,
      description:
        "We're looking for a Senior Frontend Developer to join our engineering team and help build the next generation of our e-commerce platform.",
      requirements: [
        "5+ years of experience with React and modern JavaScript",
        "Experience with Next.js and TypeScript",
        "Strong understanding of web performance optimization",
        "Experience with responsive design and cross-browser compatibility",
        "Excellent problem-solving skills and attention to detail",
      ],
    },
    {
      id: 2,
      title: "UX/UI Designer",
      department: "Design",
      location: "San Francisco, CA",
      type: "Full-time",
      remote: true,
      description:
        "We're seeking a talented UX/UI Designer to create beautiful, intuitive interfaces for our e-commerce platform and mobile applications.",
      requirements: [
        "3+ years of experience in UX/UI design for web and mobile applications",
        "Proficiency in design tools such as Figma, Sketch, or Adobe XD",
        "Strong portfolio demonstrating user-centered design process",
        "Experience with design systems and component libraries",
        "Knowledge of accessibility standards and best practices",
      ],
    },
    {
      id: 3,
      title: "Product Manager",
      department: "Product",
      location: "Chicago, IL",
      type: "Full-time",
      remote: false,
      description:
        "We're looking for a Product Manager to lead the development of new features and improvements to our e-commerce platform.",
      requirements: [
        "3+ years of experience in product management, preferably in e-commerce",
        "Strong analytical skills and data-driven decision making",
        "Excellent communication and stakeholder management skills",
        "Experience with agile development methodologies",
        "Bachelor's degree in Business, Computer Science, or related field",
      ],
    },
    {
      id: 4,
      title: "Customer Support Specialist",
      department: "Customer Service",
      location: "Remote",
      type: "Full-time",
      remote: true,
      description:
        "We're seeking a Customer Support Specialist to provide exceptional service to our customers and help resolve their issues.",
      requirements: [
        "2+ years of experience in customer service, preferably in e-commerce",
        "Excellent communication skills, both written and verbal",
        "Problem-solving mindset and ability to work independently",
        "Experience with customer service tools and CRM systems",
        "Ability to work in a fast-paced environment",
      ],
    },
    {
      id: 5,
      title: "Digital Marketing Specialist",
      department: "Marketing",
      location: "Miami, FL",
      type: "Full-time",
      remote: true,
      description:
        "We're looking for a Digital Marketing Specialist to help grow our online presence and drive customer acquisition.",
      requirements: [
        "3+ years of experience in digital marketing, preferably in e-commerce",
        "Experience with SEO, SEM, social media marketing, and email campaigns",
        "Proficiency in marketing analytics tools and data analysis",
        "Strong copywriting and content creation skills",
        "Bachelor's degree in Marketing, Communications, or related field",
      ],
    },
    {
      id: 6,
      title: "Backend Developer",
      department: "Engineering",
      location: "Austin, TX",
      type: "Full-time",
      remote: true,
      description:
        "We're seeking a Backend Developer to build and maintain the server-side of our e-commerce platform.",
      requirements: [
        "4+ years of experience with Node.js, Python, or similar backend technologies",
        "Experience with RESTful APIs and GraphQL",
        "Knowledge of database systems (SQL and NoSQL)",
        "Understanding of cloud services (AWS, Azure, or GCP)",
        "Experience with microservices architecture",
      ],
    },
  ]

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <div className="flex flex-col items-center text-center space-y-4 mb-12">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Join Our Team</h1>
        <p className="text-muted-foreground max-w-[700px] md:text-xl">
          We're building the future of e-commerce and we're looking for talented individuals to join us on this journey.
        </p>
      </div>

      {/* Why Join Us Section */}
      <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
        <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden">
          <Image
            src="/placeholder.svg?height=400&width=600&text=Team+Culture"
            alt="Team Culture"
            fill
            className="object-cover"
          />
        </div>
        <div className="space-y-4">
          <h2 className="text-2xl font-bold tracking-tight">Why Join ShopHub?</h2>
          <p className="text-muted-foreground">
            At ShopHub, we're more than just an e-commerce platform. We're a team of passionate individuals working
            together to revolutionize the way people shop online. We value innovation, collaboration, and personal
            growth, and we're committed to creating an inclusive and supportive work environment.
          </p>
          <div className="grid grid-cols-2 gap-4 pt-4">
            <div className="flex items-start gap-2">
              <div className="p-2 rounded-full bg-primary/10 mt-0.5">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-primary"
                >
                  <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                  <path d="m7 10 3 3 7-7" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Competitive Salary</h3>
                <p className="text-sm text-muted-foreground">We offer competitive compensation packages.</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="p-2 rounded-full bg-primary/10 mt-0.5">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-primary"
                >
                  <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                  <path d="m7 10 3 3 7-7" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Health Benefits</h3>
                <p className="text-sm text-muted-foreground">Comprehensive health, dental, and vision coverage.</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="p-2 rounded-full bg-primary/10 mt-0.5">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-primary"
                >
                  <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                  <path d="m7 10 3 3 7-7" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Remote Work</h3>
                <p className="text-sm text-muted-foreground">Flexible work arrangements for many positions.</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="p-2 rounded-full bg-primary/10 mt-0.5">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinec
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-primary"
                >
                  <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                  <path d="m7 10 3 3 7-7" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Professional Growth</h3>
                <p className="text-sm text-muted-foreground">
                  Continuous learning and career development opportunities.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Open Positions */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold tracking-tight mb-8">Open Positions</h2>
        <Tabs defaultValue="all">
          <div className="flex justify-between items-center mb-6">
            <TabsList>
              <TabsTrigger value="all">All Departments</TabsTrigger>
              <TabsTrigger value="engineering">Engineering</TabsTrigger>
              <TabsTrigger value="design">Design</TabsTrigger>
              <TabsTrigger value="product">Product</TabsTrigger>
              <TabsTrigger value="marketing">Marketing</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="all" className="space-y-6">
            {jobListings.map((job) => (
              <JobCard key={job.id} job={job} />
            ))}
          </TabsContent>

          <TabsContent value="engineering" className="space-y-6">
            {jobListings
              .filter((job) => job.department === "Engineering")
              .map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
          </TabsContent>

          <TabsContent value="design" className="space-y-6">
            {jobListings
              .filter((job) => job.department === "Design")
              .map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
          </TabsContent>

          <TabsContent value="product" className="space-y-6">
            {jobListings
              .filter((job) => job.department === "Product")
              .map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
          </TabsContent>

          <TabsContent value="marketing" className="space-y-6">
            {jobListings
              .filter((job) => job.department === "Marketing")
              .map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
          </TabsContent>
        </Tabs>
      </div>

      {/* Application Process */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold tracking-tight text-center mb-8">Our Application Process</h2>
        <div className="grid md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">
                  1
                </div>
                <h3 className="font-semibold">Apply Online</h3>
                <p className="text-sm text-muted-foreground">
                  Submit your application through our careers page with your resume and cover letter.
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">
                  2
                </div>
                <h3 className="font-semibold">Initial Screening</h3>
                <p className="text-sm text-muted-foreground">
                  Our recruiting team will review your application and reach out for an initial phone interview.
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">
                  3
                </div>
                <h3 className="font-semibold">Skills Assessment</h3>
                <p className="text-sm text-muted-foreground">
                  Depending on the role, you may be asked to complete a skills assessment or technical interview.
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">
                  4
                </div>
                <h3 className="font-semibold">Final Interview</h3>
                <p className="text-sm text-muted-foreground">
                  Meet with the team and discuss your experience, skills, and how you can contribute to ShopHub.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-muted rounded-lg p-8 text-center">
        <h2 className="text-2xl font-bold tracking-tight mb-4">Don't See a Position That Fits?</h2>
        <p className="text-muted-foreground max-w-[700px] mx-auto mb-6">
          We're always on the lookout for talented individuals to join our team. Send us your resume and we'll keep it
          on file for future opportunities.
        </p>
        <Button asChild size="lg">
          <Link href="/contact">Contact Us</Link>
        </Button>
      </div>
    </div>
  )
}

// Job Card Component
function JobCard({ job }: { job: any }) {
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <CardTitle>{job.title}</CardTitle>
            <CardDescription>
              {job.department} • {job.location}
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline">{job.type}</Badge>
            {job.remote && <Badge variant="secondary">Remote</Badge>}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground mb-4">{job.description}</p>
        <div className="space-y-2">
          <h4 className="font-semibold">Requirements:</h4>
          <ul className="list-disc pl-5 space-y-1">
            {job.requirements.map((req: string, index: number) => (
              <li key={index} className="text-sm text-muted-foreground">
                {req}
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
      <CardFooter>
        <Button asChild className="w-full sm:w-auto">
          <Link href={`/careers/${job.id}`}>Apply Now</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

