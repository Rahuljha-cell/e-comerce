"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { ShoppingCart, Star, Filter, Search } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { mockProducts } from "@/lib/mock-data"

// Define product categories
const categories = [
  {
    id: "electronics",
    name: "Electronics",
    icon: "💻",
    banner: "/placeholder.svg?height=300&width=1200&text=Electronics",
  },
  {
    id: "mens-clothing",
    name: "Men's Clothing",
    icon: "👔",
    banner: "/placeholder.svg?height=300&width=1200&text=Men's+Clothing",
  },
  {
    id: "womens-clothing",
    name: "Women's Clothing",
    icon: "👗",
    banner: "/placeholder.svg?height=300&width=1200&text=Women's+Clothing",
  },
  {
    id: "jewelry",
    name: "Jewelry & Watches",
    icon: "💍",
    banner: "/placeholder.svg?height=300&width=1200&text=Jewelry+&+Watches",
  },
  {
    id: "home",
    name: "Home & Kitchen",
    icon: "🏠",
    banner: "/placeholder.svg?height=300&width=1200&text=Home+&+Kitchen",
  },
  {
    id: "beauty",
    name: "Beauty & Personal Care",
    icon: "💄",
    banner: "/placeholder.svg?height=300&width=1200&text=Beauty+&+Personal+Care",
  },
  {
    id: "sports",
    name: "Sports & Outdoors",
    icon: "🏀",
    banner: "/placeholder.svg?height=300&width=1200&text=Sports+&+Outdoors",
  },
  { id: "toys", name: "Toys & Games", icon: "🎮", banner: "/placeholder.svg?height=300&width=1200&text=Toys+&+Games" },
]

// Extend mock products with categories
const categorizedProducts = mockProducts.map((product) => {
  let category = "electronics"

  if (product.id % 8 === 0) category = "mens-clothing"
  else if (product.id % 7 === 0) category = "womens-clothing"
  else if (product.id % 6 === 0) category = "jewelry"
  else if (product.id % 5 === 0) category = "home"
  else if (product.id % 4 === 0) category = "beauty"
  else if (product.id % 3 === 0) category = "sports"
  else if (product.id % 2 === 0) category = "toys"

  return {
    ...product,
    category,
  }
})

// Define product images for different categories
const productImages = {
  electronics: ["/placeholder.svg?height=300&width=300&text=Electronics"],
  "mens-clothing": ["/placeholder.svg?height=300&width=300&text=Mens+Clothing"],
  "womens-clothing": ["/placeholder.svg?height=300&width=300&text=Womens+Clothing"],
  jewelry: ["/placeholder.svg?height=300&width=300&text=Jewelry"],
  home: ["/placeholder.svg?height=300&width=300&text=Home"],
  beauty: ["/placeholder.svg?height=300&width=300&text=Beauty"],
  sports: ["/placeholder.svg?height=300&width=300&text=Sports"],
  toys: ["/placeholder.svg?height=300&width=300&text=Toys"],
}

// Get a product image based on category
const getProductImage = (category: string) => {
  return productImages[category as keyof typeof productImages]?.[0] || productImages.electronics[0]
}

export default function CategoryPage({ params }: { params: { slug: string } }) {
  const [isLoading, setIsLoading] = useState(true)
  const [category, setCategory] = useState<any>(null)
  const [products, setProducts] = useState<any[]>([])
  const [filteredProducts, setFilteredProducts] = useState<any[]>([])
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1500])
  const [selectedBrands, setSelectedBrands] = useState<string[]>([])
  const [selectedColors, setSelectedColors] = useState<string[]>([])
  const [showFilters, setShowFilters] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [sortOption, setSortOption] = useState("featured")

  // Get min and max prices
  const minPrice = 0
  const maxPrice = 1500

  // Load category and products
  useEffect(() => {
    const categorySlug = params.slug
    const foundCategory = categories.find((c) => c.id === categorySlug)

    if (foundCategory) {
      setCategory(foundCategory)

      // Filter products by category
      const categoryProducts = categorizedProducts.filter((p) => p.category === categorySlug)
      setProducts(categoryProducts)
      setFilteredProducts(categoryProducts)
    }

    setIsLoading(false)
  }, [params.slug])

  // Get unique brands and colors for this category
  const allBrands = [...new Set(products.map((p) => p.brand))]
  const allColors = [...new Set(products.map((p) => p.color))]

  // Filter products based on price range, brands, colors, and search
  useEffect(() => {
    let result = [...products]

    // Filter by price range
    result = result.filter((p) => p.price >= priceRange[0] && p.price <= priceRange[1])

    // Filter by brands
    if (selectedBrands.length > 0) {
      result = result.filter((p) => selectedBrands.includes(p.brand))
    }

    // Filter by colors
    if (selectedColors.length > 0) {
      result = result.filter((p) => selectedColors.includes(p.color))
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query) ||
          p.brand.toLowerCase().includes(query),
      )
    }

    // Sort products
    result = sortProducts(result, sortOption)

    setFilteredProducts(result)
  }, [products, priceRange, selectedBrands, selectedColors, searchQuery, sortOption])

  // Sort products based on selected option
  const sortProducts = (products: any[], option: string) => {
    switch (option) {
      case "featured":
        return [...products].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0))
      case "newest":
        return [...products].sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime())
      case "price-low":
        return [...products].sort((a, b) => a.price - b.price)
      case "price-high":
        return [...products].sort((a, b) => b.price - a.price)
      case "best-selling":
        return [...products].sort((a, b) => b.salesCount - a.salesCount)
      case "rating":
        return [...products].sort((a, b) => b.rating - a.rating)
      default:
        return products
    }
  }

  // Toggle brand selection
  const toggleBrand = (brand: string) => {
    setSelectedBrands((prev) => (prev.includes(brand) ? prev.filter((b) => b !== brand) : [...prev, brand]))
  }

  // Toggle color selection
  const toggleColor = (color: string) => {
    setSelectedColors((prev) => (prev.includes(color) ? prev.filter((c) => c !== color) : [...prev, color]))
  }

  // Reset all filters
  const resetFilters = () => {
    setPriceRange([minPrice, maxPrice])
    setSelectedBrands([])
    setSelectedColors([])
    setSearchQuery("")
    setSortOption("featured")
  }

  // Add to cart function
  const addToCart = (product: any) => {
    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart.`,
      action: (
        <Link href="/cart">
          <Button variant="outline" size="sm">
            View Cart
          </Button>
        </Link>
      ),
    })
  }

  if (isLoading) {
    return (
      <div className="container px-4 py-8 md:px-6 md:py-12">
        <Skeleton className="h-[200px] w-full rounded-lg mb-8" />
        <Skeleton className="h-10 w-64 mb-4" />
        <Skeleton className="h-6 w-full max-w-md mb-8" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array(8)
            .fill(0)
            .map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <div className="relative h-48 md:h-60">
                  <Skeleton className="h-full w-full" />
                </div>
                <CardContent className="p-4">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2 mb-4" />
                  <Skeleton className="h-4 w-1/4" />
                </CardContent>
              </Card>
            ))}
        </div>
      </div>
    )
  }

  if (!category) {
    return (
      <div className="container px-4 py-8 md:px-6 md:py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Category Not Found</h1>
        <p className="text-muted-foreground mb-6">The category you are looking for does not exist.</p>
        <Button asChild>
          <Link href="/">Back to Home</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Toaster />

      {/* Category Banner */}
      <div className="relative h-[200px] md:h-[300px] w-full rounded-lg overflow-hidden mb-8">
        <Image src={category.banner || "/placeholder.svg"} alt={category.name} fill className="object-cover" priority />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex flex-col justify-center p-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">{category.name}</h1>
          <p className="text-white/80 max-w-md">Explore our collection of {category.name.toLowerCase()} products.</p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Filters - Desktop */}
        <div className="hidden md:block w-64 shrink-0">
          <div className="sticky top-24 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Filters</h3>
              <Button variant="ghost" size="sm" onClick={resetFilters} className="h-8 text-xs">
                Reset All
              </Button>
            </div>

            <Accordion type="multiple" defaultValue={["price", "brand", "color"]}>
              {/* Price Range Filter */}
              <AccordionItem value="price">
                <AccordionTrigger>Price Range</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4">
                    <Slider
                      min={minPrice}
                      max={maxPrice}
                      step={10}
                      value={priceRange}
                      onValueChange={(value) => setPriceRange(value as [number, number])}
                    />
                    <div className="flex items-center justify-between">
                      <div className="flex items-center border rounded-md">
                        <span className="pl-2 text-muted-foreground">$</span>
                        <Input
                          type="number"
                          min={minPrice}
                          max={priceRange[1]}
                          value={priceRange[0]}
                          onChange={(e) => {
                            const value = Number(e.target.value)
                            if (!isNaN(value)) {
                              setPriceRange([value, priceRange[1]])
                            }
                          }}
                          className="border-0 w-20"
                        />
                      </div>
                      <span className="text-muted-foreground">to</span>
                      <div className="flex items-center border rounded-md">
                        <span className="pl-2 text-muted-foreground">$</span>
                        <Input
                          type="number"
                          min={priceRange[0]}
                          max={maxPrice}
                          value={priceRange[1]}
                          onChange={(e) => {
                            const value = Number(e.target.value)
                            if (!isNaN(value)) {
                              setPriceRange([priceRange[0], value])
                            }
                          }}
                          className="border-0 w-20"
                        />
                      </div>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Brand Filter */}
              <AccordionItem value="brand">
                <AccordionTrigger>Brand</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2 max-h-[200px] overflow-y-auto pr-2">
                    {allBrands.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No brands available</p>
                    ) : (
                      allBrands.map((brand) => (
                        <div key={brand} className="flex items-center space-x-2">
                          <Checkbox
                            id={`brand-${brand}`}
                            checked={selectedBrands.includes(brand)}
                            onCheckedChange={() => toggleBrand(brand)}
                          />
                          <Label htmlFor={`brand-${brand}`} className="text-sm font-normal cursor-pointer">
                            {brand}
                          </Label>
                        </div>
                      ))
                    )}
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Color Filter */}
              <AccordionItem value="color">
                <AccordionTrigger>Color</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2 max-h-[200px] overflow-y-auto pr-2">
                    {allColors.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No colors available</p>
                    ) : (
                      allColors.map((color) => (
                        <div key={color} className="flex items-center space-x-2">
                          <Checkbox
                            id={`color-${color}`}
                            checked={selectedColors.includes(color)}
                            onCheckedChange={() => toggleColor(color)}
                          />
                          <div
                            className="w-4 h-4 rounded-full border"
                            style={{ backgroundColor: color.toLowerCase() }}
                          />
                          <Label htmlFor={`color-${color}`} className="text-sm font-normal cursor-pointer">
                            {color}
                          </Label>
                        </div>
                      ))
                    )}
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Other Filters */}
              <AccordionItem value="other">
                <AccordionTrigger>Availability</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="in-stock" />
                      <Label htmlFor="in-stock" className="text-sm font-normal cursor-pointer">
                        In Stock Only
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="on-sale" />
                      <Label htmlFor="on-sale" className="text-sm font-normal cursor-pointer">
                        On Sale
                      </Label>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>

        {/* Products Grid */}
        <div className="flex-1">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">{category.name}</h2>
              <p className="text-muted-foreground">
                Showing {filteredProducts.length} of {products.length} products
              </p>
            </div>

            <div className="flex items-center gap-2">
              {/* Mobile Filter Button */}
              <Button
                variant="outline"
                size="sm"
                className="md:hidden flex items-center gap-1"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="h-4 w-4" />
                Filters
                {(selectedBrands.length > 0 ||
                  selectedColors.length > 0 ||
                  priceRange[0] > minPrice ||
                  priceRange[1] < maxPrice) && (
                  <Badge variant="secondary" className="ml-1 h-5 w-5 p-0 flex items-center justify-center">
                    {selectedBrands.length +
                      selectedColors.length +
                      (priceRange[0] > minPrice || priceRange[1] < maxPrice ? 1 : 0)}
                  </Badge>
                )}
              </Button>

              {/* Search */}
              <div className="relative flex-1 min-w-[150px]">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search products..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {/* Sort */}
              <Select value={sortOption} onValueChange={setSortOption}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="newest">Newest Arrivals</SelectItem>
                  <SelectItem value="best-selling">Best Selling</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Mobile Filters */}
          {showFilters && (
            <div className="md:hidden mb-6 p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Filters</h3>
                <Button variant="ghost" size="sm" onClick={resetFilters} className="h-8 text-xs">
                  Reset All
                </Button>
              </div>

              <Accordion type="multiple" defaultValue={["price"]}>
                {/* Price Range Filter */}
                <AccordionItem value="price">
                  <AccordionTrigger>Price Range</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4">
                      <Slider
                        min={minPrice}
                        max={maxPrice}
                        step={10}
                        value={priceRange}
                        onValueChange={(value) => setPriceRange(value as [number, number])}
                      />
                      <div className="flex items-center justify-between">
                        <div className="flex items-center border rounded-md">
                          <span className="pl-2 text-muted-foreground">$</span>
                          <Input
                            type="number"
                            min={minPrice}
                            max={priceRange[1]}
                            value={priceRange[0]}
                            onChange={(e) => {
                              const value = Number(e.target.value)
                              if (!isNaN(value)) {
                                setPriceRange([value, priceRange[1]])
                              }
                            }}
                            className="border-0 w-20"
                          />
                        </div>
                        <span className="text-muted-foreground">to</span>
                        <div className="flex items-center border rounded-md">
                          <span className="pl-2 text-muted-foreground">$</span>
                          <Input
                            type="number"
                            min={priceRange[0]}
                            max={maxPrice}
                            value={priceRange[1]}
                            onChange={(e) => {
                              const value = Number(e.target.value)
                              if (!isNaN(value)) {
                                setPriceRange([priceRange[0], value])
                              }
                            }}
                            className="border-0 w-20"
                          />
                        </div>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Brand Filter */}
                <AccordionItem value="brand">
                  <AccordionTrigger>Brand</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2 max-h-[200px] overflow-y-auto pr-2">
                      {allBrands.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No brands available</p>
                      ) : (
                        allBrands.map((brand) => (
                          <div key={brand} className="flex items-center space-x-2">
                            <Checkbox
                              id={`mobile-brand-${brand}`}
                              checked={selectedBrands.includes(brand)}
                              onCheckedChange={() => toggleBrand(brand)}
                            />
                            <Label htmlFor={`mobile-brand-${brand}`} className="text-sm font-normal cursor-pointer">
                              {brand}
                            </Label>
                          </div>
                        ))
                      )}
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Color Filter */}
                <AccordionItem value="color">
                  <AccordionTrigger>Color</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2 max-h-[200px] overflow-y-auto pr-2">
                      {allColors.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No colors available</p>
                      ) : (
                        allColors.map((color) => (
                          <div key={color} className="flex items-center space-x-2">
                            <Checkbox
                              id={`mobile-color-${color}`}
                              checked={selectedColors.includes(color)}
                              onCheckedChange={() => toggleColor(color)}
                            />
                            <div
                              className="w-4 h-4 rounded-full border"
                              style={{ backgroundColor: color.toLowerCase() }}
                            />
                            <Label htmlFor={`mobile-color-${color}`} className="text-sm font-normal cursor-pointer">
                              {color}
                            </Label>
                          </div>
                        ))
                      )}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>

              <Button className="w-full mt-4" onClick={() => setShowFilters(false)}>
                Apply Filters
              </Button>
            </div>
          )}

          {/* Products Grid */}
          {filteredProducts.length === 0 ? (
            <div className="text-center py-12 border rounded-lg">
              <h3 className="text-lg font-medium mb-2">No products found</h3>
              <p className="text-muted-foreground mb-4">Try adjusting your filters to find what you're looking for.</p>
              <Button onClick={resetFilters}>Clear All Filters</Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <Card key={product.id} className="overflow-hidden h-full transition-all hover:shadow-lg">
                  <Link href={`/products/${product.id}`}>
                    <div className="relative h-48 md:h-60">
                      <Image
                        src={getProductImage(product.category) || "/placeholder.svg"}
                        alt={product.name}
                        fill
                        className="object-cover"
                      />
                      {product.onSale && (
                        <Badge className="absolute top-2 right-2 bg-red-500 hover:bg-red-600">Sale</Badge>
                      )}
                    </div>
                  </Link>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-xs text-muted-foreground">{product.brand}</p>
                      <div className="flex items-center">
                        <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                        <span className="text-xs ml-1">{product.rating.toFixed(1)}</span>
                      </div>
                    </div>
                    <Link href={`/products/${product.id}`}>
                      <h3 className="font-medium text-sm line-clamp-1 hover:underline">{product.name}</h3>
                    </Link>
                    <div className="flex items-center gap-2 mt-1">
                      {product.onSale ? (
                        <>
                          <span className="font-medium text-sm">${product.salePrice.toFixed(2)}</span>
                          <span className="text-xs text-muted-foreground line-through">
                            ${product.price.toFixed(2)}
                          </span>
                        </>
                      ) : (
                        <span className="font-medium text-sm">${product.price.toFixed(2)}</span>
                      )}
                    </div>
                    <Button variant="outline" size="sm" className="w-full mt-3" onClick={() => addToCart(product)}>
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Add to Cart
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Pagination */}
          {filteredProducts.length > 0 && (
            <div className="flex justify-center mt-8">
              <Button variant="outline">Load More</Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

