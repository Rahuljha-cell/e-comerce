export default function PrivacyPolicyPage() {
  return (
    <div className="container px-4 py-8 md:px-6 md:py-12 max-w-4xl">
      <h1 className="text-3xl font-bold tracking-tight mb-6">Privacy Policy</h1>

      <div className="prose prose-sm sm:prose max-w-none">
        <p>Last Updated: March 27, 2023</p>

        <h2>1. Introduction</h2>
        <p>
          At ShopHub ("we," "our," or "us"), we respect your privacy and are committed to protecting your personal
          information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when
          you visit our website or use our services.
        </p>
        <p>
          Please read this Privacy Policy carefully. By accessing or using our services, you acknowledge that you have
          read, understood, and agree to be bound by this Privacy Policy.
        </p>

        <h2>2. Information We Collect</h2>
        <p>We may collect several types of information from and about users of our services, including:</p>
        <ul>
          <li>
            <strong>Personal Information:</strong> This includes information that can be used to identify you, such as
            your name, email address, postal address, phone number, and payment information.
          </li>
          <li>
            <strong>Non-Personal Information:</strong> This includes information that does not directly identify you,
            such as your browser type, IP address, device information, and usage data.
          </li>
          <li>
            <strong>Cookies and Similar Technologies:</strong> We use cookies and similar technologies to collect
            information about your browsing activities and preferences.
          </li>
        </ul>

        <h2>3. How We Collect Information</h2>
        <p>We collect information in several ways, including:</p>
        <ul>
          <li>
            <strong>Direct Collection:</strong> Information you provide to us when you register for an account, make a
            purchase, sign up for our newsletter, or contact our customer service.
          </li>
          <li>
            <strong>Automated Collection:</strong> Information collected automatically as you navigate through our
            website or use our services, such as usage details, IP addresses, and information collected through cookies.
          </li>
          <li>
            <strong>Third-Party Sources:</strong> Information we may receive from third-party sources, such as business
            partners, analytics providers, and social media platforms.
          </li>
        </ul>

        <h2>4. How We Use Your Information</h2>
        <p>We may use the information we collect for various purposes, including:</p>
        <ul>
          <li>To provide, maintain, and improve our services</li>
          <li>To process transactions and send related information</li>
          <li>To send administrative information, such as updates to our terms, conditions, and policies</li>
          <li>To personalize your experience and deliver content and product offerings relevant to your interests</li>
          <li>To respond to your inquiries and provide customer support</li>
          <li>To send promotional communications, such as special offers and information about new products</li>
          <li>To monitor and analyze usage patterns and trends</li>
          <li>To protect our services and users from fraudulent, unauthorized, or illegal activity</li>
        </ul>

        <h2>5. Disclosure of Your Information</h2>
        <p>We may disclose your information to third parties in the following circumstances:</p>
        <ul>
          <li>
            <strong>Service Providers:</strong> We may share your information with third-party service providers who
            perform services on our behalf, such as payment processing, data analysis, email delivery, and customer
            service.
          </li>
          <li>
            <strong>Business Transfers:</strong> If we are involved in a merger, acquisition, or sale of all or a
            portion of our assets, your information may be transferred as part of that transaction.
          </li>
          <li>
            <strong>Legal Requirements:</strong> We may disclose your information if required to do so by law or in
            response to valid requests by public authorities.
          </li>
          <li>
            <strong>Protection of Rights:</strong> We may disclose your information to protect our rights, property, or
            safety, or the rights, property, or safety of our users or others.
          </li>
        </ul>

        <h2>6. Your Choices</h2>
        <p>You have several choices regarding the information we collect and how it is used:</p>
        <ul>
          <li>
            <strong>Account Information:</strong> You can review and update your account information by logging into
            your account settings.
          </li>
          <li>
            <strong>Marketing Communications:</strong> You can opt out of receiving promotional emails by following the
            unsubscribe instructions in those emails.
          </li>
          <li>
            <strong>Cookies:</strong> You can set your browser to refuse all or some browser cookies or to alert you
            when cookies are being sent.
          </li>
          <li>
            <strong>Do Not Track:</strong> Some browsers have a "Do Not Track" feature that signals to websites that you
            do not want to have your online activities tracked. Our website does not currently respond to "Do Not Track"
            signals.
          </li>
        </ul>

        <h2>7. Data Security</h2>
        <p>
          We have implemented measures designed to secure your personal information from accidental loss and from
          unauthorized access, use, alteration, and disclosure. However, the transmission of information via the
          internet is not completely secure, and we cannot guarantee the security of your information.
        </p>

        <h2>8. Children's Privacy</h2>
        <p>
          Our services are not intended for children under the age of 13, and we do not knowingly collect personal
          information from children under 13. If we learn we have collected or received personal information from a
          child under 13, we will delete that information.
        </p>

        <h2>9. International Data Transfers</h2>
        <p>
          Your information may be transferred to, and maintained on, computers located outside of your state, province,
          country, or other governmental jurisdiction where the data protection laws may differ from those in your
          jurisdiction.
        </p>

        <h2>10. Changes to Our Privacy Policy</h2>
        <p>
          We may update our Privacy Policy from time to time. If we make material changes to how we treat our users'
          personal information, we will notify you through a notice on our website or by other means.
        </p>
        <p>
          The date the Privacy Policy was last revised is identified at the top of the page. You are responsible for
          periodically visiting our website and this Privacy Policy to check for any changes.
        </p>

        <h2>11. Contact Information</h2>
        <p>If you have any questions or concerns about this Privacy Policy, please contact us at:</p>
        <p>
          ShopHub
          <br />
          123 Commerce Street
          <br />
          New York, NY 10001
          <br />
          privacy@shophub.com
          <br />
          (555) 123-4567
        </p>
      </div>
    </div>
  )
}

