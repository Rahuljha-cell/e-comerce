import LoadingSpinner from "@/components/loading-spinner"

export default function Loading() {
  return (
    <div className="flex justify-center items-center min-h-[50vh]">
      <div className="text-center">
        <LoadingSpinner size="large" />
        <p className="mt-4 text-muted-foreground">Loading...</p>
      </div>
    </div>
  )
}

