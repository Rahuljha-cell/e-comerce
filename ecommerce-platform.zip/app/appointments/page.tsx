"use client"

import { Badge } from "@/components/ui/badge"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { AlertCircle } from "lucide-react"
import LoadingSpinner from "@/components/loading-spinner"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface UserInfo {
  firstName: string
  lastName: string
  email: string
  phone: string
}

interface Appointment {
  id: string
  date: Date
  timeSlot: string
  serviceType: string
  status: "confirmed" | "cancelled" | "completed"
  notes?: string
  userInfo: UserInfo
}

export default function AppointmentsPage() {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [timeSlot, setTimeSlot] = useState<string | undefined>()
  const [serviceType, setServiceType] = useState<string | undefined>()
  const [notes, setNotes] = useState("")
  const [userInfo, setUserInfo] = useState<UserInfo>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
  })
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [bookingStep, setBookingStep] = useState(1)
  const [cancelAppointmentId, setCancelAppointmentId] = useState<string | null>(null)
  const [rescheduleAppointment, setRescheduleAppointment] = useState<Appointment | null>(null)
  const [rescheduleDate, setRescheduleDate] = useState<Date | undefined>(new Date())
  const [rescheduleTimeSlot, setRescheduleTimeSlot] = useState<string | undefined>()
  const [isLoading, setIsLoading] = useState(true)

  // Mock available time slots
  const timeSlots = ["9:00 AM", "10:00 AM", "11:00 AM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM"]

  // Mock service types
  const serviceTypes = [
    { id: "consultation", name: "Consultation", duration: "30 min", price: "$50" },
    { id: "standard", name: "Standard Service", duration: "1 hour", price: "$100" },
    { id: "premium", name: "Premium Service", duration: "2 hours", price: "$200" },
  ]

  // Load mock appointments
  useEffect(() => {
    // Simulate API call to fetch appointments
    setTimeout(() => {
      const mockAppointments: Appointment[] = [
        {
          id: "apt-1",
          date: new Date(new Date().setDate(new Date().getDate() + 5)),
          timeSlot: "10:00 AM",
          serviceType: "consultation",
          status: "confirmed",
          notes: "First time consultation",
          userInfo: {
            firstName: "John",
            lastName: "Doe",
            email: "john.doe@example.com",
            phone: "(123) 456-7890",
          },
        },
        {
          id: "apt-2",
          date: new Date(new Date().setDate(new Date().getDate() + 14)),
          timeSlot: "2:00 PM",
          serviceType: "premium",
          status: "confirmed",
          userInfo: {
            firstName: "John",
            lastName: "Doe",
            email: "john.doe@example.com",
            phone: "(123) 456-7890",
          },
        },
        {
          id: "apt-3",
          date: new Date(new Date().setDate(new Date().getDate() - 10)),
          timeSlot: "11:00 AM",
          serviceType: "standard",
          status: "completed",
          userInfo: {
            firstName: "John",
            lastName: "Doe",
            email: "john.doe@example.com",
            phone: "(123) 456-7890",
          },
        },
      ]
      setAppointments(mockAppointments)
      setIsLoading(false)
    }, 1000)
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    if (name === "notes") {
      setNotes(value)
    } else {
      setUserInfo((prev) => ({ ...prev, [name]: value }))
    }
  }

  const validateUserInfo = () => {
    return userInfo.firstName && userInfo.lastName && userInfo.email && userInfo.phone
  }

  const validateAppointmentDetails = () => {
    return date && timeSlot && serviceType
  }

  const handleNextStep = () => {
    if (bookingStep === 1 && validateUserInfo()) {
      setBookingStep(2)
    } else if (bookingStep === 1 && !validateUserInfo()) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields to continue.",
        variant: "destructive",
      })
    }
  }

  const handlePrevStep = () => {
    setBookingStep(1)
  }

  const handleBookAppointment = async () => {
    if (!validateAppointmentDetails() || !validateUserInfo()) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields to book your appointment.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    // Simulate API call to book appointment
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const newAppointment: Appointment = {
      id: `apt-${Date.now()}`,
      date: date!,
      timeSlot: timeSlot!,
      serviceType: serviceType!,
      status: "confirmed",
      notes: notes,
      userInfo: userInfo,
    }

    setAppointments((prev) => [...prev, newAppointment])

    // Reset form
    setDate(new Date())
    setTimeSlot(undefined)
    setServiceType(undefined)
    setNotes("")
    setBookingStep(1)

    setIsSubmitting(false)

    toast({
      title: "Appointment Booked",
      description: `Your appointment has been successfully booked for ${date!.toLocaleDateString()} at ${timeSlot}.`,
    })
  }

  const handleCancelAppointment = async (id: string) => {
    setIsSubmitting(true)

    // Simulate API call to cancel appointment
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setAppointments((prev) => prev.map((apt) => (apt.id === id ? { ...apt, status: "cancelled" } : apt)))

    setCancelAppointmentId(null)
    setIsSubmitting(false)

    toast({
      title: "Appointment Cancelled",
      description: "Your appointment has been successfully cancelled.",
    })
  }

  const handleOpenReschedule = (appointment: Appointment) => {
    setRescheduleAppointment(appointment)
    setRescheduleDate(appointment.date)
    setRescheduleTimeSlot(appointment.timeSlot)
  }

  const handleRescheduleAppointment = async () => {
    if (!rescheduleAppointment || !rescheduleDate || !rescheduleTimeSlot) {
      toast({
        title: "Missing Information",
        description: "Please select a new date and time for your appointment.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    // Simulate API call to reschedule appointment
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setAppointments((prev) =>
      prev.map((apt) =>
        apt.id === rescheduleAppointment.id
          ? {
              ...apt,
              date: rescheduleDate,
              timeSlot: rescheduleTimeSlot,
            }
          : apt,
      ),
    )

    setRescheduleAppointment(null)
    setIsSubmitting(false)

    toast({
      title: "Appointment Rescheduled",
      description: `Your appointment has been successfully rescheduled to ${rescheduleDate.toLocaleDateString()} at ${rescheduleTimeSlot}.`,
    })
  }

  const getServiceNameById = (id: string) => {
    const service = serviceTypes.find((s) => s.id === id)
    return service ? service.name : id
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Toaster />

      <div className="flex flex-col items-center text-center space-y-2 mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Book an Appointment</h1>
        <p className="text-muted-foreground max-w-[700px]">
          Schedule a time with our experts for personalized service and support.
        </p>
      </div>

      <Tabs defaultValue="new" className="max-w-4xl mx-auto">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="new">New Appointment</TabsTrigger>
          <TabsTrigger value="manage">Manage Appointments</TabsTrigger>
        </TabsList>

        <TabsContent value="new" className="space-y-6 mt-6">
          {bookingStep === 1 ? (
            <Card>
              <CardHeader>
                <CardTitle>Your Information</CardTitle>
                <CardDescription>Please provide your contact details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">
                      First Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      placeholder="John"
                      value={userInfo.firstName}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">
                      Last Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      placeholder="Doe"
                      value={userInfo.lastName}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">
                    Email <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="john.doe@example.com"
                    value={userInfo.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">
                    Phone <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="phone"
                    name="phone"
                    placeholder="(123) 456-7890"
                    value={userInfo.phone}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleNextStep} className="w-full">
                  Continue
                </Button>
              </CardFooter>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Select Date & Time</CardTitle>
                  <CardDescription>Choose your preferred appointment date and time</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    className="rounded-md border mx-auto"
                    disabled={(date) => {
                      // Disable weekends and past dates
                      const day = date.getDay()
                      return date < new Date(new Date().setHours(0, 0, 0, 0)) || day === 0 || day === 6
                    }}
                  />
                  <div className="space-y-2">
                    <Label>Available Time Slots</Label>
                    <RadioGroup value={timeSlot} onValueChange={setTimeSlot} className="grid grid-cols-3 gap-2">
                      {timeSlots.map((slot) => (
                        <div key={slot}>
                          <RadioGroupItem value={slot} id={`time-${slot}`} className="peer sr-only" />
                          <Label
                            htmlFor={`time-${slot}`}
                            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-2 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                          >
                            {slot}
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Select Service</CardTitle>
                  <CardDescription>Choose the type of service you need</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Service Type</Label>
                    <RadioGroup value={serviceType} onValueChange={setServiceType} className="space-y-2">
                      {serviceTypes.map((service) => (
                        <div key={service.id} className="flex items-center space-x-2">
                          <RadioGroupItem value={service.id} id={`service-${service.id}`} />
                          <Label
                            htmlFor={`service-${service.id}`}
                            className="flex flex-1 justify-between cursor-pointer"
                          >
                            <div>
                              <span className="font-medium">{service.name}</span>
                              <p className="text-sm text-muted-foreground">Duration: {service.duration}</p>
                            </div>
                            <span className="font-medium">{service.price}</span>
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                  <Separator />
                  <div className="space-y-2">
                    <Label htmlFor="notes">Special Requests or Notes</Label>
                    <Input
                      id="notes"
                      name="notes"
                      value={notes}
                      onChange={handleInputChange}
                      placeholder="Any special requirements or information we should know"
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col space-y-2">
                  <Button
                    className="w-full"
                    disabled={!date || !timeSlot || !serviceType || isSubmitting}
                    onClick={handleBookAppointment}
                  >
                    {isSubmitting ? (
                      <>
                        <LoadingSpinner size="small" />
                        <span className="ml-2">Booking...</span>
                      </>
                    ) : (
                      "Book Appointment"
                    )}
                  </Button>
                  <Button variant="outline" className="w-full" onClick={handlePrevStep} disabled={isSubmitting}>
                    Back
                  </Button>
                </CardFooter>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="manage" className="space-y-6 mt-6">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <LoadingSpinner size="large" />
            </div>
          ) : appointments.filter((apt) => apt.status === "confirmed").length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No Upcoming Appointments</h3>
                <p className="text-muted-foreground text-center max-w-md mb-6">
                  You don't have any upcoming appointments scheduled. Book a new appointment to get started.
                </p>
                <Button asChild>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault()
                      document
                        .querySelector('[data-value="new"]')
                        ?.dispatchEvent(new MouseEvent("click", { bubbles: true }))
                    }}
                  >
                    Book an Appointment
                  </a>
                </Button>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Your Upcoming Appointments</CardTitle>
                <CardDescription>View and manage your scheduled appointments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {appointments
                    .filter((apt) => apt.status === "confirmed")
                    .map((appointment) => (
                      <div key={appointment.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-semibold">{getServiceNameById(appointment.serviceType)}</h3>
                            <p className="text-sm text-muted-foreground">
                              {appointment.date.toLocaleDateString("en-US", {
                                weekday: "long",
                                month: "long",
                                day: "numeric",
                                year: "numeric",
                              })}{" "}
                              at {appointment.timeSlot}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Duration: {serviceTypes.find((s) => s.id === appointment.serviceType)?.duration}
                            </p>
                            {appointment.notes && (
                              <p className="text-sm text-muted-foreground mt-2">
                                <span className="font-medium">Notes:</span> {appointment.notes}
                              </p>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" onClick={() => handleOpenReschedule(appointment)}>
                              Reschedule
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => setCancelAppointmentId(appointment.id)}
                            >
                              Cancel
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          )}

          {appointments.filter((apt) => apt.status === "cancelled").length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Cancelled Appointments</CardTitle>
                <CardDescription>View your cancelled appointments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {appointments
                    .filter((apt) => apt.status === "cancelled")
                    .map((appointment) => (
                      <div key={appointment.id} className="border rounded-lg p-4 bg-muted/50">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center">
                              <h3 className="font-semibold">{getServiceNameById(appointment.serviceType)}</h3>
                              <Badge variant="outline" className="ml-2 bg-red-100 text-red-800 hover:bg-red-100">
                                Cancelled
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {appointment.date.toLocaleDateString("en-US", {
                                weekday: "long",
                                month: "long",
                                day: "numeric",
                                year: "numeric",
                              })}{" "}
                              at {appointment.timeSlot}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Duration: {serviceTypes.find((s) => s.id === appointment.serviceType)?.duration}
                            </p>
                          </div>
                          <Button variant="outline" size="sm" asChild>
                            <a
                              href="#"
                              onClick={(e) => {
                                e.preventDefault()
                                document
                                  .querySelector('[data-value="new"]')
                                  ?.dispatchEvent(new MouseEvent("click", { bubbles: true }))
                              }}
                            >
                              Book Again
                            </a>
                          </Button>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Past Appointments</CardTitle>
              <CardDescription>View your appointment history</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {appointments
                  .filter((apt) => apt.status === "completed")
                  .map((appointment) => (
                    <div key={appointment.id} className="border rounded-lg p-4 bg-muted/50">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center">
                            <h3 className="font-semibold">{getServiceNameById(appointment.serviceType)}</h3>
                            <Badge variant="outline" className="ml-2 bg-green-100 text-green-800 hover:bg-green-100">
                              Completed
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {appointment.date.toLocaleDateString("en-US", {
                              weekday: "long",
                              month: "long",
                              day: "numeric",
                              year: "numeric",
                            })}{" "}
                            at {appointment.timeSlot}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Duration: {serviceTypes.find((s) => s.id === appointment.serviceType)?.duration}
                          </p>
                        </div>
                        <Button variant="outline" size="sm">
                          Book Again
                        </Button>
                      </div>
                    </div>
                  ))}
                {appointments.filter((apt) => apt.status === "completed").length === 0 && (
                  <p className="text-center text-muted-foreground py-4">You don't have any past appointments.</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Cancel Appointment Confirmation Dialog */}
      <Dialog open={!!cancelAppointmentId} onOpenChange={() => setCancelAppointmentId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cancel Appointment</DialogTitle>
            <DialogDescription>
              Are you sure you want to cancel this appointment? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCancelAppointmentId(null)} disabled={isSubmitting}>
              Keep Appointment
            </Button>
            <Button
              variant="destructive"
              onClick={() => cancelAppointmentId && handleCancelAppointment(cancelAppointmentId)}
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <LoadingSpinner size="small" />
                  <span className="ml-2">Cancelling...</span>
                </>
              ) : (
                "Cancel Appointment"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reschedule Appointment Dialog */}
      <Dialog open={!!rescheduleAppointment} onOpenChange={() => setRescheduleAppointment(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Reschedule Appointment</DialogTitle>
            <DialogDescription>Select a new date and time for your appointment.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>New Date</Label>
              <Calendar
                mode="single"
                selected={rescheduleDate}
                onSelect={setRescheduleDate}
                className="rounded-md border mx-auto"
                disabled={(date) => {
                  // Disable weekends and past dates
                  const day = date.getDay()
                  return date < new Date(new Date().setHours(0, 0, 0, 0)) || day === 0 || day === 6
                }}
              />
            </div>
            <div className="space-y-2">
              <Label>New Time</Label>
              <Select value={rescheduleTimeSlot} onValueChange={setRescheduleTimeSlot}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a time slot" />
                </SelectTrigger>
                <SelectContent>
                  {timeSlots.map((slot) => (
                    <SelectItem key={slot} value={slot}>
                      {slot}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRescheduleAppointment(null)} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              onClick={handleRescheduleAppointment}
              disabled={isSubmitting || !rescheduleDate || !rescheduleTimeSlot}
            >
              {isSubmitting ? (
                <>
                  <LoadingSpinner size="small" />
                  <span className="ml-2">Rescheduling...</span>
                </>
              ) : (
                "Confirm Reschedule"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

