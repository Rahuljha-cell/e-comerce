export default function TermsPage() {
  return (
    <div className="container px-4 py-8 md:px-6 md:py-12 max-w-4xl">
      <h1 className="text-3xl font-bold tracking-tight mb-6">Terms of Service</h1>

      <div className="prose prose-sm sm:prose max-w-none">
        <p>Last Updated: March 27, 2023</p>

        <h2>1. Introduction</h2>
        <p>
          Welcome to ShopHub ("we," "our," or "us"). These Terms of Service ("Terms") govern your access to and use of
          the ShopHub website, mobile application, and services (collectively, the "Services").
        </p>
        <p>
          By accessing or using our Services, you agree to be bound by these Terms. If you do not agree to these Terms,
          you may not access or use the Services.
        </p>

        <h2>2. Account Registration</h2>
        <p>
          To access certain features of the Services, you may be required to register for an account. You agree to
          provide accurate, current, and complete information during the registration process and to update such
          information to keep it accurate, current, and complete.
        </p>
        <p>
          You are responsible for safeguarding your account credentials and for all activities that occur under your
          account. You agree to notify us immediately of any unauthorized use of your account.
        </p>

        <h2>3. User Conduct</h2>
        <p>You agree not to:</p>
        <ul>
          <li>Use the Services in any way that violates any applicable law or regulation</li>
          <li>Use the Services for the purpose of exploiting, harming, or attempting to exploit or harm minors</li>
          <li>Attempt to gain unauthorized access to any portion of the Services</li>
          <li>Interfere with or disrupt the Services or servers or networks connected to the Services</li>
          <li>Use any robot, spider, or other automatic device to access the Services</li>
          <li>
            Introduce any viruses, trojan horses, worms, or other material that is malicious or technologically harmful
          </li>
        </ul>

        <h2>4. Products and Purchases</h2>
        <p>
          All products offered through our Services are described with reasonable accuracy, including their prices,
          features, and availability. However, we do not guarantee that product descriptions or other content on the
          Services are accurate, complete, reliable, current, or error-free.
        </p>
        <p>
          Prices for products are subject to change without notice. We reserve the right to modify or discontinue any
          product without notice at any time.
        </p>
        <p>
          When you place an order through the Services, you are making an offer to purchase the products at the listed
          price. We reserve the right to accept or decline your order for any reason.
        </p>

        <h2>5. Payment and Billing</h2>
        <p>
          By providing a credit card or other payment method accepted by us, you represent and warrant that you are
          authorized to use the designated payment method and authorize us to charge your payment method for the total
          amount of your order (including any applicable taxes and shipping charges).
        </p>
        <p>
          If the payment method you provide cannot be verified, is invalid, or is otherwise not acceptable, your order
          may be suspended or canceled. You must resolve any payment method problems to proceed with your order.
        </p>

        <h2>6. Shipping and Delivery</h2>
        <p>
          We will make reasonable efforts to ship products within the estimated delivery timeframes provided at
          checkout. However, we do not guarantee delivery times, and delays may occur due to various factors beyond our
          control.
        </p>
        <p>
          Risk of loss and title for items purchased from our Services pass to you upon delivery of the items to the
          carrier.
        </p>

        <h2>7. Returns and Refunds</h2>
        <p>
          Our return and refund policy is described separately and is incorporated into these Terms by reference. Please
          review our Return Policy for more information.
        </p>

        <h2>8. Intellectual Property</h2>
        <p>
          The Services and their entire contents, features, and functionality (including but not limited to all
          information, software, text, displays, images, video, and audio, and the design, selection, and arrangement
          thereof) are owned by us, our licensors, or other providers of such material and are protected by copyright,
          trademark, patent, trade secret, and other intellectual property or proprietary rights laws.
        </p>
        <p>
          These Terms permit you to use the Services for your personal, non-commercial use only. You must not reproduce,
          distribute, modify, create derivative works of, publicly display, publicly perform, republish, download,
          store, or transmit any of the material on our Services.
        </p>

        <h2>9. Disclaimer of Warranties</h2>
        <p>
          THE SERVICES AND ALL CONTENT, PRODUCTS, AND SERVICES INCLUDED ON OR OTHERWISE MADE AVAILABLE TO YOU THROUGH
          THE SERVICES ARE PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS, WITHOUT ANY WARRANTIES OF ANY KIND, EITHER
          EXPRESS OR IMPLIED.
        </p>
        <p>
          WE DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF
          MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
        </p>

        <h2>10. Limitation of Liability</h2>
        <p>
          IN NO EVENT WILL WE, OUR AFFILIATES, OR THEIR LICENSORS, SERVICE PROVIDERS, EMPLOYEES, AGENTS, OFFICERS, OR
          DIRECTORS BE LIABLE FOR DAMAGES OF ANY KIND, UNDER ANY LEGAL THEORY, ARISING OUT OF OR IN CONNECTION WITH YOUR
          USE, OR INABILITY TO USE, THE SERVICES, ANY WEBSITES LINKED TO THEM, ANY CONTENT ON THE SERVICES OR SUCH OTHER
          WEBSITES, INCLUDING ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES.
        </p>

        <h2>11. Indemnification</h2>
        <p>
          You agree to defend, indemnify, and hold harmless us, our affiliates, licensors, and service providers, and
          our and their respective officers, directors, employees, contractors, agents, licensors, suppliers,
          successors, and assigns from and against any claims, liabilities, damages, judgments, awards, losses, costs,
          expenses, or fees (including reasonable attorneys' fees) arising out of or relating to your violation of these
          Terms or your use of the Services.
        </p>

        <h2>12. Changes to Terms</h2>
        <p>
          We may revise and update these Terms from time to time in our sole discretion. All changes are effective
          immediately when we post them.
        </p>
        <p>
          Your continued use of the Services following the posting of revised Terms means that you accept and agree to
          the changes.
        </p>

        <h2>13. Governing Law and Jurisdiction</h2>
        <p>
          These Terms and any dispute or claim arising out of or related to them, their subject matter, or their
          formation shall be governed by and construed in accordance with the laws of the state of our principal place
          of business, without giving effect to any choice or conflict of law provision or rule.
        </p>
        <p>
          Any legal suit, action, or proceeding arising out of, or related to, these Terms or the Services shall be
          instituted exclusively in the federal courts or the courts of the state of our principal place of business.
        </p>

        <h2>14. Contact Information</h2>
        <p>If you have any questions about these Terms, please contact us at:</p>
        <p>
          ShopHub
          <br />
          123 Commerce Street
          <br />
          New York, NY 10001
          <br />
          support@shophub.com
          <br />
          (555) 123-4567
        </p>
      </div>
    </div>
  )
}

