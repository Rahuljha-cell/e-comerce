"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Trash, Star, Heart } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import LoadingSpinner from "@/components/loading-spinner"
import { mockProducts } from "@/lib/mock-data"

// Define product categories
const categories = [
  { id: "electronics", name: "Electronics", icon: "💻" },
  { id: "mens-clothing", name: "Men's Clothing", icon: "👔" },
  { id: "womens-clothing", name: "Women's Clothing", icon: "👗" },
  { id: "jewelry", name: "Jewelry & Watches", icon: "💍" },
  { id: "home", name: "Home & Kitchen", icon: "🏠" },
  { id: "beauty", name: "Beauty & Personal Care", icon: "💄" },
  { id: "sports", name: "Sports & Outdoors", icon: "🏀" },
  { id: "toys", name: "Toys & Games", icon: "🎮" },
]

// Define product images for different categories
const productImages = {
  electronics: ["/placeholder.svg?height=300&width=300&text=Electronics"],
  "mens-clothing": ["/placeholder.svg?height=300&width=300&text=Mens+Clothing"],
  "womens-clothing": ["/placeholder.svg?height=300&width=300&text=Womens+Clothing"],
  jewelry: ["/placeholder.svg?height=300&width=300&text=Jewelry"],
  home: ["/placeholder.svg?height=300&width=300&text=Home"],
  beauty: ["/placeholder.svg?height=300&width=300&text=Beauty"],
  sports: ["/placeholder.svg?height=300&width=300&text=Sports"],
  toys: ["/placeholder.svg?height=300&width=300&text=Toys"],
}

// Extend mock products with categories
const categorizedProducts = mockProducts.map((product) => {
  let category = "electronics"

  if (product.id % 8 === 0) category = "mens-clothing"
  else if (product.id % 7 === 0) category = "womens-clothing"
  else if (product.id % 6 === 0) category = "jewelry"
  else if (product.id % 5 === 0) category = "home"
  else if (product.id % 4 === 0) category = "beauty"
  else if (product.id % 3 === 0) category = "sports"
  else if (product.id % 2 === 0) category = "toys"

  return {
    ...product,
    category,
  }
})

// Get a product image based on category
const getProductImage = (category: string) => {
  return productImages[category as keyof typeof productImages]?.[0] || productImages.electronics[0]
}

export default function WishlistPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [wishlistItems, setWishlistItems] = useState<any[]>([])
  const [isRemoving, setIsRemoving] = useState<number | null>(null)
  const [isAddingToCart, setIsAddingToCart] = useState<number | null>(null)

  // Load wishlist items
  useEffect(() => {
    // Simulate API call to fetch wishlist items
    setTimeout(() => {
      // Select 5 random products for the wishlist
      const randomProducts = [...categorizedProducts].sort(() => 0.5 - Math.random()).slice(0, 5)

      setWishlistItems(randomProducts)
      setIsLoading(false)
    }, 1000)
  }, [])

  const removeFromWishlist = async (id: number) => {
    setIsRemoving(id)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 800))

    setWishlistItems(wishlistItems.filter((item) => item.id !== id))
    setIsRemoving(null)

    toast({
      title: "Removed from Wishlist",
      description: "The item has been removed from your wishlist.",
    })
  }

  const addToCart = async (product: any) => {
    setIsAddingToCart(product.id)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 800))

    setIsAddingToCart(null)

    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart.`,
      action: (
        <Link href="/cart">
          <Button variant="outline" size="sm">
            View Cart
          </Button>
        </Link>
      ),
    })
  }

  return (
    <div className="container px-4 py-8 md:px-6 md:py-12">
      <Toaster />

      <div className="flex items-center gap-2 mb-6">
        <Heart className="h-5 w-5 text-red-500 fill-red-500" />
        <h1 className="text-2xl font-bold tracking-tight">My Wishlist</h1>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array(4)
            .fill(0)
            .map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <div className="relative h-48 md:h-60">
                  <Skeleton className="h-full w-full" />
                </div>
                <CardContent className="p-4">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2 mb-4" />
                  <Skeleton className="h-4 w-1/4" />
                  <div className="flex gap-2 mt-4">
                    <Skeleton className="h-9 w-full" />
                    <Skeleton className="h-9 w-10" />
                  </div>
                </CardContent>
              </Card>
            ))}
        </div>
      ) : wishlistItems.length === 0 ? (
        <div className="text-center py-12 border rounded-lg">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
            <Heart className="h-8 w-8 text-muted-foreground" />
          </div>
          <h2 className="text-xl font-semibold mb-2">Your wishlist is empty</h2>
          <p className="text-muted-foreground mb-6">Items added to your wishlist will be saved here for easy access.</p>
          <Button asChild>
            <Link href="/products">Browse Products</Link>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {wishlistItems.map((product) => (
            <Card key={product.id} className="overflow-hidden h-full transition-all hover:shadow-lg">
              <Link href={`/products/${product.id}`}>
                <div className="relative h-48 md:h-60">
                  <Image
                    src={getProductImage(product.category) || "/placeholder.svg"}
                    alt={product.name}
                    fill
                    className="object-cover"
                  />
                  {product.onSale && <Badge className="absolute top-2 right-2 bg-red-500 hover:bg-red-600">Sale</Badge>}
                </div>
              </Link>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-xs text-muted-foreground">{product.brand}</p>
                  <div className="flex items-center">
                    <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                    <span className="text-xs ml-1">{product.rating.toFixed(1)}</span>
                  </div>
                </div>
                <Link href={`/products/${product.id}`}>
                  <h3 className="font-medium text-sm line-clamp-1 hover:underline">{product.name}</h3>
                </Link>
                <div className="flex items-center gap-2 mt-1">
                  {product.onSale ? (
                    <>
                      <span className="font-medium text-sm">${product.salePrice.toFixed(2)}</span>
                      <span className="text-xs text-muted-foreground line-through">${product.price.toFixed(2)}</span>
                    </>
                  ) : (
                    <span className="font-medium text-sm">${product.price.toFixed(2)}</span>
                  )}
                </div>
                <div className="flex gap-2 mt-3">
                  <Button
                    variant="default"
                    size="sm"
                    className="flex-1"
                    onClick={() => addToCart(product)}
                    disabled={isAddingToCart === product.id}
                  >
                    {isAddingToCart === product.id ? (
                      <>
                        <LoadingSpinner size="small" />
                        <span className="ml-2">Adding...</span>
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Add to Cart
                      </>
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="px-2"
                    onClick={() => removeFromWishlist(product.id)}
                    disabled={isRemoving === product.id}
                  >
                    {isRemoving === product.id ? <LoadingSpinner size="small" /> : <Trash className="h-4 w-4" />}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

