"use client"

import { useState } from "react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, X } from "lucide-react"

interface ProductFiltersProps {
  filters: {
    categories: string[]
    brands: string[]
    priceRange: [number, number]
    colors: string[]
    ratings: number[]
    onSale: boolean
    inStock: boolean
  }
  allCategories: string[]
  allBrands: string[]
  allColors: string[]
  minPrice: number
  maxPrice: number
  onFilterChange: (filterType: string, value: any) => void
  toggleArrayFilter: (filterType: "categories" | "brands" | "colors" | "ratings", value: string | number) => void
  toggleBooleanFilter: (filterType: "onSale" | "inStock") => void
  clearAllFilters: () => void
  onClose?: () => void
}

export default function ProductFilters({
  filters,
  allCategories,
  allBrands,
  allColors,
  minPrice,
  maxPrice,
  onFilterChange,
  toggleArrayFilter,
  toggleBooleanFilter,
  clearAllFilters,
  onClose,
}: ProductFiltersProps) {
  const [categorySearch, setCategorySearch] = useState("")
  const [brandSearch, setBrandSearch] = useState("")
  const [colorSearch, setColorSearch] = useState("")

  // Filter categories based on search
  const filteredCategories = allCategories.filter((category) =>
    category.toLowerCase().includes(categorySearch.toLowerCase()),
  )

  // Filter brands based on search
  const filteredBrands = allBrands.filter((brand) => brand.toLowerCase().includes(brandSearch.toLowerCase()))

  // Filter colors based on search
  const filteredColors = allColors.filter((color) => color.toLowerCase().includes(colorSearch.toLowerCase()))

  // Format price for display
  const formatPrice = (value: number) => {
    return `$${value.toFixed(2)}`
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Filters</h3>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={clearAllFilters} className="h-8 text-xs">
            Clear All
          </Button>
          {onClose && (
            <Button variant="ghost" size="icon" onClick={onClose} className="md:hidden">
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>

      <Accordion type="multiple" defaultValue={["category", "price", "brand", "color", "other"]}>
        {/* Category Filter */}
        <AccordionItem value="category">
          <AccordionTrigger>Categories</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search categories"
                  className="pl-8"
                  value={categorySearch}
                  onChange={(e) => setCategorySearch(e.target.value)}
                />
              </div>

              <div className="max-h-[200px] overflow-y-auto space-y-2 pr-2">
                {filteredCategories.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No categories found</p>
                ) : (
                  filteredCategories.map((category) => (
                    <div key={category} className="flex items-center space-x-2">
                      <Checkbox
                        id={`category-${category}`}
                        checked={filters.categories.includes(category)}
                        onCheckedChange={() => toggleArrayFilter("categories", category)}
                      />
                      <Label htmlFor={`category-${category}`} className="text-sm font-normal cursor-pointer flex-1">
                        {category}
                      </Label>
                    </div>
                  ))
                )}
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Price Range Filter */}
        <AccordionItem value="price">
          <AccordionTrigger>Price Range</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <Slider
                min={minPrice}
                max={maxPrice}
                step={1}
                value={filters.priceRange}
                onValueChange={(value) => onFilterChange("priceRange", value)}
              />
              <div className="flex items-center justify-between">
                <div className="flex items-center border rounded-md">
                  <span className="pl-2 text-muted-foreground">$</span>
                  <Input
                    type="number"
                    min={minPrice}
                    max={filters.priceRange[1]}
                    value={filters.priceRange[0]}
                    onChange={(e) => {
                      const value = Number(e.target.value)
                      if (!isNaN(value)) {
                        onFilterChange("priceRange", [value, filters.priceRange[1]])
                      }
                    }}
                    className="border-0 w-20"
                  />
                </div>
                <span className="text-muted-foreground">to</span>
                <div className="flex items-center border rounded-md">
                  <span className="pl-2 text-muted-foreground">$</span>
                  <Input
                    type="number"
                    min={filters.priceRange[0]}
                    max={maxPrice}
                    value={filters.priceRange[1]}
                    onChange={(e) => {
                      const value = Number(e.target.value)
                      if (!isNaN(value)) {
                        onFilterChange("priceRange", [filters.priceRange[0], value])
                      }
                    }}
                    className="border-0 w-20"
                  />
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Brand Filter */}
        <AccordionItem value="brand">
          <AccordionTrigger>Brand</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search brands"
                  className="pl-8"
                  value={brandSearch}
                  onChange={(e) => setBrandSearch(e.target.value)}
                />
              </div>

              <div className="max-h-[200px] overflow-y-auto space-y-2 pr-2">
                {filteredBrands.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No brands found</p>
                ) : (
                  filteredBrands.map((brand) => (
                    <div key={brand} className="flex items-center space-x-2">
                      <Checkbox
                        id={`brand-${brand}`}
                        checked={filters.brands.includes(brand)}
                        onCheckedChange={() => toggleArrayFilter("brands", brand)}
                      />
                      <Label htmlFor={`brand-${brand}`} className="text-sm font-normal cursor-pointer flex-1">
                        {brand}
                      </Label>
                    </div>
                  ))
                )}
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Color Filter */}
        <AccordionItem value="color">
          <AccordionTrigger>Color</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search colors"
                  className="pl-8"
                  value={colorSearch}
                  onChange={(e) => setColorSearch(e.target.value)}
                />
              </div>

              <div className="max-h-[200px] overflow-y-auto space-y-2 pr-2">
                {filteredColors.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No colors found</p>
                ) : (
                  filteredColors.map((color) => (
                    <div key={color} className="flex items-center space-x-2">
                      <Checkbox
                        id={`color-${color}`}
                        checked={filters.colors.includes(color)}
                        onCheckedChange={() => toggleArrayFilter("colors", color)}
                      />
                      <div
                        className="w-4 h-4 rounded-full border"
                        style={{
                          backgroundColor: color.toLowerCase(),
                        }}
                      />
                      <Label htmlFor={`color-${color}`} className="text-sm font-normal cursor-pointer flex-1">
                        {color}
                      </Label>
                    </div>
                  ))
                )}
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Rating Filter */}
        <AccordionItem value="rating">
          <AccordionTrigger>Rating</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {[5, 4, 3, 2, 1].map((rating) => (
                <div key={rating} className="flex items-center space-x-2">
                  <Checkbox
                    id={`rating-${rating}`}
                    checked={filters.ratings.includes(rating)}
                    onCheckedChange={() => toggleArrayFilter("ratings", rating)}
                  />
                  <Label htmlFor={`rating-${rating}`} className="text-sm font-normal cursor-pointer flex items-center">
                    <div className="flex">
                      {Array(5)
                        .fill(0)
                        .map((_, i) => (
                          <svg
                            key={i}
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill={i < rating ? "currentColor" : "none"}
                            stroke="currentColor"
                            className={`w-4 h-4 ${i < rating ? "text-yellow-500" : "text-gray-300"}`}
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth="2"
                              d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
                            />
                          </svg>
                        ))}
                    </div>
                    <span className="ml-2">{rating} & Up</span>
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Other Filters */}
        <AccordionItem value="other">
          <AccordionTrigger>Other Filters</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox id="on-sale" checked={filters.onSale} onCheckedChange={() => toggleBooleanFilter("onSale")} />
                <Label htmlFor="on-sale" className="text-sm font-normal cursor-pointer">
                  On Sale
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="in-stock"
                  checked={filters.inStock}
                  onCheckedChange={() => toggleBooleanFilter("inStock")}
                />
                <Label htmlFor="in-stock" className="text-sm font-normal cursor-pointer">
                  In Stock
                </Label>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  )
}

