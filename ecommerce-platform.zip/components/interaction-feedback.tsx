"use client"

import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"

type FeedbackType = "click" | "hover" | "loading" | "success" | "error"

interface FeedbackProps {
  type: FeedbackType
  x: number
  y: number
  message?: string
}

export default function InteractionFeedback() {
  const [feedbacks, setFeedbacks] = useState<FeedbackProps[]>([])

  useEffect(() => {
    // Click feedback
    const handleClick = (e: MouseEvent) => {
      // Don't show feedback for clicks on buttons, links, etc.
      if (
        e.target instanceof HTMLButtonElement ||
        e.target instanceof HTMLAnchorElement ||
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLSelectElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        return
      }

      const feedback: FeedbackProps = {
        type: "click",
        x: e.clientX,
        y: e.clientY,
      }

      setFeedbacks((prev) => [...prev, feedback])

      // Remove feedback after animation
      setTimeout(() => {
        setFeedbacks((prev) => prev.filter((f) => f !== feedback))
      }, 1000)
    }

    document.addEventListener("click", handleClick)

    return () => {
      document.removeEventListener("click", handleClick)
    }
  }, [])

  return (
    <>
      {feedbacks.map((feedback, index) => (
        <FeedbackElement key={index} {...feedback} />
      ))}
    </>
  )
}

function FeedbackElement({ type, x, y, message }: FeedbackProps) {
  return (
    <div
      className={cn("fixed pointer-events-none z-50", type === "click" && "animate-ripple")}
      style={{
        left: x,
        top: y,
        transform: "translate(-50%, -50%)",
      }}
    >
      {type === "click" && <div className="w-12 h-12 rounded-full bg-primary/20 animate-ping" />}

      {message && (
        <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 px-2 py-1 bg-background border rounded text-xs shadow-lg animate-fade-in">
          {message}
        </div>
      )}
    </div>
  )
}

