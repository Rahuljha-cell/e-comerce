"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ShoppingCart, Heart, Package, Bell, Settings, Search, Tag } from "lucide-react"
import Confetti from "react-confetti"
import { useWindowSize } from "@/hooks/use-window-size"

export default function WelcomeModal() {
  const [isOpen, setIsOpen] = useState(false)
  const [showConfetti, setShowConfetti] = useState(false)
  const [activeTab, setActiveTab] = useState("welcome")
  const { width, height } = useWindowSize()

  // Show welcome modal on first visit
  useEffect(() => {
    const hasSeenWelcome = localStorage.getItem("hasSeenWelcome")

    if (!hasSeenWelcome) {
      // Small delay to ensure the modal appears after page load
      const timer = setTimeout(() => {
        setIsOpen(true)
        setShowConfetti(true)

        // Hide confetti after 5 seconds
        setTimeout(() => {
          setShowConfetti(false)
        }, 5000)
      }, 1000)

      return () => clearTimeout(timer)
    }
  }, [])

  // Handle close
  const handleClose = () => {
    setIsOpen(false)
    localStorage.setItem("hasSeenWelcome", "true")
  }

  // Handle tab change
  const handleTabChange = (value: string) => {
    setActiveTab(value)
  }

  return (
    <>
      {showConfetti && <Confetti width={width} height={height} recycle={false} numberOfPieces={200} />}

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="text-2xl text-center">Welcome to ShopHub!</DialogTitle>
            <DialogDescription className="text-center">
              Your one-stop destination for all your shopping needs
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="welcome" value={activeTab} onValueChange={handleTabChange}>
            <TabsList className="grid grid-cols-5 mb-4">
              <TabsTrigger value="welcome">Welcome</TabsTrigger>
              <TabsTrigger value="shop">Shop</TabsTrigger>
              <TabsTrigger value="account">Account</TabsTrigger>
              <TabsTrigger value="orders">Orders</TabsTrigger>
              <TabsTrigger value="deals">Deals</TabsTrigger>
            </TabsList>

            <TabsContent value="welcome" className="space-y-4">
              <div className="text-center py-4">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <ShoppingCart className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-medium mb-2">Discover ShopHub</h3>
                <p className="text-muted-foreground mb-4">
                  We're excited to have you here! ShopHub offers millions of products, personalized recommendations, and
                  lightning-fast delivery.
                </p>
                <div className="grid grid-cols-3 gap-4 mt-6">
                  <div className="text-center">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                      <Tag className="h-5 w-5 text-primary" />
                    </div>
                    <p className="text-sm font-medium">Great Deals</p>
                  </div>
                  <div className="text-center">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                      <Package className="h-5 w-5 text-primary" />
                    </div>
                    <p className="text-sm font-medium">Fast Delivery</p>
                  </div>
                  <div className="text-center">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                      <Heart className="h-5 w-5 text-primary" />
                    </div>
                    <p className="text-sm font-medium">Save Favorites</p>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="shop" className="space-y-4">
              <div className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Search className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Search & Browse</h3>
                  <p className="text-sm text-muted-foreground">
                    Find exactly what you're looking for with our powerful search and filtering options.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Heart className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Wishlist</h3>
                  <p className="text-sm text-muted-foreground">
                    Save items to your wishlist for later and get notified when they go on sale.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <ShoppingCart className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Easy Checkout</h3>
                  <p className="text-sm text-muted-foreground">
                    Our streamlined checkout process makes shopping quick and hassle-free.
                  </p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="account" className="space-y-4">
              <div className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Settings className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Account Settings</h3>
                  <p className="text-sm text-muted-foreground">
                    Customize your profile, manage payment methods, and update your preferences.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Bell className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Notifications</h3>
                  <p className="text-sm text-muted-foreground">
                    Stay updated with order status, deals, and personalized recommendations.
                  </p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="orders" className="space-y-4">
              <div className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Package className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Order Tracking</h3>
                  <p className="text-sm text-muted-foreground">
                    Track your orders in real-time and get delivery updates.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-primary"
                  >
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                    <polyline points="17 8 12 3 7 8" />
                    <line x1="12" y1="3" x2="12" y2="15" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-medium">Returns & Replacements</h3>
                  <p className="text-sm text-muted-foreground">
                    Easily request returns or replacements for your orders within 7 days of delivery.
                  </p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="deals" className="space-y-4">
              <div className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Tag className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Mega Deals</h3>
                  <p className="text-sm text-muted-foreground">
                    Don't miss our limited-time mega deals with discounts up to 70% off!
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-primary"
                  >
                    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-medium">Personalized Offers</h3>
                  <p className="text-sm text-muted-foreground">
                    Get special offers tailored to your shopping preferences and history.
                  </p>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex justify-between items-center mt-4">
            <Button
              variant="outline"
              onClick={() => {
                const prevTab = {
                  welcome: "welcome",
                  shop: "welcome",
                  account: "shop",
                  orders: "account",
                  deals: "orders",
                }[activeTab]
                handleTabChange(prevTab)
              }}
              disabled={activeTab === "welcome"}
            >
              Previous
            </Button>

            <div className="flex gap-1">
              {["welcome", "shop", "account", "orders", "deals"].map((tab) => (
                <div key={tab} className={`w-2 h-2 rounded-full ${activeTab === tab ? "bg-primary" : "bg-muted"}`} />
              ))}
            </div>

            <Button
              onClick={() => {
                const nextTab = {
                  welcome: "shop",
                  shop: "account",
                  account: "orders",
                  orders: "deals",
                  deals: "deals",
                }[activeTab]

                if (activeTab === "deals") {
                  handleClose()
                } else {
                  handleTabChange(nextTab)
                }
              }}
            >
              {activeTab === "deals" ? "Get Started" : "Next"}
            </Button>
          </div>

          <DialogFooter className="sm:justify-center border-t pt-4 mt-4">
            <Button variant="ghost" size="sm" onClick={handleClose}>
              Skip Tour
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

