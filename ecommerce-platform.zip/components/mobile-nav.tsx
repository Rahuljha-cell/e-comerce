"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import {
  Home,
  ShoppingBag,
  Heart,
  Package,
  User,
  Settings,
  HelpCircle,
  Menu,
  Search,
  Phone,
  Info,
  FileText,
  ShieldCheck,
  LogIn,
  LogOut,
  ChevronRight,
} from "lucide-react"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/hooks/use-auth"

// Define navigation items
const mainNavItems = [
  { href: "/", label: "Home", icon: <Home className="h-5 w-5 mr-3" /> },
  { href: "/products", label: "All Products", icon: <ShoppingBag className="h-5 w-5 mr-3" /> },
  { href: "/category/electronics", label: "Electronics", icon: <Search className="h-5 w-5 mr-3" /> },
  { href: "/category/mens-clothing", label: "Men's Clothing", icon: <Search className="h-5 w-5 mr-3" /> },
  { href: "/category/womens-clothing", label: "Women's Clothing", icon: <Search className="h-5 w-5 mr-3" /> },
  { href: "/category/jewelry", label: "Jewelry & Watches", icon: <Search className="h-5 w-5 mr-3" /> },
  { href: "/category/home", label: "Home & Kitchen", icon: <Search className="h-5 w-5 mr-3" /> },
]

const accountNavItems = [
  { href: "/account/profile", label: "My Profile", icon: <User className="h-5 w-5 mr-3" /> },
  { href: "/account/orders", label: "My Orders", icon: <Package className="h-5 w-5 mr-3" /> },
  { href: "/wishlist", label: "Wishlist", icon: <Heart className="h-5 w-5 mr-3" /> },
  { href: "/account/settings", label: "Settings", icon: <Settings className="h-5 w-5 mr-3" /> },
]

const infoNavItems = [
  { href: "/about", label: "About Us", icon: <Info className="h-5 w-5 mr-3" /> },
  { href: "/contact", label: "Contact Us", icon: <Phone className="h-5 w-5 mr-3" /> },
  { href: "/terms", label: "Terms & Conditions", icon: <FileText className="h-5 w-5 mr-3" /> },
  { href: "/privacy", label: "Privacy Policy", icon: <ShieldCheck className="h-5 w-5 mr-3" /> },
  { href: "/help", label: "Help & FAQ", icon: <HelpCircle className="h-5 w-5 mr-3" /> },
]

export default function MobileNav() {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()
  const { isAuthenticated, user, signOut } = useAuth()

  const handleLinkClick = () => {
    setOpen(false)
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[300px] sm:w-[350px] p-0">
        <SheetHeader className="p-4 border-b">
          <SheetTitle className="text-left">Menu</SheetTitle>
        </SheetHeader>

        <ScrollArea className="h-[calc(100vh-60px)]">
          {isAuthenticated && (
            <div className="p-4 flex items-center">
              <Avatar className="h-10 w-10 mr-3">
                <AvatarImage src={user?.image || ""} alt={user?.name || "User"} />
                <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{user?.name || "User"}</p>
                <p className="text-sm text-muted-foreground">{user?.email || ""}</p>
              </div>
            </div>
          )}

          <div className="p-4">
            <p className="text-sm font-medium text-muted-foreground mb-2">Shop</p>
            <nav className="space-y-1">
              {mainNavItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={handleLinkClick}
                  className={`flex items-center py-2 px-3 text-sm rounded-md transition-colors ${
                    pathname === item.href ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted"
                  }`}
                >
                  {item.icon}
                  {item.label}
                  <ChevronRight className="h-4 w-4 ml-auto" />
                </Link>
              ))}
            </nav>
          </div>

          <Separator />

          <div className="p-4">
            <p className="text-sm font-medium text-muted-foreground mb-2">Account</p>
            <nav className="space-y-1">
              {isAuthenticated ? (
                <>
                  {accountNavItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={handleLinkClick}
                      className={`flex items-center py-2 px-3 text-sm rounded-md transition-colors ${
                        pathname === item.href ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted"
                      }`}
                    >
                      {item.icon}
                      {item.label}
                      <ChevronRight className="h-4 w-4 ml-auto" />
                    </Link>
                  ))}
                  <button
                    onClick={() => {
                      signOut()
                      handleLinkClick()
                    }}
                    className="flex items-center py-2 px-3 text-sm rounded-md transition-colors w-full text-left hover:bg-muted"
                  >
                    <LogOut className="h-5 w-5 mr-3" />
                    Sign Out
                  </button>
                </>
              ) : (
                <Link
                  href="/signin"
                  onClick={handleLinkClick}
                  className="flex items-center py-2 px-3 text-sm rounded-md transition-colors hover:bg-muted"
                >
                  <LogIn className="h-5 w-5 mr-3" />
                  Sign In
                  <ChevronRight className="h-4 w-4 ml-auto" />
                </Link>
              )}
            </nav>
          </div>

          <Separator />

          <div className="p-4">
            <p className="text-sm font-medium text-muted-foreground mb-2">Information</p>
            <nav className="space-y-1">
              {infoNavItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={handleLinkClick}
                  className={`flex items-center py-2 px-3 text-sm rounded-md transition-colors ${
                    pathname === item.href ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted"
                  }`}
                >
                  {item.icon}
                  {item.label}
                  <ChevronRight className="h-4 w-4 ml-auto" />
                </Link>
              ))}
            </nav>
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  )
}

