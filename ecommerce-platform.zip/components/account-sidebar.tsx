"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { User, Package, ShoppingCart, Heart, CreditCard, Settings, LogOut, Bell } from "lucide-react"

export default function AccountSidebar() {
  const pathname = usePathname()

  const isActive = (path: string) => {
    return pathname === path
  }

  const menuItems = [
    { href: "/account/profile", label: "Profile", icon: User },
    { href: "/account/orders", label: "My Orders", icon: Package },
    { href: "/wishlist", label: "Wishlist", icon: Heart },
    { href: "/cart", label: "Cart", icon: ShoppingCart },
    { href: "/account/payment", label: "Payment Methods", icon: CreditCard },
    { href: "/account/notifications", label: "Notifications", icon: Bell },
    { href: "/account/settings", label: "Settings", icon: Settings },
  ]

  return (
    <div className="w-full md:w-64 shrink-0 space-y-6">
      <div className="flex items-center gap-4 p-4 border rounded-lg">
        <Avatar className="h-12 w-12">
          <AvatarImage src="/placeholder.svg?height=48&width=48&text=JD" alt="John Doe" />
          <AvatarFallback>JD</AvatarFallback>
        </Avatar>
        <div>
          <p className="font-medium">John Doe</p>
          <p className="text-sm text-muted-foreground">john.doe@example.com</p>
        </div>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <div className="bg-muted px-4 py-2">
          <h3 className="font-medium">Account</h3>
        </div>
        <div className="p-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <Button
                key={item.href}
                variant={isActive(item.href) ? "secondary" : "ghost"}
                className="w-full justify-start mb-1"
                asChild
              >
                <Link href={item.href}>
                  <Icon className="h-4 w-4 mr-2" />
                  {item.label}
                </Link>
              </Button>
            )
          })}

          <div className="pt-2 mt-2 border-t">
            <Button variant="ghost" className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50">
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </div>

      <div className="border rounded-lg p-4">
        <h3 className="font-medium mb-2">Need Help?</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Contact our customer support team for assistance with your account.
        </p>
        <Button variant="outline" className="w-full" asChild>
          <Link href="/contact">Contact Support</Link>
        </Button>
      </div>
    </div>
  )
}

